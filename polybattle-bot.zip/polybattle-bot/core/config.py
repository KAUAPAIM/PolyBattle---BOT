"""
Carregamento de configuração a partir do arquivo .env.

Todas as opções são lidas uma única vez na inicialização e expostas
através do objeto imutável ``Settings``. Nenhum token ou credencial é
impresso em logs.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent


class ConfigError(RuntimeError):
    """Erro de configuração inválida ou ausente."""


def _get_int(name: str, default: int | None = None, *, minimum: int | None = None) -> int | None:
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise ConfigError(f"A variável {name} deve ser um número inteiro (valor atual inválido).") from exc
    if minimum is not None and value < minimum:
        raise ConfigError(f"A variável {name} deve ser >= {minimum}.")
    return value


def _get_str(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


@dataclass(frozen=True)
class Settings:
    # Credenciais / alvo
    token: str
    guild_id: int | None

    # Arquivos
    database_path: Path
    log_dir: Path
    log_level: str

    # Identidade do jogo
    game_name: str
    roblox_game_url: str
    roblox_universe_id: int | None
    roblox_group_url: str
    website_url: str
    update_check_minutes: int

    # Verificação
    verify_min_account_age_days: int

    # Moderação / punições automáticas por avisos
    warn_timeout_threshold: int
    warn_timeout_minutes: int
    warn_kick_threshold: int
    warn_ban_threshold: int

    # Automod
    automod_flood_messages: int
    automod_flood_seconds: int
    automod_duplicate_messages: int
    automod_duplicate_seconds: int
    automod_max_mentions: int
    automod_timeout_minutes: int
    automod_malicious_link_timeout_minutes: int

    # Anti-raid
    raid_join_threshold: int
    raid_join_seconds: int
    raid_mode_minutes: int

    # Tickets / cargos automáticos
    max_open_tickets_per_user: int
    veteran_days: int


def load_settings(env_file: str | os.PathLike | None = None) -> Settings:
    """Lê o .env e valida as opções obrigatórias."""
    load_dotenv(env_file or BASE_DIR / ".env")

    token = _get_str("DISCORD_TOKEN")
    if not token or token == "cole_o_token_aqui":
        raise ConfigError(
            "DISCORD_TOKEN não definido. Copie .env.example para .env e preencha o token do bot."
        )

    db_path = Path(_get_str("DATABASE_PATH", "data/polybattle.db"))
    if not db_path.is_absolute():
        db_path = BASE_DIR / db_path
    log_dir = Path(_get_str("LOG_DIR", "logs"))
    if not log_dir.is_absolute():
        log_dir = BASE_DIR / log_dir

    return Settings(
        token=token,
        guild_id=_get_int("GUILD_ID"),
        database_path=db_path,
        log_dir=log_dir,
        log_level=_get_str("LOG_LEVEL", "INFO").upper(),
        game_name=_get_str("GAME_NAME", "PolyBattle"),
        roblox_game_url=_get_str("ROBLOX_GAME_URL"),
        roblox_universe_id=_get_int("ROBLOX_UNIVERSE_ID"),
        roblox_group_url=_get_str("ROBLOX_GROUP_URL"),
        website_url=_get_str("WEBSITE_URL"),
        update_check_minutes=_get_int("UPDATE_CHECK_MINUTES", 10, minimum=2),
        verify_min_account_age_days=_get_int("VERIFY_MIN_ACCOUNT_AGE_DAYS", 3, minimum=0),
        warn_timeout_threshold=_get_int("WARN_TIMEOUT_THRESHOLD", 3, minimum=0),
        warn_timeout_minutes=_get_int("WARN_TIMEOUT_MINUTES", 60, minimum=1),
        warn_kick_threshold=_get_int("WARN_KICK_THRESHOLD", 5, minimum=0),
        warn_ban_threshold=_get_int("WARN_BAN_THRESHOLD", 0, minimum=0),
        automod_flood_messages=_get_int("AUTOMOD_FLOOD_MESSAGES", 6, minimum=2),
        automod_flood_seconds=_get_int("AUTOMOD_FLOOD_SECONDS", 5, minimum=1),
        automod_duplicate_messages=_get_int("AUTOMOD_DUPLICATE_MESSAGES", 3, minimum=2),
        automod_duplicate_seconds=_get_int("AUTOMOD_DUPLICATE_SECONDS", 30, minimum=1),
        automod_max_mentions=_get_int("AUTOMOD_MAX_MENTIONS", 5, minimum=1),
        automod_timeout_minutes=_get_int("AUTOMOD_TIMEOUT_MINUTES", 10, minimum=1),
        automod_malicious_link_timeout_minutes=_get_int(
            "AUTOMOD_MALICIOUS_LINK_TIMEOUT_MINUTES", 1440, minimum=1
        ),
        raid_join_threshold=_get_int("RAID_JOIN_THRESHOLD", 10, minimum=2),
        raid_join_seconds=_get_int("RAID_JOIN_SECONDS", 30, minimum=5),
        raid_mode_minutes=_get_int("RAID_MODE_MINUTES", 15, minimum=1),
        max_open_tickets_per_user=_get_int("MAX_OPEN_TICKETS_PER_USER", 1, minimum=1),
        veteran_days=_get_int("VETERAN_DAYS", 30, minimum=1),
    )
