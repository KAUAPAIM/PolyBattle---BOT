"""
Textos oficiais publicados pelo bot (regras, apresentação, painéis).

Edite este arquivo para ajustar o conteúdo e rode ``/setup panels`` para
republicar. Os textos são bilíngues (PT-BR / EN).
"""

from __future__ import annotations

SERVER_NAME = "POLYBATTLE | OFFICIAL"
FOOTER = "POLYBATTLE | OFFICIAL • Tactical Operations Command"

PRESENTATION_TITLE = "PRESENTING: POLYBATTLE"
PRESENTATION = (
    "**PolyBattle** é um FPS tático desenvolvido no Roblox. Duas facções — **RED** e **BLUE** — "
    "disputam o controle do campo de batalha. Escolha seu lado, faça o deploy e lute ao lado do seu "
    "esquadrão.\n\n"
    "**PolyBattle** is a tactical FPS built on Roblox. Two factions — **RED** and **BLUE** — fight "
    "for control of the battlefield. Pick your side, deploy and fight alongside your squad."
)

GAME_INFO_SECTIONS: list[tuple[str, str]] = [
    (
        "⚔️ Facções | Factions",
        "🔴 **RED** vs 🔵 **BLUE**\n"
        "Escolha seu lado antes do deploy. | Choose your side before deploying.",
    ),
    (
        "🪖 Jogue em esquadrão | Play as a squad",
        "Use <#looking_for_team> para encontrar parceiros e os canais **Squad** para comunicação por voz.\n"
        "Use <#looking_for_team> to find teammates and the **Squad** voice channels to communicate.",
    ),
    (
        "🛠 Atualizações | Updates",
        "Todas as notas de atualização são publicadas em <#changelog>.\n"
        "All patch notes are posted in <#changelog>.",
    ),
    (
        "🎫 Suporte | Support",
        "Problemas com o jogo? Abra um ticket em <#open_a_ticket>.\n"
        "Having issues? Open a ticket in <#open_a_ticket>.",
    ),
]

RULES: list[tuple[str, str, str]] = [
    ("1", "Respeito acima de tudo",
     "Respect above all — no harassment, hate speech, discrimination or personal attacks."),
    ("2", "Sem spam ou flood",
     "No spam, flooding, repeated messages or excessive mentions."),
    ("3", "Sem conteúdo impróprio (NSFW, gore, ilegal)",
     "No NSFW, gore or illegal content of any kind."),
    ("4", "Sem divulgação não autorizada (servidores, links, vendas)",
     "No unauthorized advertising — servers, links or sales."),
    ("5", "Sem trapaças, exploits ou venda de contas",
     "No cheats, exploits, account trading or promotion of them."),
    ("6", "Use cada canal para seu propósito",
     "Use each channel for its intended purpose."),
    ("7", "Não se passe por membros da equipe",
     "Do not impersonate staff members or developers."),
    ("8", "Bugs e exploits devem ser reportados em privado (ticket)",
     "Report exploits privately through a ticket — never publicly."),
    ("9", "Decisões da equipe devem ser respeitadas; contestações via ticket",
     "Respect staff decisions; appeals go through a ticket."),
    ("10", "Siga os Termos de Serviço do Discord e do Roblox",
     "Follow Discord's and Roblox's Terms of Service."),
]

PUNISHMENT_LADDER = (
    "**Sistema de punições | Punishment system**\n"
    "`AVISO / WARN` → `MUTE (timeout)` → `KICK` → `BAN`\n"
    "Infrações graves podem resultar em banimento imediato.\n"
    "Severe violations may result in an immediate ban."
)

VERIFY_TEXT = (
    "Bem-vindo(a) ao **POLYBATTLE | OFFICIAL**.\n"
    "Para acessar o servidor, clique em **Verificar** e confirme o código de segurança.\n\n"
    "Welcome to **POLYBATTLE | OFFICIAL**.\n"
    "To access the server, click **Verify** and confirm the security code.\n\n"
    "Ao se verificar você concorda com as regras em <#server_rules>.\n"
    "By verifying you agree to the rules in <#server_rules>."
)

TICKET_PANEL_TEXT = (
    "Precisa de ajuda da equipe? Selecione uma categoria abaixo para abrir um **ticket privado**.\n"
    "Need help from the team? Select a category below to open a **private ticket**.\n\n"
    "🛟 **General Support** — dúvidas gerais | general help\n"
    "🐞 **Bug Report** — bugs e exploits (privado) | bugs and exploits (private)\n"
    "🚨 **Player Report** — denúncias detalhadas | detailed reports\n"
    "🤝 **Partnership** — parcerias | partnerships\n"
    "📁 **Other Issues** — outros assuntos | anything else\n\n"
    "Abuso do sistema de tickets resulta em punição. | Ticket abuse will be punished."
)

REPORT_PANEL_TEXT = (
    "Viu alguém quebrando as regras? Clique em **Denunciar jogador** e preencha o formulário. "
    "A denúncia é enviada **apenas para a equipe**.\n\n"
    "Saw someone breaking the rules? Click **Report player** and fill in the form. "
    "Reports are only visible to staff.\n\n"
    "Denúncias falsas são passíveis de punição. | False reports may be punished."
)

SUGGESTION_PANEL_TEXT = (
    "Tem uma ideia para o PolyBattle? Use o comando **/suggest**.\n"
    "Have an idea for PolyBattle? Use the **/suggest** command.\n\n"
    "👍 / 👎 para votar | to vote — a equipe analisa as mais votadas. | Staff reviews the top ideas."
)

WELCOME_PUBLIC = (
    "🪖 **{mention}** se alistou no **POLYBATTLE**! Soldado nº **{count}**.\n"
    "-# {mention} has enlisted. Welcome to the battlefield, soldier #{count}."
)

WELCOME_DM = (
    "**Bem-vindo(a) ao POLYBATTLE | OFFICIAL, {name}!**\n"
    "Para liberar o servidor, vá até o canal **✅┃verify** e clique em **Verificar**.\n\n"
    "**Welcome to POLYBATTLE | OFFICIAL, {name}!**\n"
    "To unlock the server, go to **✅┃verify** and click **Verify**."
)
