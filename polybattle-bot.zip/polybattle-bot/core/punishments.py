"""Regras de escalonamento de punições (lógica pura, testável)."""

from __future__ import annotations


def escalation_for(warning_count: int, *, timeout_at: int, kick_at: int, ban_at: int) -> str | None:
    """
    Decide a punição automática após um aviso.

    Thresholds iguais a 0 ficam desativados. A punição mais severa aplicável vence.
    Retorna 'ban', 'kick', 'timeout' ou None.
    """
    if ban_at and warning_count >= ban_at:
        return "ban"
    if kick_at and warning_count >= kick_at:
        return "kick"
    if timeout_at and warning_count >= timeout_at:
        return "timeout"
    return None
