"""
Blueprint (planta) do servidor POLYBATTLE | OFFICIAL.

Este módulo é **dados puros**: não importa discord.py, o que permite testar
a estrutura isoladamente. O cog ``setup`` converte estas especificações em
cargos, categorias, canais e permissões reais.

Convenções
----------
* Permissões são nomes de atributos de ``discord.Permissions``
  (ex.: ``"send_messages"``).
* Alvos de overwrite: ``"@everyone"`` ou a *key* de um cargo do blueprint.
* Cada cargo/canal tem uma *key* estável. O ID real no Discord fica salvo no
  banco (tabela ``resources``), o que impede duplicações quando o setup é
  executado novamente e permite renomear canais sem perder o vínculo.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# --------------------------------------------------------------------------- paleta
COLOR_BLACK = 0x0B0D0B
COLOR_GREEN = 0x4B6F2A        # verde militar (cor principal das embeds)
COLOR_GREEN_LIGHT = 0x7FA650
COLOR_GRAY = 0x5F6368
COLOR_WHITE = 0xF2F2F2
COLOR_DANGER = 0x9E2A2B       # usado apenas em alertas/punições
COLOR_WARNING = 0xC9A227

# --------------------------------------------------------------------------- permissões base
EVERYONE_GUILD_PERMS: frozenset[str] = frozenset({
    "view_channel",
    "read_message_history",
    "use_application_commands",
})

MEMBER_GUILD_PERMS: frozenset[str] = frozenset({
    "view_channel",
    "read_message_history",
    "send_messages",
    "send_messages_in_threads",
    "create_public_threads",
    "add_reactions",
    "embed_links",
    "attach_files",
    "use_external_emojis",
    "use_application_commands",
    "change_nickname",
    "connect",
    "speak",
    "stream",
    "use_voice_activation",
})

MODERATION_PERMS: frozenset[str] = frozenset({
    "kick_members",
    "moderate_members",
    "manage_messages",
    "manage_threads",
    "manage_nicknames",
    "mute_members",
    "deafen_members",
    "move_members",
    "view_audit_log",
})

# Permissões consideradas perigosas: concessão não autorizada é revertida
# pelo módulo de segurança.
DANGEROUS_PERMS: frozenset[str] = frozenset({
    "administrator",
    "manage_guild",
    "manage_roles",
    "manage_channels",
    "manage_webhooks",
    "ban_members",
    "kick_members",
    "moderate_members",
    "mention_everyone",
})


@dataclass(frozen=True)
class RoleSpec:
    key: str
    name: str
    color: int
    permissions: frozenset[str]
    hoist: bool = True
    mentionable: bool = False


@dataclass(frozen=True)
class ChannelSpec:
    key: str
    name: str
    kind: str = "text"                 # "text" | "voice"
    topic: str = ""
    slowmode: int = 0
    user_limit: int = 0
    overwrites: dict[str, dict[str, bool]] = field(default_factory=dict)


@dataclass(frozen=True)
class CategorySpec:
    key: str
    name: str
    overwrites: dict[str, dict[str, bool]]
    channels: tuple[ChannelSpec, ...]


# --------------------------------------------------------------------------- cargos (do topo para a base)
ROLES: tuple[RoleSpec, ...] = (
    RoleSpec("founder", "Founder", 0xF2F2F2, frozenset({"administrator"})),
    RoleSpec("owner", "Owner", 0xC9C9C9, frozenset({"administrator"})),
    RoleSpec(
        "administrator", "Administrator", 0x9E2A2B,
        MEMBER_GUILD_PERMS | MODERATION_PERMS | {
            "ban_members", "manage_roles", "manage_channels", "manage_guild",
            "manage_webhooks", "manage_events", "manage_expressions", "mention_everyone",
            "create_private_threads", "priority_speaker",
        },
    ),
    RoleSpec(
        "head_moderator", "Head Moderator", 0xD9822B,
        MEMBER_GUILD_PERMS | MODERATION_PERMS | {"ban_members", "create_private_threads"},
    ),
    RoleSpec("moderator", "Moderator", 0xE3B341, MEMBER_GUILD_PERMS | MODERATION_PERMS),
    RoleSpec(
        "support_team", "Support Team", 0x4FA3D1,
        MEMBER_GUILD_PERMS | {"manage_threads"},
    ),
    RoleSpec("developer", "Developer", 0x6FBF73, MEMBER_GUILD_PERMS, mentionable=True),
    RoleSpec("builder", "Builder", 0xA67C52, MEMBER_GUILD_PERMS),
    RoleSpec("tester", "Tester", 0x9B7EDE, MEMBER_GUILD_PERMS),
    RoleSpec("vip", "VIP", 0xE5C07B, MEMBER_GUILD_PERMS),
    RoleSpec("veteran", "Veteran", 0x6B8E23, MEMBER_GUILD_PERMS),
    RoleSpec("verified", "Verified", 0x8A9A5B, MEMBER_GUILD_PERMS, hoist=False),
    RoleSpec("member", "Member", 0x9AA0A6, MEMBER_GUILD_PERMS),
)

ROLE_KEYS: tuple[str, ...] = tuple(r.key for r in ROLES)
ROLE_BY_KEY: dict[str, RoleSpec] = {r.key: r for r in ROLES}

# Grupos funcionais (usados pelas checagens de permissão)
ADMIN_ROLES = ("founder", "owner", "administrator")
SENIOR_MOD_ROLES = ADMIN_ROLES + ("head_moderator",)
MOD_ROLES = SENIOR_MOD_ROLES + ("moderator",)
STAFF_ROLES = MOD_ROLES + ("support_team",)
DEV_ROLES = ("developer", "builder", "tester")

# Quem pode conceder cada cargo protegido. Concessões feitas por outras pessoas
# (mesmo que o Discord permita pela hierarquia) são revertidas e registradas.
GRANT_RULES: dict[str, tuple[str, ...]] = {
    "founder": ("founder",),
    "owner": ("founder",),
    "administrator": ("founder", "owner"),
    "head_moderator": ("founder", "owner", "administrator"),
    "moderator": ("founder", "owner", "administrator", "head_moderator"),
    "support_team": ("founder", "owner", "administrator", "head_moderator"),
    "developer": ("founder", "owner", "administrator"),
    "builder": ("founder", "owner", "administrator"),
    "tester": ("founder", "owner", "administrator"),
    "vip": ("founder", "owner", "administrator"),
}

# --------------------------------------------------------------------------- overwrites reutilizáveis
READ_ONLY = {"send_messages": False, "create_public_threads": False,
             "create_private_threads": False, "send_messages_in_threads": False,
             "add_reactions": True}
HIDDEN = {"view_channel": False}
VISIBLE = {"view_channel": True}
STAFF_VISIBLE = {"view_channel": True, "send_messages": True, "read_message_history": True,
                 "connect": True, "speak": True}


def _staff(perms: dict[str, bool] | None = None) -> dict[str, dict[str, bool]]:
    data = perms or STAFF_VISIBLE
    return {key: dict(data) for key in STAFF_ROLES}


# --------------------------------------------------------------------------- categorias e canais
CATEGORIES: tuple[CategorySpec, ...] = (
    CategorySpec(
        key="cat_information",
        name="◤ INFORMATION ◢",
        overwrites={"@everyone": {"view_channel": True, **READ_ONLY, "add_reactions": False},
                    "verified": {"add_reactions": True}},
        channels=(
            ChannelSpec(
                "verify", "✅┃verify",
                topic="Verifique-se para acessar o servidor. | Verify to unlock the server.",
                overwrites={"verified": {"view_channel": False}},
            ),
            ChannelSpec(
                "announcements", "📢┃announcements",
                topic="Comunicados oficiais do PolyBattle. | Official PolyBattle announcements.",
                overwrites={"administrator": {"send_messages": True}},
            ),
            ChannelSpec(
                "server_rules", "📜┃server-rules",
                topic="Regras do servidor. Leia antes de participar. | Server rules.",
            ),
            ChannelSpec(
                "game_information", "🎮┃game-information",
                topic="Tudo sobre o PolyBattle. | Everything about PolyBattle.",
            ),
            ChannelSpec(
                "changelog", "🛠┃changelog",
                topic="Notas de atualização do jogo. | Game patch notes.",
                overwrites={"developer": {"send_messages": True}},
            ),
            ChannelSpec(
                "useful_links", "🔗┃useful-links",
                topic="Links oficiais. | Official links.",
            ),
        ),
    ),
    CategorySpec(
        key="cat_community",
        name="◤ COMMUNITY ◢",
        overwrites={"@everyone": dict(HIDDEN), "verified": dict(VISIBLE)},
        channels=(
            ChannelSpec("general_chat", "💬┃general-chat",
                        topic="Chat geral da comunidade. | General community chat.", slowmode=2),
            ChannelSpec("in_game_chat", "🎯┃in-game-chat",
                        topic="Fale sobre partidas, armas e estratégias. | Matches, loadouts and tactics.",
                        slowmode=2),
            ChannelSpec("screenshots", "📸┃screenshots",
                        topic="Somente imagens do jogo. | In-game screenshots only.", slowmode=15),
            ChannelSpec("clips_and_highlights", "🎬┃clips-and-highlights",
                        topic="Seus melhores clipes. | Your best plays.", slowmode=15),
            ChannelSpec("looking_for_team", "🪖┃looking-for-team",
                        topic="Monte seu esquadrão. | Find your squad.", slowmode=30),
        ),
    ),
    CategorySpec(
        key="cat_support",
        name="◤ GAME SUPPORT ◢",
        overwrites={"@everyone": dict(HIDDEN), "verified": dict(VISIBLE)},
        channels=(
            ChannelSpec("open_a_ticket", "🎫┃open-a-ticket",
                        topic="Abra um ticket com a equipe. | Open a ticket with the team.",
                        overwrites={"verified": {**READ_ONLY}}),
            ChannelSpec("bug_reports", "🐞┃bug-reports",
                        topic="Relate bugs com passos para reproduzir. | Report bugs with repro steps.",
                        slowmode=60),
            ChannelSpec("suggestions", "💡┃suggestions",
                        topic="Use /suggest para enviar sugestões. | Use /suggest to submit ideas.",
                        overwrites={"verified": {"send_messages": False, "create_public_threads": False,
                                                 "send_messages_in_threads": True}}),
            ChannelSpec("player_reports", "🚨┃player-reports",
                        topic="Denuncie jogadores pelo painel. | Report players via the panel.",
                        overwrites={"verified": {**READ_ONLY}}),
        ),
    ),
    CategorySpec(
        key="cat_development",
        name="◤ DEVELOPMENT ◢",
        overwrites={"@everyone": dict(HIDDEN), "verified": dict(VISIBLE)},
        channels=(
            ChannelSpec("development_updates", "🧪┃development-updates",
                        topic="Bastidores do desenvolvimento. | Behind the scenes.",
                        overwrites={"verified": {**READ_ONLY},
                                    "developer": {"send_messages": True}}),
            ChannelSpec("upcoming_features", "🚀┃upcoming-features",
                        topic="O que está por vir. | What's coming next.",
                        overwrites={"verified": {**READ_ONLY},
                                    "developer": {"send_messages": True}}),
            ChannelSpec("testing", "🔬┃testing",
                        topic="Área restrita de testes. | Restricted testing area.",
                        overwrites={"verified": {"view_channel": False},
                                    "tester": {"view_channel": True, "send_messages": True},
                                    "builder": {"view_channel": True, "send_messages": True},
                                    "developer": {"view_channel": True, "send_messages": True},
                                    **_staff()}),
            ChannelSpec("community_feedback", "🗳┃community-feedback",
                        topic="Seu feedback sobre o jogo. | Your feedback about the game.",
                        slowmode=30),
        ),
    ),
    CategorySpec(
        key="cat_voice",
        name="◤ VOICE CHANNELS ◢",
        overwrites={"@everyone": dict(HIDDEN),
                    "verified": {"view_channel": True, "connect": True, "speak": True}},
        channels=(
            ChannelSpec("voice_general", "🔊 General Voice", kind="voice"),
            ChannelSpec("voice_squad_01", "🪖 Squad 01", kind="voice", user_limit=5),
            ChannelSpec("voice_squad_02", "🪖 Squad 02", kind="voice", user_limit=5),
            ChannelSpec("voice_squad_03", "🪖 Squad 03", kind="voice", user_limit=5),
            ChannelSpec("voice_squad_04", "🪖 Squad 04", kind="voice", user_limit=5),
        ),
    ),
    CategorySpec(
        key="cat_staff",
        name="◤ STAFF ◢",
        overwrites={"@everyone": dict(HIDDEN), **_staff()},
        channels=(
            ChannelSpec("staff_chat", "🛡┃staff-chat", topic="Comunicação interna da equipe."),
            ChannelSpec("staff_logs", "🗂┃staff-logs", topic="Logs automáticos do bot. Somente leitura.",
                        overwrites={key: {"send_messages": False, "add_reactions": False}
                                    for key in STAFF_ROLES if key not in ("founder", "owner")}),
            ChannelSpec("staff_reports", "📋┃staff-reports",
                        topic="Denúncias de jogadores recebidas pelo bot."),
            ChannelSpec("staff_announcements", "📣┃staff-announcements",
                        topic="Avisos internos da administração.",
                        overwrites={key: {"send_messages": False}
                                    for key in ("head_moderator", "moderator", "support_team")}),
            ChannelSpec("staff_voice", "🎧 Staff Voice", kind="voice"),
        ),
    ),
    CategorySpec(
        key="cat_tickets",
        name="◤ TICKETS ◢",
        overwrites={"@everyone": dict(HIDDEN), **_staff()},
        channels=(),
    ),
)

ALL_CHANNELS: dict[str, ChannelSpec] = {
    ch.key: ch for cat in CATEGORIES for ch in cat.channels
}
CATEGORY_BY_KEY: dict[str, CategorySpec] = {c.key: c for c in CATEGORIES}

# --------------------------------------------------------------------------- tickets
@dataclass(frozen=True)
class TicketType:
    key: str
    label: str
    emoji: str
    description: str
    prefix: str
    roles: tuple[str, ...]   # cargos que enxergam o ticket (além do autor)


TICKET_TYPES: tuple[TicketType, ...] = (
    TicketType("general", "General Support", "🛟", "Dúvidas e ajuda geral | General help", "support",
               STAFF_ROLES),
    TicketType("bug", "Bug Report", "🐞", "Relatar um bug privado | Private bug report", "bug",
               STAFF_ROLES + ("developer",)),
    TicketType("player", "Player Report", "🚨", "Denunciar um jogador | Report a player", "report",
               MOD_ROLES),
    TicketType("partnership", "Partnership", "🤝", "Propostas de parceria | Partnership requests",
               "partner", ADMIN_ROLES),
    TicketType("other", "Other Issues", "📁", "Outros assuntos | Other issues", "other", STAFF_ROLES),
)
TICKET_BY_KEY: dict[str, TicketType] = {t.key: t for t in TICKET_TYPES}


def validate_blueprint() -> list[str]:
    """Retorna uma lista de problemas encontrados (vazia = blueprint consistente)."""
    problems: list[str] = []
    valid_targets = {"@everyone", *ROLE_KEYS}

    keys = [r.key for r in ROLES]
    if len(keys) != len(set(keys)):
        problems.append("Chaves de cargos duplicadas")
    names = [r.name for r in ROLES]
    if len(names) != len(set(names)):
        problems.append("Nomes de cargos duplicados")
    colors = [r.color for r in ROLES]
    if len(colors) != len(set(colors)):
        problems.append("Cores de cargos repetidas")

    seen: set[str] = set()
    for cat in CATEGORIES:
        for target in cat.overwrites:
            if target not in valid_targets:
                problems.append(f"Overwrite inválido em {cat.key}: {target}")
        for ch in cat.channels:
            if ch.key in seen or ch.key in CATEGORY_BY_KEY:
                problems.append(f"Chave de canal duplicada: {ch.key}")
            seen.add(ch.key)
            if ch.kind not in ("text", "voice"):
                problems.append(f"Tipo de canal inválido: {ch.key}")
            for target in ch.overwrites:
                if target not in valid_targets:
                    problems.append(f"Overwrite inválido em {ch.key}: {target}")

    for role_key, grantors in GRANT_RULES.items():
        if role_key not in ROLE_BY_KEY:
            problems.append(f"GRANT_RULES referencia cargo inexistente: {role_key}")
        for g in grantors:
            if g not in ROLE_BY_KEY:
                problems.append(f"GRANT_RULES referencia concedente inexistente: {g}")
            elif ROLE_KEYS.index(g) > ROLE_KEYS.index(role_key):
                problems.append(f"{g} não pode conceder {role_key}: está abaixo na hierarquia")

    for t in TICKET_TYPES:
        for r in t.roles:
            if r not in ROLE_BY_KEY:
                problems.append(f"Ticket {t.key} referencia cargo inexistente: {r}")
    return problems


def merge_overwrites(
    category: dict[str, dict[str, bool]], channel: dict[str, dict[str, bool]]
) -> dict[str, dict[str, bool]]:
    """Combina os overwrites da categoria com os específicos do canal (o canal prevalece)."""
    merged: dict[str, dict[str, bool]] = {t: dict(p) for t, p in category.items()}
    for target, perms in channel.items():
        merged.setdefault(target, {}).update(perms)
    return merged
