"""
Classe principal do bot, utilitários compartilhados entre cogs e
tratamento global de erros.
"""

from __future__ import annotations

import logging
import traceback
from typing import Iterable

import discord
from discord import app_commands
from discord.ext import commands

from core import blueprint as bp
from core import ui
from core.config import Settings
from core.database import Database

log = logging.getLogger("polybattle")

EXTENSIONS = (
    "cogs.setup",
    "cogs.verification",
    "cogs.welcome",
    "cogs.tickets",
    "cogs.reports",
    "cogs.suggestions",
    "cogs.moderation",
    "cogs.automod",
    "cogs.security",
    "cogs.logging_events",
    "cogs.announcements",
    "cogs.autoroles",
)


class MissingStaffRole(app_commands.CheckFailure):
    """O usuário não possui nenhum dos cargos exigidos pelo comando."""

    def __init__(self, role_keys: Iterable[str]) -> None:
        self.role_keys = tuple(role_keys)
        names = ", ".join(bp.ROLE_BY_KEY[k].name for k in self.role_keys if k in bp.ROLE_BY_KEY)
        super().__init__(f"Cargo necessário: {names}")


class SetupRequired(app_commands.CheckFailure):
    """O servidor ainda não foi configurado com /setup install."""


async def respond(interaction: discord.Interaction, embed: discord.Embed, *,
                  ephemeral: bool = True, view: discord.ui.View | None = None) -> None:
    """Responde à interação independentemente de ela já ter sido respondida/adiada."""
    kwargs = {"embed": embed, "ephemeral": ephemeral}
    if view is not None:
        kwargs["view"] = view
    if interaction.response.is_done():
        await interaction.followup.send(**kwargs)
    else:
        await interaction.response.send_message(**kwargs)


class PolyBattleBot(commands.Bot):
    def __init__(self, settings: Settings) -> None:
        intents = discord.Intents.default()
        intents.members = True           # privilegiado: boas-vindas, cargos, anti-raid
        intents.message_content = True   # privilegiado: automod e logs de mensagens
        super().__init__(
            command_prefix=commands.when_mentioned,
            intents=intents,
            help_command=None,
            allowed_mentions=discord.AllowedMentions(everyone=False, roles=False, users=True,
                                                     replied_user=False),
            activity=discord.Activity(type=discord.ActivityType.watching, name="the battlefield"),
        )
        self.settings = settings
        self.db = Database(settings.database_path)
        # cache: guild_id -> {(kind, key): discord_id}
        self._resources: dict[int, dict[tuple[str, str], int]] = {}
        # servidores em manutenção (/setup em andamento): logs de eventos ficam silenciados
        self.quiet_guilds: set[int] = set()

    # ------------------------------------------------------------------ inicialização
    async def setup_hook(self) -> None:
        await self.db.connect()
        self.tree.on_error = self.on_tree_error  # type: ignore[assignment]
        for ext in EXTENSIONS:
            await self.load_extension(ext)
            log.info("Extensão carregada: %s", ext)

        if self.settings.guild_id:
            guild = discord.Object(id=self.settings.guild_id)
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            log.info("%d comandos sincronizados no servidor %s", len(synced), self.settings.guild_id)
        else:
            synced = await self.tree.sync()
            log.info("%d comandos sincronizados globalmente (pode levar até 1h para aparecer)", len(synced))

    async def on_ready(self) -> None:
        assert self.user is not None
        log.info("Conectado como %s (%s) em %d servidor(es)", self.user, self.user.id, len(self.guilds))
        for guild in self.guilds:
            await self.refresh_resources(guild.id)

    async def close(self) -> None:
        await super().close()
        await self.db.close()

    # ------------------------------------------------------------------ recursos do blueprint
    async def refresh_resources(self, guild_id: int) -> None:
        self._resources[guild_id] = await self.db.all_resources(guild_id)

    def _resource_id(self, guild_id: int, kind: str, key: str) -> int | None:
        return self._resources.get(guild_id, {}).get((kind, key))

    def role(self, guild: discord.Guild, key: str) -> discord.Role | None:
        rid = self._resource_id(guild.id, "role", key)
        return guild.get_role(rid) if rid else None

    def channel(self, guild: discord.Guild, key: str):
        cid = self._resource_id(guild.id, "channel", key)
        return guild.get_channel(cid) if cid else None

    def category(self, guild: discord.Guild, key: str) -> discord.CategoryChannel | None:
        cid = self._resource_id(guild.id, "category", key)
        ch = guild.get_channel(cid) if cid else None
        return ch if isinstance(ch, discord.CategoryChannel) else None

    def channel_map(self, guild_id: int) -> dict[str, int]:
        return {key: did for (kind, key), did in self._resources.get(guild_id, {}).items()
                if kind == "channel"}

    def is_setup(self, guild_id: int) -> bool:
        return bool(self._resources.get(guild_id))

    def member_has_any(self, member: discord.Member, role_keys: Iterable[str]) -> bool:
        wanted = {self._resource_id(member.guild.id, "role", k) for k in role_keys}
        wanted.discard(None)
        return any(r.id in wanted for r in member.roles)

    def is_staff(self, member: discord.Member) -> bool:
        return (member.guild_permissions.administrator
                or member.id == member.guild.owner_id
                or self.member_has_any(member, bp.STAFF_ROLES))

    # ------------------------------------------------------------------ logs
    async def send_log(self, guild: discord.Guild, embed: discord.Embed, *,
                       file: discord.File | None = None, channel_key: str = "staff_logs") -> None:
        """Envia um registro para o canal de logs da staff. Nunca levanta exceção."""
        channel = self.channel(guild, channel_key)
        if not isinstance(channel, discord.TextChannel):
            return
        try:
            if file is not None:
                await channel.send(embed=embed, file=file)
            else:
                await channel.send(embed=embed)
        except discord.HTTPException as exc:
            log.warning("Falha ao enviar log em %s: %s", guild.id, exc)

    # ------------------------------------------------------------------ erros
    async def on_tree_error(self, interaction: discord.Interaction,
                            error: app_commands.AppCommandError) -> None:
        original = getattr(error, "original", error)
        if isinstance(error, MissingStaffRole):
            msg = f"Você não tem permissão para usar este comando.\n-# {error}"
        elif isinstance(error, SetupRequired):
            msg = ("O servidor ainda não foi configurado. Um administrador deve executar `/setup install`.\n"
                   "-# Server not configured yet. An admin must run /setup install.")
        elif isinstance(error, app_commands.MissingPermissions):
            msg = "Você não tem as permissões necessárias: " + ", ".join(error.missing_permissions)
        elif isinstance(error, app_commands.BotMissingPermissions):
            msg = "O bot não tem as permissões necessárias: " + ", ".join(error.missing_permissions)
        elif isinstance(error, app_commands.CommandOnCooldown):
            msg = f"Aguarde {error.retry_after:.0f}s para usar este comando novamente."
        elif isinstance(error, app_commands.NoPrivateMessage):
            msg = "Este comando só pode ser usado dentro do servidor."
        elif isinstance(error, app_commands.CheckFailure):
            msg = "Você não pode usar este comando aqui."
        elif isinstance(original, discord.Forbidden):
            msg = ("O Discord recusou a ação por falta de permissão. Verifique se o cargo do bot está "
                   "acima dos cargos envolvidos.")
            log.warning("Forbidden em /%s: %s", getattr(interaction.command, "qualified_name", "?"), original)
        else:
            msg = "Ocorreu um erro inesperado. A equipe foi notificada."
            log.error(
                "Erro no comando /%s:\n%s",
                getattr(interaction.command, "qualified_name", "?"),
                "".join(traceback.format_exception(type(original), original, original.__traceback__)),
            )
        try:
            await respond(interaction, ui.error(msg))
        except discord.HTTPException:
            pass


async def handle_component_error(interaction: discord.Interaction, error: Exception, where: str) -> None:
    """Tratamento padrão de erros de Views e Modals."""
    if isinstance(error, discord.Forbidden):
        msg = "O bot não tem permissão para concluir esta ação. Avise a equipe."
        log.warning("Forbidden em %s: %s", where, error)
    else:
        msg = "Ocorreu um erro inesperado. Tente novamente em instantes."
        log.error("Erro em %s:\n%s", where,
                  "".join(traceback.format_exception(type(error), error, error.__traceback__)))
    try:
        await respond(interaction, ui.error(msg))
    except discord.HTTPException:
        pass


class BaseView(discord.ui.View):
    async def on_error(self, interaction: discord.Interaction, error: Exception,
                       item: discord.ui.Item) -> None:
        await handle_component_error(interaction, error, f"{type(self).__name__}/{getattr(item, 'custom_id', item)}")


class BaseModal(discord.ui.Modal):
    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:  # type: ignore[override]
        await handle_component_error(interaction, error, type(self).__name__)


# ---------------------------------------------------------------------- checks de comandos
def require_roles(*role_keys: str):
    """
    Check para slash commands: exige um dos cargos do blueprint.
    Donos do servidor e membros com permissão de Administrador sempre passam.
    """
    async def predicate(interaction: discord.Interaction) -> bool:
        if interaction.guild is None or not isinstance(interaction.user, discord.Member):
            raise app_commands.NoPrivateMessage()
        bot: PolyBattleBot = interaction.client  # type: ignore[assignment]
        member = interaction.user
        if member.id == interaction.guild.owner_id or member.guild_permissions.administrator:
            return True
        if not bot.is_setup(interaction.guild.id):
            raise SetupRequired()
        if bot.member_has_any(member, role_keys):
            return True
        raise MissingStaffRole(role_keys)
    return app_commands.check(predicate)


def require_setup():
    async def predicate(interaction: discord.Interaction) -> bool:
        if interaction.guild is None:
            raise app_commands.NoPrivateMessage()
        bot: PolyBattleBot = interaction.client  # type: ignore[assignment]
        if not bot.is_setup(interaction.guild.id):
            raise SetupRequired()
        return True
    return app_commands.check(predicate)


def hierarchy_error(actor: discord.Member, target: discord.Member, me: discord.Member) -> str | None:
    """
    Valida a hierarquia antes de uma punição. Retorna a mensagem de erro ou None se permitido.
    """
    guild = actor.guild
    if target.id == actor.id:
        return "Você não pode aplicar esta ação em si mesmo."
    if target.id == guild.owner_id:
        return "Não é possível punir o dono do servidor."
    if target.id == me.id:
        return "Não é possível aplicar esta ação no próprio bot."
    if actor.id != guild.owner_id and target.top_role >= actor.top_role:
        return "O alvo possui um cargo igual ou superior ao seu."
    if target.top_role >= me.top_role:
        return "O cargo do alvo está acima (ou no mesmo nível) do cargo do bot."
    return None
