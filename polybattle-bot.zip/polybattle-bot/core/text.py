"""Funções utilitárias puras (sem discord.py) — testáveis isoladamente."""

from __future__ import annotations

import re

_REF_RE = re.compile(r"<#([a-z_][a-z0-9_]*)>")
_DURATION_RE = re.compile(r"(\d+)\s*(s|m|h|d|w)", re.IGNORECASE)
_UNITS = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}

MAX_TIMEOUT_SECONDS = 28 * 86400  # limite do Discord para timeout


def resolve_channel_refs(text: str, channels: dict[str, int]) -> str:
    """
    Troca referências simbólicas ``<#chave>`` pelo mention real ``<#123>``.
    Referências desconhecidas viram ``#chave`` (texto simples) em vez de um link quebrado.
    """
    def repl(match: re.Match[str]) -> str:
        key = match.group(1)
        cid = channels.get(key)
        return f"<#{cid}>" if cid else f"#{key.replace('_', '-')}"
    return _REF_RE.sub(repl, text)


def parse_duration(raw: str) -> int | None:
    """
    Converte '30s', '10m', '2h', '1d', '1w' ou combinações ('1h30m') em segundos.
    Retorna None se o formato for inválido.
    """
    raw = (raw or "").strip().lower().replace(" ", "")
    if not raw:
        return None
    pos = 0
    total = 0
    for match in _DURATION_RE.finditer(raw):
        if match.start() != pos:
            return None
        total += int(match.group(1)) * _UNITS[match.group(2).lower()]
        pos = match.end()
    if pos != len(raw) or total <= 0:
        return None
    return total


def format_duration(seconds: int | float | None) -> str:
    if not seconds:
        return "—"
    seconds = int(seconds)
    parts = []
    for label, size in (("d", 86400), ("h", 3600), ("m", 60), ("s", 1)):
        value, seconds = divmod(seconds, size)
        if value:
            parts.append(f"{value}{label}")
    return " ".join(parts) or "0s"


def truncate(text: str | None, limit: int) -> str:
    text = text or ""
    return text if len(text) <= limit else text[: max(0, limit - 1)] + "…"


def bi(pt: str, en: str) -> str:
    """Mensagem bilíngue: português em destaque e inglês em subtexto."""
    return f"{pt}\n-# {en}"


def slugify_username(name: str, max_len: int = 20) -> str:
    """Nome seguro para canais de ticket (minúsculas, a-z0-9 e hífens)."""
    slug = re.sub(r"[^a-z0-9]+", "-", (name or "").lower()).strip("-")
    return (slug or "user")[:max_len].strip("-") or "user"
