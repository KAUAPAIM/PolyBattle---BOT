"""
Regras do automod (lógica pura, sem discord.py — coberta por testes).

* Flood: muitas mensagens em pouco tempo.
* Spam: a mesma mensagem repetida várias vezes.
* Convites de outros servidores Discord.
* Links maliciosos: blocklist do servidor, domínios punycode, frases típicas de
  golpe e domínios que imitam marcas (ex.: "dlscord-gift", "rob1ox").
"""

from __future__ import annotations

import re
from collections import deque
from dataclasses import dataclass, field

INVITE_RE = re.compile(
    r"(?:https?://)?(?:www\.)?(?:discord(?:app)?\.com/invite|discord\.gg|dsc\.gg|invite\.gg)/[\w-]+",
    re.IGNORECASE,
)
URL_RE = re.compile(r"(?:https?://|www\.)([^\s/<>\"'?#]+)", re.IGNORECASE)

OFFICIAL_DOMAINS: frozenset[str] = frozenset({
    "discord.com", "discord.gg", "discordapp.com", "discordapp.net", "discord.media", "discord.dev",
    "discordstatus.com", "roblox.com", "rbxcdn.com", "roblox.qq.com", "robloxdev.com",
    "steamcommunity.com", "steampowered.com", "steamstatic.com", "steamdb.info",
    "youtube.com", "youtu.be", "twitch.tv", "x.com", "twitter.com", "tiktok.com", "medal.tv",
    "imgur.com", "gyazo.com", "tenor.com", "giphy.com", "github.com", "google.com",
})

BRAND_TOKENS: tuple[str, ...] = ("discord", "steam", "roblox", "nitro")

SCAM_PHRASES: tuple[re.Pattern[str], ...] = (
    re.compile(r"free\s*(discord\s*)?nitro", re.IGNORECASE),
    re.compile(r"nitro\s*(de\s*)?gr[aá]tis", re.IGNORECASE),
    re.compile(r"steam\s*gift", re.IGNORECASE),
    re.compile(r"free\s*robux", re.IGNORECASE),
    re.compile(r"robux\s*gr[aá]tis", re.IGNORECASE),
)

_LEET = str.maketrans({"0": "o", "1": "i", "l": "i", "3": "e", "4": "a", "5": "s", "7": "t", "@": "a", "$": "s"})


def _normalize(text: str) -> str:
    text = text.lower().replace("rn", "m").replace("vv", "w")
    return text.translate(_LEET)


_NORMALIZED_BRANDS = tuple(_normalize(b) for b in BRAND_TOKENS)


def extract_domains(text: str) -> list[str]:
    domains = []
    for match in URL_RE.finditer(text or ""):
        host = match.group(1).lower().rstrip(".")
        host = host.split("@")[-1].split(":")[0]
        if host.startswith("www."):
            host = host[4:]
        if "." in host:
            domains.append(host)
    return domains


def has_invite(text: str) -> bool:
    return bool(INVITE_RE.search(text or ""))


def _matches(domain: str, base: str) -> bool:
    return domain == base or domain.endswith("." + base)


def is_official(domain: str) -> bool:
    return any(_matches(domain, d) for d in OFFICIAL_DOMAINS)


@dataclass(frozen=True)
class LinkVerdict:
    severity: str   # "malicious" | "suspicious"
    domain: str
    reason: str


def check_links(text: str, blocklist: set[str] | frozenset[str] = frozenset()) -> LinkVerdict | None:
    """Analisa os links da mensagem. Retorna o veredito mais grave encontrado ou None."""
    domains = extract_domains(text)
    if not domains:
        return None
    scam_text = any(p.search(text) for p in SCAM_PHRASES)
    suspicious: LinkVerdict | None = None
    for domain in domains:
        if any(_matches(domain, b) for b in blocklist):
            return LinkVerdict("malicious", domain, "domínio na blocklist do servidor")
        if "xn--" in domain:
            return LinkVerdict("malicious", domain, "domínio punycode (possível imitação)")
        if is_official(domain):
            continue
        if scam_text:
            return LinkVerdict("malicious", domain, "link com frase típica de golpe")
        norm = _normalize(domain)
        for brand, raw in zip(_NORMALIZED_BRANDS, BRAND_TOKENS, strict=True):
            if brand in norm and suspicious is None:
                suspicious = LinkVerdict("suspicious", domain, f"domínio imita '{raw}'")
    return suspicious


def count_mentions(user_mentions: int, role_mentions: int, mentions_everyone_attempt: bool) -> int:
    return user_mentions + role_mentions + (5 if mentions_everyone_attempt else 0)


@dataclass
class _Entry:
    ts: float
    content: str
    channel_id: int
    message_id: int


@dataclass
class MessageTracker:
    """Janela deslizante de mensagens por usuário para detectar flood e spam."""

    flood_messages: int
    flood_seconds: float
    duplicate_messages: int
    duplicate_seconds: float
    _history: dict[tuple[int, int], deque[_Entry]] = field(default_factory=dict)

    def add(self, guild_id: int, user_id: int, ts: float, content: str, channel_id: int,
            message_id: int) -> str | None:
        """Registra a mensagem e retorna 'flood', 'duplicate' ou None."""
        key = (guild_id, user_id)
        window = max(self.flood_seconds, self.duplicate_seconds)
        hist = self._history.setdefault(key, deque(maxlen=50))
        while hist and ts - hist[0].ts > window:
            hist.popleft()
        hist.append(_Entry(ts, content.strip().lower(), channel_id, message_id))

        recent = [e for e in hist if ts - e.ts <= self.flood_seconds]
        if len(recent) >= self.flood_messages:
            return "flood"
        normalized = content.strip().lower()
        if normalized:
            dupes = [e for e in hist if ts - e.ts <= self.duplicate_seconds and e.content == normalized]
            if len(dupes) >= self.duplicate_messages:
                return "duplicate"
        return None

    def recent_messages(self, guild_id: int, user_id: int, ts: float, seconds: float) -> list[tuple[int, int]]:
        """(channel_id, message_id) das mensagens recentes — usado para limpar o flood."""
        return [(e.channel_id, e.message_id) for e in self._history.get((guild_id, user_id), ())
                if ts - e.ts <= seconds]

    def reset(self, guild_id: int, user_id: int) -> None:
        self._history.pop((guild_id, user_id), None)

    def prune(self, now: float) -> None:
        window = max(self.flood_seconds, self.duplicate_seconds)
        for key in [k for k, h in self._history.items() if not h or now - h[-1].ts > window]:
            self._history.pop(key, None)


@dataclass
class JoinRateMonitor:
    """Detecta picos de entrada (raid)."""

    threshold: int
    seconds: float
    _joins: dict[int, deque[float]] = field(default_factory=dict)

    def add(self, guild_id: int, ts: float) -> bool:
        q = self._joins.setdefault(guild_id, deque())
        q.append(ts)
        while q and ts - q[0] > self.seconds:
            q.popleft()
        return len(q) >= self.threshold

    def reset(self, guild_id: int) -> None:
        self._joins.pop(guild_id, None)
