"""Construtores de embeds com a identidade visual do PolyBattle."""

from __future__ import annotations

import datetime as dt

import discord

from core import blueprint as bp
from core.content import FOOTER
from core.text import truncate


def _now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def brand(title: str | None = None, description: str | None = None, *,
          color: int = bp.COLOR_GREEN, timestamp: bool = True) -> discord.Embed:
    embed = discord.Embed(
        title=truncate(title, 256) if title else None,
        description=truncate(description, 4096) if description else None,
        color=color,
        timestamp=_now() if timestamp else None,
    )
    embed.set_footer(text=FOOTER)
    return embed


def success(description: str, title: str = "✅ Operação concluída | Done") -> discord.Embed:
    return brand(title, description, color=bp.COLOR_GREEN_LIGHT, timestamp=False)


def error(description: str, title: str = "⛔ Erro | Error") -> discord.Embed:
    return brand(title, description, color=bp.COLOR_DANGER, timestamp=False)


def warning(description: str, title: str = "⚠️ Atenção | Warning") -> discord.Embed:
    return brand(title, description, color=bp.COLOR_WARNING, timestamp=False)


def log_embed(title: str, description: str | None = None, *, color: int = bp.COLOR_GRAY,
              user: discord.abc.User | None = None) -> discord.Embed:
    embed = brand(title, description, color=color)
    if user is not None:
        embed.set_author(name=f"{user} ({user.id})", icon_url=user.display_avatar.url)
    return embed


def user_field(user: discord.abc.User | None) -> str:
    if user is None:
        return "—"
    return f"{user.mention} `{user}` (`{user.id}`)"
