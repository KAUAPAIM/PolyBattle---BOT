"""
Camada de acesso ao banco SQLite.

Usa o módulo ``sqlite3`` da biblioteca padrão. Todas as operações rodam em
uma thread separada (``asyncio.to_thread``) protegidas por um lock, para não
bloquear o event loop do bot. O schema é criado/migrado automaticamente na
primeira conexão (``PRAGMA user_version``).
"""

from __future__ import annotations

import asyncio
import logging
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Iterable

log = logging.getLogger("polybattle.db")

SCHEMA_VERSION = 1

SCHEMA = """
CREATE TABLE IF NOT EXISTS guild_config (
    guild_id   INTEGER NOT NULL,
    key        TEXT    NOT NULL,
    value      TEXT,
    PRIMARY KEY (guild_id, key)
);

-- Mapeamento entre as chaves do blueprint e os IDs reais no Discord.
-- Impede a duplicação de cargos/canais em execuções repetidas do /setup.
CREATE TABLE IF NOT EXISTS resources (
    guild_id   INTEGER NOT NULL,
    kind       TEXT    NOT NULL CHECK (kind IN ('role', 'category', 'channel')),
    key        TEXT    NOT NULL,
    discord_id INTEGER NOT NULL,
    PRIMARY KEY (guild_id, kind, key)
);

CREATE TABLE IF NOT EXISTS panels (
    guild_id   INTEGER NOT NULL,
    key        TEXT    NOT NULL,
    channel_id INTEGER NOT NULL,
    message_id INTEGER NOT NULL,
    PRIMARY KEY (guild_id, key)
);

CREATE TABLE IF NOT EXISTS tickets (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id     INTEGER NOT NULL,
    channel_id   INTEGER UNIQUE,
    user_id      INTEGER NOT NULL,
    ticket_type  TEXT    NOT NULL,
    subject      TEXT,
    status       TEXT    NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed')),
    claimed_by   INTEGER,
    opened_at    REAL    NOT NULL,
    closed_at    REAL,
    closed_by    INTEGER,
    close_reason TEXT
);
CREATE INDEX IF NOT EXISTS idx_tickets_user ON tickets (guild_id, user_id, status);

CREATE TABLE IF NOT EXISTS warnings (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id     INTEGER NOT NULL,
    user_id      INTEGER NOT NULL,
    moderator_id INTEGER NOT NULL,
    reason       TEXT    NOT NULL,
    created_at   REAL    NOT NULL,
    active       INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_warnings_user ON warnings (guild_id, user_id, active);

CREATE TABLE IF NOT EXISTS mod_actions (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id     INTEGER NOT NULL,
    action       TEXT    NOT NULL,
    target_id    INTEGER NOT NULL,
    moderator_id INTEGER NOT NULL,
    reason       TEXT,
    duration_s   INTEGER,
    created_at   REAL    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_mod_actions_target ON mod_actions (guild_id, target_id);

CREATE TABLE IF NOT EXISTS suggestions (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id     INTEGER NOT NULL,
    channel_id   INTEGER,
    message_id   INTEGER UNIQUE,
    author_id    INTEGER NOT NULL,
    title        TEXT    NOT NULL,
    content      TEXT    NOT NULL,
    status       TEXT    NOT NULL DEFAULT 'pending'
                 CHECK (status IN ('pending', 'approved', 'denied', 'implemented')),
    staff_id     INTEGER,
    staff_reason TEXT,
    created_at   REAL    NOT NULL
);

CREATE TABLE IF NOT EXISTS suggestion_votes (
    suggestion_id INTEGER NOT NULL REFERENCES suggestions (id) ON DELETE CASCADE,
    user_id       INTEGER NOT NULL,
    vote          INTEGER NOT NULL CHECK (vote IN (-1, 1)),
    PRIMARY KEY (suggestion_id, user_id)
);

CREATE TABLE IF NOT EXISTS reports (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id     INTEGER NOT NULL,
    reporter_id  INTEGER NOT NULL,
    target_text  TEXT    NOT NULL,
    target_id    INTEGER,
    reason       TEXT    NOT NULL,
    evidence     TEXT,
    source       TEXT    NOT NULL DEFAULT 'panel',
    status       TEXT    NOT NULL DEFAULT 'open'
                 CHECK (status IN ('open', 'reviewing', 'resolved', 'rejected')),
    message_id   INTEGER UNIQUE,
    handled_by   INTEGER,
    created_at   REAL    NOT NULL
);

CREATE TABLE IF NOT EXISTS link_blocklist (
    guild_id INTEGER NOT NULL,
    domain   TEXT    NOT NULL,
    added_by INTEGER,
    PRIMARY KEY (guild_id, domain)
);

CREATE TABLE IF NOT EXISTS bot_state (
    key   TEXT PRIMARY KEY,
    value TEXT
);
"""


class Database:
    """Wrapper assíncrono e thread-safe sobre uma conexão SQLite."""

    def __init__(self, path: Path | str) -> None:
        self.path = Path(path)
        self._conn: sqlite3.Connection | None = None
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ ciclo de vida
    def connect_sync(self) -> None:
        if self.path != Path(":memory:"):
            self.path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self.path), check_same_thread=False, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        if self.path != Path(":memory:"):
            conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA busy_timeout = 5000")
        self._conn = conn
        self._migrate()
        log.info("Banco de dados pronto em %s", self.path)

    async def connect(self) -> None:
        await asyncio.to_thread(self.connect_sync)

    async def close(self) -> None:
        if self._conn is not None:
            with self._lock:
                self._conn.close()
                self._conn = None

    def _migrate(self) -> None:
        assert self._conn is not None
        with self._lock:
            current = self._conn.execute("PRAGMA user_version").fetchone()[0]
            if current < SCHEMA_VERSION:
                self._conn.executescript(SCHEMA)
                self._conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
                log.info("Schema migrado de v%s para v%s", current, SCHEMA_VERSION)

    # ------------------------------------------------------------------ primitivas
    def _run(self, sql: str, params: Iterable[Any] = (), *, fetch: str | None = None) -> Any:
        if self._conn is None:
            raise RuntimeError("Banco de dados não conectado")
        with self._lock:
            cur = self._conn.execute(sql, tuple(params))
            if fetch == "one":
                return cur.fetchone()
            if fetch == "all":
                return cur.fetchall()
            return cur.lastrowid

    async def execute(self, sql: str, *params: Any) -> int:
        """Executa e retorna o lastrowid."""
        return await asyncio.to_thread(self._run, sql, params)

    async def fetchone(self, sql: str, *params: Any) -> sqlite3.Row | None:
        return await asyncio.to_thread(self._run, sql, params, fetch="one")

    async def fetchall(self, sql: str, *params: Any) -> list[sqlite3.Row]:
        return await asyncio.to_thread(self._run, sql, params, fetch="all")

    # ------------------------------------------------------------------ config
    async def get_config(self, guild_id: int, key: str, default: str | None = None) -> str | None:
        row = await self.fetchone(
            "SELECT value FROM guild_config WHERE guild_id = ? AND key = ?", guild_id, key
        )
        return row["value"] if row else default

    async def set_config(self, guild_id: int, key: str, value: str | None) -> None:
        await self.execute(
            "INSERT INTO guild_config (guild_id, key, value) VALUES (?, ?, ?) "
            "ON CONFLICT (guild_id, key) DO UPDATE SET value = excluded.value",
            guild_id, key, value,
        )

    # ------------------------------------------------------------------ recursos (cargos/canais)
    async def get_resource(self, guild_id: int, kind: str, key: str) -> int | None:
        row = await self.fetchone(
            "SELECT discord_id FROM resources WHERE guild_id = ? AND kind = ? AND key = ?",
            guild_id, kind, key,
        )
        return int(row["discord_id"]) if row else None

    async def set_resource(self, guild_id: int, kind: str, key: str, discord_id: int) -> None:
        await self.execute(
            "INSERT INTO resources (guild_id, kind, key, discord_id) VALUES (?, ?, ?, ?) "
            "ON CONFLICT (guild_id, kind, key) DO UPDATE SET discord_id = excluded.discord_id",
            guild_id, kind, key, discord_id,
        )

    async def all_resources(self, guild_id: int) -> dict[tuple[str, str], int]:
        rows = await self.fetchall(
            "SELECT kind, key, discord_id FROM resources WHERE guild_id = ?", guild_id
        )
        return {(r["kind"], r["key"]): int(r["discord_id"]) for r in rows}

    # ------------------------------------------------------------------ painéis
    async def get_panel(self, guild_id: int, key: str) -> sqlite3.Row | None:
        return await self.fetchone(
            "SELECT channel_id, message_id FROM panels WHERE guild_id = ? AND key = ?", guild_id, key
        )

    async def set_panel(self, guild_id: int, key: str, channel_id: int, message_id: int) -> None:
        await self.execute(
            "INSERT INTO panels (guild_id, key, channel_id, message_id) VALUES (?, ?, ?, ?) "
            "ON CONFLICT (guild_id, key) DO UPDATE SET channel_id = excluded.channel_id, "
            "message_id = excluded.message_id",
            guild_id, key, channel_id, message_id,
        )

    # ------------------------------------------------------------------ tickets
    async def create_ticket(self, guild_id: int, user_id: int, ticket_type: str, subject: str) -> int:
        return await self.execute(
            "INSERT INTO tickets (guild_id, user_id, ticket_type, subject, opened_at) VALUES (?, ?, ?, ?, ?)",
            guild_id, user_id, ticket_type, subject, time.time(),
        )

    async def set_ticket_channel(self, ticket_id: int, channel_id: int) -> None:
        await self.execute("UPDATE tickets SET channel_id = ? WHERE id = ?", channel_id, ticket_id)

    async def delete_ticket(self, ticket_id: int) -> None:
        await self.execute("DELETE FROM tickets WHERE id = ?", ticket_id)

    async def get_ticket_by_channel(self, channel_id: int) -> sqlite3.Row | None:
        return await self.fetchone("SELECT * FROM tickets WHERE channel_id = ?", channel_id)

    async def count_open_tickets(self, guild_id: int, user_id: int) -> int:
        row = await self.fetchone(
            "SELECT COUNT(*) AS n FROM tickets WHERE guild_id = ? AND user_id = ? AND status = 'open'",
            guild_id, user_id,
        )
        return int(row["n"])

    async def open_tickets(self, guild_id: int) -> list[sqlite3.Row]:
        return await self.fetchall(
            "SELECT * FROM tickets WHERE guild_id = ? AND status = 'open'", guild_id
        )

    async def claim_ticket(self, ticket_id: int, staff_id: int) -> None:
        await self.execute("UPDATE tickets SET claimed_by = ? WHERE id = ?", staff_id, ticket_id)

    async def close_ticket(self, ticket_id: int, closed_by: int, reason: str | None) -> bool:
        """Fecha o ticket. Retorna False se já estava fechado (evita fechamento duplo)."""
        def _close() -> bool:
            assert self._conn is not None
            with self._lock:
                cur = self._conn.execute(
                    "UPDATE tickets SET status = 'closed', closed_at = ?, closed_by = ?, close_reason = ? "
                    "WHERE id = ? AND status = 'open'",
                    (time.time(), closed_by, reason, ticket_id),
                )
                return cur.rowcount == 1
        return await asyncio.to_thread(_close)

    # ------------------------------------------------------------------ avisos / ações
    async def add_warning(self, guild_id: int, user_id: int, moderator_id: int, reason: str) -> int:
        return await self.execute(
            "INSERT INTO warnings (guild_id, user_id, moderator_id, reason, created_at) VALUES (?, ?, ?, ?, ?)",
            guild_id, user_id, moderator_id, reason, time.time(),
        )

    async def active_warnings(self, guild_id: int, user_id: int) -> list[sqlite3.Row]:
        return await self.fetchall(
            "SELECT * FROM warnings WHERE guild_id = ? AND user_id = ? AND active = 1 ORDER BY id",
            guild_id, user_id,
        )

    async def remove_warning(self, guild_id: int, warning_id: int) -> bool:
        def _rm() -> bool:
            assert self._conn is not None
            with self._lock:
                cur = self._conn.execute(
                    "UPDATE warnings SET active = 0 WHERE guild_id = ? AND id = ? AND active = 1",
                    (guild_id, warning_id),
                )
                return cur.rowcount == 1
        return await asyncio.to_thread(_rm)

    async def clear_warnings(self, guild_id: int, user_id: int) -> int:
        def _clear() -> int:
            assert self._conn is not None
            with self._lock:
                cur = self._conn.execute(
                    "UPDATE warnings SET active = 0 WHERE guild_id = ? AND user_id = ? AND active = 1",
                    (guild_id, user_id),
                )
                return cur.rowcount
        return await asyncio.to_thread(_clear)

    async def log_action(
        self, guild_id: int, action: str, target_id: int, moderator_id: int,
        reason: str | None, duration_s: int | None = None,
    ) -> int:
        return await self.execute(
            "INSERT INTO mod_actions (guild_id, action, target_id, moderator_id, reason, duration_s, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            guild_id, action, target_id, moderator_id, reason, duration_s, time.time(),
        )

    async def actions_for(self, guild_id: int, target_id: int, limit: int = 10) -> list[sqlite3.Row]:
        return await self.fetchall(
            "SELECT * FROM mod_actions WHERE guild_id = ? AND target_id = ? ORDER BY id DESC LIMIT ?",
            guild_id, target_id, limit,
        )

    # ------------------------------------------------------------------ sugestões
    async def create_suggestion(self, guild_id: int, author_id: int, title: str, content: str) -> int:
        return await self.execute(
            "INSERT INTO suggestions (guild_id, author_id, title, content, created_at) VALUES (?, ?, ?, ?, ?)",
            guild_id, author_id, title, content, time.time(),
        )

    async def set_suggestion_message(self, suggestion_id: int, channel_id: int, message_id: int) -> None:
        await self.execute(
            "UPDATE suggestions SET channel_id = ?, message_id = ? WHERE id = ?",
            channel_id, message_id, suggestion_id,
        )

    async def get_suggestion(self, guild_id: int, suggestion_id: int) -> sqlite3.Row | None:
        return await self.fetchone(
            "SELECT * FROM suggestions WHERE guild_id = ? AND id = ?", guild_id, suggestion_id
        )

    async def get_suggestion_by_message(self, message_id: int) -> sqlite3.Row | None:
        return await self.fetchone("SELECT * FROM suggestions WHERE message_id = ?", message_id)

    async def vote_suggestion(self, suggestion_id: int, user_id: int, vote: int) -> str:
        """
        Registra/alterna um voto. Retorna 'added', 'changed' ou 'removed'
        (clicar duas vezes no mesmo botão remove o voto).
        """
        if vote not in (-1, 1):
            raise ValueError("vote deve ser -1 ou 1")

        def _vote() -> str:
            assert self._conn is not None
            with self._lock:
                row = self._conn.execute(
                    "SELECT vote FROM suggestion_votes WHERE suggestion_id = ? AND user_id = ?",
                    (suggestion_id, user_id),
                ).fetchone()
                if row is None:
                    self._conn.execute(
                        "INSERT INTO suggestion_votes (suggestion_id, user_id, vote) VALUES (?, ?, ?)",
                        (suggestion_id, user_id, vote),
                    )
                    return "added"
                if row["vote"] == vote:
                    self._conn.execute(
                        "DELETE FROM suggestion_votes WHERE suggestion_id = ? AND user_id = ?",
                        (suggestion_id, user_id),
                    )
                    return "removed"
                self._conn.execute(
                    "UPDATE suggestion_votes SET vote = ? WHERE suggestion_id = ? AND user_id = ?",
                    (vote, suggestion_id, user_id),
                )
                return "changed"
        return await asyncio.to_thread(_vote)

    async def suggestion_tally(self, suggestion_id: int) -> tuple[int, int]:
        row = await self.fetchone(
            "SELECT COALESCE(SUM(vote = 1), 0) AS up, COALESCE(SUM(vote = -1), 0) AS down "
            "FROM suggestion_votes WHERE suggestion_id = ?",
            suggestion_id,
        )
        return int(row["up"]), int(row["down"])

    async def set_suggestion_status(
        self, suggestion_id: int, status: str, staff_id: int, reason: str | None
    ) -> None:
        await self.execute(
            "UPDATE suggestions SET status = ?, staff_id = ?, staff_reason = ? WHERE id = ?",
            status, staff_id, reason, suggestion_id,
        )

    # ------------------------------------------------------------------ denúncias
    async def create_report(
        self, guild_id: int, reporter_id: int, target_text: str, target_id: int | None,
        reason: str, evidence: str | None, source: str,
    ) -> int:
        return await self.execute(
            "INSERT INTO reports (guild_id, reporter_id, target_text, target_id, reason, evidence, source, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            guild_id, reporter_id, target_text, target_id, reason, evidence, source, time.time(),
        )

    async def set_report_message(self, report_id: int, message_id: int) -> None:
        await self.execute("UPDATE reports SET message_id = ? WHERE id = ?", message_id, report_id)

    async def get_report_by_message(self, message_id: int) -> sqlite3.Row | None:
        return await self.fetchone("SELECT * FROM reports WHERE message_id = ?", message_id)

    async def set_report_status(self, report_id: int, status: str, staff_id: int) -> None:
        await self.execute(
            "UPDATE reports SET status = ?, handled_by = ? WHERE id = ?", status, staff_id, report_id
        )

    async def recent_reports_by(self, guild_id: int, reporter_id: int, since: float) -> int:
        row = await self.fetchone(
            "SELECT COUNT(*) AS n FROM reports WHERE guild_id = ? AND reporter_id = ? AND created_at >= ?",
            guild_id, reporter_id, since,
        )
        return int(row["n"])

    # ------------------------------------------------------------------ blocklist
    async def add_blocked_domain(self, guild_id: int, domain: str, added_by: int) -> bool:
        def _add() -> bool:
            assert self._conn is not None
            with self._lock:
                cur = self._conn.execute(
                    "INSERT OR IGNORE INTO link_blocklist (guild_id, domain, added_by) VALUES (?, ?, ?)",
                    (guild_id, domain, added_by),
                )
                return cur.rowcount == 1
        return await asyncio.to_thread(_add)

    async def remove_blocked_domain(self, guild_id: int, domain: str) -> bool:
        def _rm() -> bool:
            assert self._conn is not None
            with self._lock:
                cur = self._conn.execute(
                    "DELETE FROM link_blocklist WHERE guild_id = ? AND domain = ?", (guild_id, domain)
                )
                return cur.rowcount == 1
        return await asyncio.to_thread(_rm)

    async def blocked_domains(self, guild_id: int) -> set[str]:
        rows = await self.fetchall("SELECT domain FROM link_blocklist WHERE guild_id = ?", guild_id)
        return {r["domain"] for r in rows}

    # ------------------------------------------------------------------ estado global
    async def get_state(self, key: str) -> str | None:
        row = await self.fetchone("SELECT value FROM bot_state WHERE key = ?", key)
        return row["value"] if row else None

    async def set_state(self, key: str, value: str) -> None:
        await self.execute(
            "INSERT INTO bot_state (key, value) VALUES (?, ?) "
            "ON CONFLICT (key) DO UPDATE SET value = excluded.value",
            key, value,
        )
