"""
Gerador de transcript HTML de tickets (sem dependência de discord.py).

O cog de tickets converte as mensagens do canal em ``TranscriptMessage`` e
chama ``render_html``. O arquivo resultante é autossuficiente (CSS inline).
"""

from __future__ import annotations

import datetime as dt
import html
from dataclasses import dataclass, field


@dataclass
class TranscriptMessage:
    author: str
    author_id: int
    content: str
    created_at: dt.datetime
    is_bot: bool = False
    attachments: list[str] = field(default_factory=list)
    embeds: list[str] = field(default_factory=list)


_CSS = """
body{background:#0b0d0b;color:#e6e6e6;font-family:Segoe UI,Roboto,Arial,sans-serif;margin:0}
header{background:#151915;border-bottom:3px solid #4b6f2a;padding:20px 28px}
header h1{margin:0;font-size:20px;letter-spacing:2px;color:#f2f2f2}
header p{margin:4px 0 0;color:#9aa0a6;font-size:13px}
main{padding:16px 28px}
.msg{padding:10px 0;border-bottom:1px solid #1e231e}
.meta{font-size:13px;color:#9aa0a6}
.author{font-weight:600;color:#7fa650}
.bot{color:#c9a227}
.content{white-space:pre-wrap;word-wrap:break-word;margin-top:4px}
.embed{border-left:3px solid #4b6f2a;background:#151915;padding:6px 10px;margin-top:6px;font-size:13px}
a{color:#7fa650}
footer{color:#5f6368;font-size:12px;padding:16px 28px}
"""


def render_html(*, title: str, subtitle_lines: list[str], messages: list[TranscriptMessage],
                generated_at: dt.datetime | None = None) -> str:
    generated_at = generated_at or dt.datetime.now(dt.timezone.utc)
    esc = html.escape
    parts = [
        "<!DOCTYPE html><html lang='pt-BR'><head><meta charset='utf-8'>",
        f"<title>{esc(title)}</title><style>{_CSS}</style></head><body>",
        f"<header><h1>{esc(title)}</h1>",
        *(f"<p>{esc(line)}</p>" for line in subtitle_lines),
        "</header><main>",
    ]
    if not messages:
        parts.append("<p class='meta'>Nenhuma mensagem registrada.</p>")
    for m in messages:
        cls = "author bot" if m.is_bot else "author"
        stamp = m.created_at.astimezone(dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        parts.append("<div class='msg'>")
        parts.append(f"<div class='meta'><span class='{cls}'>{esc(m.author)}</span> "
                     f"<span>({m.author_id})</span> • {stamp}</div>")
        if m.content:
            parts.append(f"<div class='content'>{esc(m.content)}</div>")
        for e in m.embeds:
            parts.append(f"<div class='embed'>{esc(e)}</div>")
        for url in m.attachments:
            safe = esc(url, quote=True)
            if url.startswith("https://"):
                parts.append(f"<div class='meta'>📎 <a href='{safe}' rel='noopener noreferrer'>{safe}</a></div>")
            else:
                parts.append(f"<div class='meta'>📎 {safe}</div>")
        parts.append("</div>")
    parts.append(f"</main><footer>Gerado em {generated_at.strftime('%Y-%m-%d %H:%M:%S UTC')} • "
                 f"{len(messages)} mensagem(ns) • POLYBATTLE | OFFICIAL</footer></body></html>")
    return "".join(parts)
