"""Testes das partes puras: texto, automod, punições, transcript, blueprint e banco."""
from __future__ import annotations

import datetime as dt
import time

from conftest import run

from core import blueprint as bp
from core.automod_rules import JoinRateMonitor, MessageTracker, check_links, extract_domains, has_invite
from core.database import Database
from core.punishments import escalation_for
from core.text import bi, format_duration, parse_duration, resolve_channel_refs, slugify_username, truncate
from core.transcript import TranscriptMessage, render_html


# ---------------------------------------------------------------- texto
def test_parse_duration():
    assert parse_duration("30s") == 30
    assert parse_duration("10m") == 600
    assert parse_duration("1h30m") == 5400
    assert parse_duration("2d") == 172800
    assert parse_duration("1w") == 604800
    for bad in ("", "abc", "10", "10x", "m10", "0m", "1h abc"):
        assert parse_duration(bad) is None, bad


def test_format_and_truncate():
    assert format_duration(5400) == "1h 30m"
    assert format_duration(None) == "—"
    assert truncate("abcdef", 4) == "abc…"
    assert truncate(None, 3) == ""
    assert bi("pt", "en") == "pt\n-# en"


def test_resolve_refs_and_slug():
    out = resolve_channel_refs("Veja <#server_rules> e <#unknown_key>", {"server_rules": 42})
    assert out == "Veja <#42> e #unknown-key"
    assert resolve_channel_refs("<#123>", {}) == "<#123>"  # IDs reais não são alterados
    assert slugify_username("João_Silva!!") == "jo-o-silva"
    assert slugify_username("___") == "user"


# ---------------------------------------------------------------- automod
def test_invites():
    assert has_invite("entra aí discord.gg/abc123")
    assert has_invite("https://discord.com/invite/xyz")
    assert not has_invite("https://discord.com/channels/1/2")


def test_links():
    assert extract_domains("veja https://www.Example.com/path e www.test.org") == ["example.com", "test.org"]
    assert check_links("https://roblox.com/games/1") is None
    assert check_links("https://www.youtube.com/watch?v=x") is None
    v = check_links("pega aqui https://dlscord-gift.com/claim")
    assert v and v.severity == "suspicious"
    v = check_links("https://rob1ox-free.xyz")
    assert v and v.severity == "suspicious"
    v = check_links("FREE NITRO https://random-site.ru/x")
    assert v and v.severity == "malicious"
    v = check_links("https://xn--dscord-9ua.com")
    assert v and v.severity == "malicious"
    v = check_links("https://evil.example.net/a", {"example.net"})
    assert v and v.severity == "malicious" and v.domain == "evil.example.net"
    assert check_links("sem links aqui") is None


def test_flood_and_duplicates():
    t = MessageTracker(flood_messages=5, flood_seconds=5, duplicate_messages=3, duplicate_seconds=30)
    now = 1000.0
    results = [t.add(1, 7, now + i * 0.5, f"msg {i}", 10, i) for i in range(5)]
    assert results[:4] == [None] * 4 and results[4] == "flood"
    t.reset(1, 7)
    r = [t.add(1, 7, now + i * 3, "COMPRE JÁ", 10, 100 + i) for i in range(3)]
    assert r == [None, None, "duplicate"]
    assert len(t.recent_messages(1, 7, now + 6, 30)) == 3
    t.prune(now + 10_000)
    assert t.recent_messages(1, 7, now, 30) == []


def test_join_monitor():
    m = JoinRateMonitor(threshold=3, seconds=10)
    assert not m.add(1, 0) and not m.add(1, 1)
    assert m.add(1, 2)
    m.reset(1)
    assert not m.add(1, 100) and not m.add(1, 200) and not m.add(1, 300)


def test_escalation():
    kw = dict(timeout_at=3, kick_at=5, ban_at=0)
    assert escalation_for(2, **kw) is None
    assert escalation_for(3, **kw) == "timeout"
    assert escalation_for(5, **kw) == "kick"
    assert escalation_for(9, **kw) == "kick"
    assert escalation_for(7, timeout_at=3, kick_at=5, ban_at=7) == "ban"
    assert escalation_for(10, timeout_at=0, kick_at=0, ban_at=0) is None


# ---------------------------------------------------------------- transcript
def test_transcript_escapes_html():
    msgs = [TranscriptMessage("hacker", 1, "<script>alert(1)</script>", dt.datetime.now(dt.timezone.utc),
                              attachments=["https://cdn/x.png", "javascript:alert(1)"], embeds=["<b>x</b>"])]
    doc = render_html(title="Ticket #0001", subtitle_lines=["Autor: 1"], messages=msgs)
    assert "<script>" not in doc and "&lt;script&gt;" in doc
    assert "href='javascript" not in doc
    assert "href='https://cdn/x.png'" in doc
    assert "1 mensagem" in doc


# ---------------------------------------------------------------- blueprint
def test_blueprint_is_consistent():
    assert bp.validate_blueprint() == []
    assert [r.name for r in bp.ROLES] == [
        "Founder", "Owner", "Administrator", "Head Moderator", "Moderator", "Support Team", "Developer",
        "Builder", "Tester", "VIP", "Veteran", "Verified", "Member"]
    expected = {"announcements", "server_rules", "game_information", "changelog", "useful_links",
                "general_chat", "in_game_chat", "screenshots", "clips_and_highlights", "looking_for_team",
                "open_a_ticket", "bug_reports", "suggestions", "player_reports", "development_updates",
                "upcoming_features", "testing", "community_feedback", "voice_general", "voice_squad_01",
                "voice_squad_02", "voice_squad_03", "voice_squad_04", "staff_chat", "staff_logs",
                "staff_reports", "staff_announcements", "staff_voice"}
    assert expected <= set(bp.ALL_CHANNELS)


def test_staff_categories_hidden_from_everyone():
    for key in ("cat_staff", "cat_tickets", "cat_community", "cat_support", "cat_development", "cat_voice"):
        assert bp.CATEGORY_BY_KEY[key].overwrites["@everyone"]["view_channel"] is False
    staff = bp.CATEGORY_BY_KEY["cat_staff"].overwrites
    for key in ("verified", "member", "vip", "veteran", "developer", "builder", "tester"):
        assert key not in staff, key
    # Somente Founder/Owner possuem a flag administrator
    admins = [r.key for r in bp.ROLES if "administrator" in r.permissions]
    assert admins == ["founder", "owner"]
    # Cargos comunitários não têm permissões perigosas
    for key in ("vip", "veteran", "verified", "member", "developer", "builder", "tester", "support_team"):
        assert not (bp.ROLE_BY_KEY[key].permissions & bp.DANGEROUS_PERMS), key


def test_merge_overwrites():
    merged = bp.merge_overwrites({"@everyone": {"view_channel": False}, "verified": {"view_channel": True}},
                                 {"verified": {"send_messages": False}})
    assert merged == {"@everyone": {"view_channel": False},
                      "verified": {"view_channel": True, "send_messages": False}}


# ---------------------------------------------------------------- banco
def test_database(tmp_path):
    async def scenario():
        db = Database(tmp_path / "db" / "x.db")
        await db.connect()
        # migração idempotente
        db._migrate()

        await db.set_config(1, "k", "v")
        await db.set_config(1, "k", "v2")
        assert await db.get_config(1, "k") == "v2"
        assert await db.get_config(1, "missing", "d") == "d"

        await db.set_resource(1, "role", "founder", 10)
        await db.set_resource(1, "role", "founder", 11)
        assert await db.get_resource(1, "role", "founder") == 11
        assert await db.all_resources(1) == {("role", "founder"): 11}

        await db.set_panel(1, "verify", 5, 6)
        await db.set_panel(1, "verify", 5, 7)
        assert (await db.get_panel(1, "verify"))["message_id"] == 7

        tid = await db.create_ticket(1, 99, "general", "help")
        await db.set_ticket_channel(tid, 555)
        assert await db.count_open_tickets(1, 99) == 1
        assert (await db.get_ticket_by_channel(555))["id"] == tid
        assert await db.close_ticket(tid, 1, "ok") is True
        assert await db.close_ticket(tid, 1, "again") is False   # fechamento duplo bloqueado
        assert await db.count_open_tickets(1, 99) == 0

        w1 = await db.add_warning(1, 50, 2, "a")
        await db.add_warning(1, 50, 2, "b")
        assert len(await db.active_warnings(1, 50)) == 2
        assert await db.remove_warning(1, w1) is True
        assert await db.remove_warning(1, w1) is False
        assert await db.clear_warnings(1, 50) == 1
        assert await db.active_warnings(1, 50) == []

        await db.log_action(1, "ban", 50, 2, "x")
        assert (await db.actions_for(1, 50))[0]["action"] == "ban"

        sid = await db.create_suggestion(1, 3, "Título", "Conteúdo")
        assert await db.vote_suggestion(sid, 10, 1) == "added"
        assert await db.vote_suggestion(sid, 11, -1) == "added"
        assert await db.suggestion_tally(sid) == (1, 1)
        assert await db.vote_suggestion(sid, 10, -1) == "changed"
        assert await db.suggestion_tally(sid) == (0, 2)
        assert await db.vote_suggestion(sid, 10, -1) == "removed"
        assert await db.suggestion_tally(sid) == (0, 1)
        await db.set_suggestion_status(sid, "approved", 2, "boa")
        assert (await db.get_suggestion(1, sid))["status"] == "approved"

        rid = await db.create_report(1, 3, "alvo", None, "motivo", None, "panel")
        await db.set_report_message(rid, 777)
        assert (await db.get_report_by_message(777))["id"] == rid
        await db.set_report_status(rid, "resolved", 2)
        assert await db.recent_reports_by(1, 3, time.time() - 60) == 1

        assert await db.add_blocked_domain(1, "bad.com", 2) is True
        assert await db.add_blocked_domain(1, "bad.com", 2) is False
        assert await db.blocked_domains(1) == {"bad.com"}
        assert await db.remove_blocked_domain(1, "bad.com") is True

        await db.set_state("a", "1")
        assert await db.get_state("a") == "1"
        await db.close()

        # reabrir mantém os dados
        db2 = Database(tmp_path / "db" / "x.db")
        await db2.connect()
        assert await db2.get_config(1, "k") == "v2"
        await db2.close()

    run(scenario())
