"""Stub mínimo de aiohttp para os testes."""
class ClientError(Exception):
    pass


class ClientTimeout:
    def __init__(self, total=None):
        self.total = total


class ClientSession:
    def __init__(self, *a, **kw):
        self.closed = False

    async def close(self):
        self.closed = True

    def get(self, url):  # pragma: no cover - não usado nos testes
        raise ClientError("offline")
