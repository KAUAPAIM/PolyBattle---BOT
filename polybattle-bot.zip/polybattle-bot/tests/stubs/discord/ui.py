"""Stub de discord.ui: Views, botões, selects e modals em memória."""
from __future__ import annotations


class Item:
    def __init__(self) -> None:
        self.callback = None


class Button(Item):
    def __init__(self, *, label=None, style=None, emoji=None, custom_id=None, url=None, disabled=False):
        super().__init__()
        self.label, self.style, self.emoji = label, style, emoji
        self.custom_id, self.url, self.disabled = custom_id, url, disabled


class Select(Item):
    def __init__(self, *, custom_id=None, placeholder=None, min_values=1, max_values=1, options=None):
        super().__init__()
        self.custom_id, self.placeholder = custom_id, placeholder
        self.options = options or []
        self.values: list[str] = []


def _decorator(kind, **kw):
    def wrap(func):
        func.__ui_item__ = (kind, kw)
        return func
    return wrap


def button(**kw):
    return _decorator(Button, **kw)


def select(**kw):
    return _decorator(Select, **kw)


class View:
    def __init__(self, *, timeout=180) -> None:
        self.timeout = timeout
        self.children: list[Item] = []
        for name in dir(type(self)):
            func = getattr(type(self), name, None)
            spec = getattr(func, "__ui_item__", None)
            if spec is None:
                continue
            kind, kw = spec
            item = kind(**kw)

            async def cb(interaction, _f=func, _i=item):
                if not await self.interaction_check(interaction):
                    return
                try:
                    await _f(self, interaction, _i)
                except Exception as exc:  # noqa: BLE001
                    await self.on_error(interaction, exc, _i)

            item.callback = cb
            setattr(self, name, item)
            self.children.append(item)
        self._stopped = False

    def add_item(self, item):
        if len(self.children) >= 25:
            raise ValueError("too many items")
        self.children.append(item)
        return self

    async def interaction_check(self, interaction) -> bool:
        return True

    async def on_error(self, interaction, error, item):
        raise error

    def stop(self):
        self._stopped = True

    async def wait(self):
        return self._stopped

    def is_persistent(self) -> bool:
        return self.timeout is None and all(getattr(c, "custom_id", None) or getattr(c, "url", None)
                                            for c in self.children)


class TextInput(Item):
    def __init__(self, *, label, style=None, placeholder=None, required=True, min_length=None,
                 max_length=None, default=None):
        super().__init__()
        if len(label) > 45:
            raise ValueError(f"label too long: {label}")
        self.label, self.required = label, required
        self.min_length, self.max_length = min_length, max_length
        self._value = default or ""

    @property
    def value(self):
        return self._value

    def __str__(self):
        return self._value


class Modal:
    title: str = ""

    def __init_subclass__(cls, *, title: str | None = None, **kw) -> None:
        super().__init_subclass__(**kw)
        if title is not None:
            cls.title = title

    def __init__(self, *, title=None, timeout=None) -> None:
        if title is not None:
            self.title = title
        if not self.title or len(self.title) > 45:
            raise ValueError(f"invalid modal title: {self.title!r}")
        self.timeout = timeout
        self.children = []
        import copy
        for name in dir(type(self)):
            attr = getattr(type(self), name, None)
            if isinstance(attr, TextInput):
                inst = copy.copy(attr)
                setattr(self, name, inst)
                self.children.append(inst)
        if len(self.children) > 5:
            raise ValueError("too many inputs")

    async def on_error(self, interaction, error):
        raise error
