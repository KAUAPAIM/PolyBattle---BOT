"""Stub de discord.ext.commands."""
from __future__ import annotations

from .. import app_commands


def when_mentioned(bot, msg):
    return []


class Cog:
    @staticmethod
    def listener(name=None):
        def deco(func):
            func.__listener__ = name or func.__name__
            return func
        return deco

    async def cog_load(self):
        pass

    async def cog_unload(self):
        pass


class Bot:
    def __init__(self, *, command_prefix=None, intents=None, help_command=None, allowed_mentions=None,
                 activity=None):
        self.intents = intents
        self.tree = app_commands.CommandTree()
        self.cogs: dict[str, Cog] = {}
        self.persistent_views = []
        self.dispatched: list[tuple] = []
        self.guilds = []
        self.user = None

    def add_view(self, view):
        if not view.is_persistent():
            raise ValueError("view is not persistent")
        self.persistent_views.append(view)

    async def add_cog(self, cog):
        self.cogs[type(cog).__name__] = cog
        await cog.cog_load()

    def get_cog(self, name):
        return self.cogs.get(name)

    def get_user(self, uid):
        return None

    def get_guild(self, gid):
        return next((g for g in self.guilds if g.id == gid), None)

    def dispatch(self, event, *args):
        self.dispatched.append((event, *args))

    async def wait_until_ready(self):
        return None

    async def close(self):
        pass
