"""Stub de discord.ext.tasks: o loop não roda sozinho; os testes chamam a coroutine."""
from __future__ import annotations


class _Loop:
    def __init__(self, coro, **interval):
        self.coro = coro
        self.interval = interval
        self.running = False

    def __get__(self, instance, owner):
        if instance is None:
            return self
        bound = _BoundLoop(self, instance)
        return bound

    def before_loop(self, coro):
        self._before = coro
        return coro


class _BoundLoop:
    def __init__(self, loop, instance):
        self._loop, self._instance = loop, instance

    def start(self):
        self._loop.running = True

    def cancel(self):
        self._loop.running = False

    def change_interval(self, **kw):
        self._loop.interval = kw

    async def __call__(self):
        return await self._loop.coro(self._instance)


def loop(**interval):
    def deco(coro):
        return _Loop(coro, **interval)
    return deco
