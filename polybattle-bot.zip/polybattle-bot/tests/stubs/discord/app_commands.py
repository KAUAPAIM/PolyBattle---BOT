"""Stub de discord.app_commands: decoradores marcam funções; checks ficam em __checks__."""
from __future__ import annotations

import types


class AppCommandError(Exception):
    pass


class CheckFailure(AppCommandError):
    pass


class NoPrivateMessage(CheckFailure):
    pass


class MissingPermissions(CheckFailure):
    def __init__(self, missing):
        self.missing_permissions = missing


class BotMissingPermissions(CheckFailure):
    def __init__(self, missing):
        self.missing_permissions = missing


class CommandOnCooldown(CheckFailure):
    def __init__(self, retry_after=1.0):
        self.retry_after = retry_after


class CommandInvokeError(AppCommandError):
    def __init__(self, original):
        self.original = original


class _RangeMeta(type):
    def __getitem__(cls, item):
        return item[0]


class Range(metaclass=_RangeMeta):
    pass


class Choice:
    def __init__(self, *, name, value):
        self.name, self.value = name, value

    def __class_getitem__(cls, item):
        return cls


def _mark(**attrs):
    def deco(func):
        for k, v in attrs.items():
            setattr(func, k, v)
        return func
    return deco


def _validate_name(name):
    if not name or len(name) > 32 or name != name.lower() or " " in name:
        raise ValueError(f"invalid command name: {name!r}")


def command(*, name=None, description="..."):
    if name:
        _validate_name(name)
    if len(description) > 100:
        raise ValueError(f"description too long ({len(description)}): {description}")
    return _mark(__app_command__=name, __description__=description)


def describe(**kw):
    for v in kw.values():
        if len(v) > 100:
            raise ValueError("param description too long")
    return _mark()


def choices(**kw):
    for opts in kw.values():
        if len(opts) > 25:
            raise ValueError("too many choices")
    return _mark()


def guild_only(func=None):
    deco = _mark(__discord_app_commands_guild_only__=True)
    return deco(func) if func is not None else deco


def default_permissions(**perms):
    return _mark()


def check(predicate):
    def deco(func):
        checks = list(getattr(func, "__checks__", []))
        checks.append(predicate)
        func.__checks__ = checks
        return func
    return deco


checks = types.SimpleNamespace(cooldown=lambda *a, **k: _mark())


class Group:
    def __init__(self, *, name, description, guild_only=False, default_permissions=None):
        _validate_name(name)
        if len(description) > 100:
            raise ValueError("group description too long")
        self.name, self.description = name, description

    def command(self, *, name=None, description="..."):
        inner = command(name=name, description=description)

        def deco(func):
            func = inner(func)
            func.__group__ = self.name
            return func
        return deco


class ContextMenu:
    def __init__(self, *, name, callback):
        self.name, self.callback, self.type = name, callback, "message"
        self.guild_only = getattr(callback, "__discord_app_commands_guild_only__", False)


class CommandTree:
    def __init__(self):
        self.commands = []

    def add_command(self, cmd):
        self.commands.append(cmd)

    def remove_command(self, name, *, type=None):
        self.commands = [c for c in self.commands if c.name != name]
