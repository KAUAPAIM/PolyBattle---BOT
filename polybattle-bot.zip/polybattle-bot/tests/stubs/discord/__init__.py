"""
Stub MÍNIMO de discord.py usado apenas pelos testes de fluxo quando a
biblioteca real não está instalada. Simula o subconjunto da API usado pelo
bot (objetos em memória). Não é usado em produção.
"""
from __future__ import annotations

import datetime as _dt
import enum
import itertools

from . import abc, utils  # noqa: F401

_ids = itertools.count(1000)


def _next_id() -> int:
    return next(_ids)


# ---------------------------------------------------------------- erros
class DiscordException(Exception):
    pass


class HTTPException(DiscordException):
    def __init__(self, text: str = "http error") -> None:
        super().__init__(text)
        self.text = text


class Forbidden(HTTPException):
    pass


class NotFound(HTTPException):
    pass


class LoginFailure(DiscordException):
    pass


class PrivilegedIntentsRequired(DiscordException):
    pass


# ---------------------------------------------------------------- básicos
class Object:
    def __init__(self, id: int) -> None:
        self.id = id


class Intents:
    def __init__(self) -> None:
        self.members = False
        self.message_content = False

    @classmethod
    def default(cls) -> "Intents":
        return cls()


class ActivityType(enum.Enum):
    watching = 3


class Activity:
    def __init__(self, **kw) -> None:
        self.kw = kw


class ButtonStyle(enum.Enum):
    primary = 1
    secondary = 2
    success = 3
    danger = 4
    link = 5


class TextStyle(enum.Enum):
    short = 1
    paragraph = 2


class AuditLogAction(enum.Enum):
    member_role_update = 25
    role_update = 31
    role_create = 30
    role_delete = 32
    bot_add = 28
    ban = 22
    unban = 23
    channel_create = 10
    channel_update = 11
    channel_delete = 12
    overwrite_update = 14


class Colour:
    def __init__(self, value: int) -> None:
        self.value = value

    def __eq__(self, other) -> bool:
        return isinstance(other, Colour) and other.value == self.value

    def __str__(self) -> str:
        return f"#{self.value:06x}"


Color = Colour

_PERM_BITS = {
    "create_instant_invite": 0, "kick_members": 1, "ban_members": 2, "administrator": 3,
    "manage_channels": 4, "manage_guild": 5, "add_reactions": 6, "view_audit_log": 7,
    "priority_speaker": 8, "stream": 9, "view_channel": 10, "send_messages": 11, "send_tts_messages": 12,
    "manage_messages": 13, "embed_links": 14, "attach_files": 15, "read_message_history": 16,
    "mention_everyone": 17, "use_external_emojis": 18, "view_guild_insights": 19, "connect": 20,
    "speak": 21, "mute_members": 22, "deafen_members": 23, "move_members": 24, "use_voice_activation": 25,
    "change_nickname": 26, "manage_nicknames": 27, "manage_roles": 28, "manage_webhooks": 29,
    "manage_expressions": 30, "use_application_commands": 31, "request_to_speak": 32, "manage_events": 33,
    "manage_threads": 34, "create_public_threads": 35, "create_private_threads": 36,
    "use_external_stickers": 37, "send_messages_in_threads": 38, "use_embedded_activities": 39,
    "moderate_members": 40,
}


class Permissions:
    def __init__(self, permissions: int = 0, **kwargs: bool) -> None:
        self.value = permissions
        for name, val in kwargs.items():
            if name not in _PERM_BITS:
                raise TypeError(f"{name!r} is not a valid permission name.")
            if val:
                self.value |= 1 << _PERM_BITS[name]
            else:
                self.value &= ~(1 << _PERM_BITS[name])

    @classmethod
    def none(cls) -> "Permissions":
        return cls(0)

    def __getattr__(self, name: str) -> bool:
        if name in _PERM_BITS:
            return bool(self.value >> _PERM_BITS[name] & 1)
        raise AttributeError(name)

    def __iter__(self):
        for name in _PERM_BITS:
            yield name, getattr(self, name)

    def __eq__(self, other) -> bool:
        return isinstance(other, Permissions) and other.value == self.value

    def __or__(self, other: "Permissions") -> "Permissions":
        return Permissions(self.value | other.value)


class PermissionOverwrite:
    def __init__(self, **kwargs) -> None:
        for name in kwargs:
            if name not in _PERM_BITS:
                raise TypeError(f"{name!r} is not a valid permission name.")
        self._values = {k: v for k, v in kwargs.items() if v is not None}

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return self._values.get(name)

    def __setattr__(self, name, value):
        if name == "_values":
            object.__setattr__(self, name, value)
        elif value is None:
            self._values.pop(name, None)
        else:
            self._values[name] = value

    def __eq__(self, other) -> bool:
        return isinstance(other, PermissionOverwrite) and other._values == self._values

    def __repr__(self) -> str:
        return f"PermissionOverwrite({self._values})"


class AllowedMentions:
    def __init__(self, *, everyone=False, users=True, roles=False, replied_user=False) -> None:
        self.everyone, self.users, self.roles = everyone, users, roles

    @classmethod
    def none(cls) -> "AllowedMentions":
        return cls(users=False)


class _Footer:
    def __init__(self, text=None) -> None:
        self.text = text


class _Field:
    def __init__(self, name, value, inline) -> None:
        self.name, self.value, self.inline = name, value, inline


class Embed:
    def __init__(self, *, title=None, description=None, color=None, colour=None, timestamp=None, url=None):
        self.title, self.description, self.url = title, description, url
        self.color = color if color is not None else colour
        self.timestamp = timestamp
        self.fields: list[_Field] = []
        self.footer = _Footer()
        self.author = None
        self.image = None
        self.thumbnail = None
        if self.title is not None and len(self.title) > 256:
            raise ValueError("title too long")
        if self.description is not None and len(self.description) > 4096:
            raise ValueError("description too long")

    def add_field(self, *, name, value, inline=True):
        if len(str(name)) > 256 or len(str(value)) > 1024:
            raise ValueError("field too long")
        if len(self.fields) >= 25:
            raise ValueError("too many fields")
        self.fields.append(_Field(name, value, inline))
        return self

    def set_field_at(self, index, *, name, value, inline=True):
        self.fields[index] = _Field(name, value, inline)
        return self

    def set_footer(self, *, text=None, icon_url=None):
        self.footer = _Footer(text)
        return self

    def set_author(self, *, name, icon_url=None, url=None):
        self.author = name
        return self

    def set_image(self, *, url):
        self.image = url
        return self

    def set_thumbnail(self, *, url):
        self.thumbnail = url
        return self


class File:
    def __init__(self, fp, filename=None) -> None:
        self.fp = fp
        self.filename = filename
        self.data = fp.read()


class SelectOption:
    def __init__(self, *, label, value, emoji=None, description=None) -> None:
        if description and len(description) > 100:
            raise ValueError("option description too long")
        self.label, self.value, self.emoji, self.description = label, value, emoji, description


# ---------------------------------------------------------------- entidades
class _Asset:
    url = "https://cdn.example/avatar.png"


class Role:
    def __init__(self, guild, name, *, position=1, permissions=None, colour=None, hoist=False,
                 mentionable=False, managed=False, id=None) -> None:
        self.id = id or _next_id()
        self.guild, self.name, self.position = guild, name, position
        self.permissions = permissions or Permissions.none()
        self.colour = colour or Colour(0)
        self.hoist, self.mentionable, self.managed = hoist, mentionable, managed

    @property
    def mention(self) -> str:
        return f"<@&{self.id}>"

    def __lt__(self, o): return self.position < o.position
    def __le__(self, o): return self.position <= o.position
    def __gt__(self, o): return self.position > o.position
    def __ge__(self, o): return self.position >= o.position
    def __eq__(self, o): return isinstance(o, Role) and o.id == self.id
    def __hash__(self): return hash(self.id)
    def __repr__(self): return f"<Role {self.name} pos={self.position}>"

    async def edit(self, *, permissions=None, colour=None, hoist=None, mentionable=None, reason=None, **_):
        if permissions is not None:
            self.permissions = permissions
        if colour is not None:
            self.colour = colour
        if hoist is not None:
            self.hoist = hoist
        if mentionable is not None:
            self.mentionable = mentionable


class User:
    def __init__(self, name="user", *, id=None, bot=False) -> None:
        self.id = id or _next_id()
        self.name = name
        self.bot = bot
        self.display_name = name
        self.display_avatar = _Asset()
        self.created_at = _dt.datetime.now(_dt.timezone.utc) - _dt.timedelta(days=400)
        self.dms: list[dict] = []

    @property
    def mention(self) -> str:
        return f"<@{self.id}>"

    def __str__(self) -> str:
        return self.name

    def __eq__(self, o): return hasattr(o, "id") and o.id == self.id
    def __hash__(self): return hash(self.id)

    async def send(self, content=None, **kw):
        if getattr(self, "dm_closed", False):
            raise Forbidden("dms closed")
        self.dms.append({"content": content, **kw})


class Member(User):
    def __init__(self, guild, name="member", *, id=None, bot=False, roles=None) -> None:
        super().__init__(name, id=id, bot=bot)
        self.guild = guild
        self._roles = list(roles or [])
        self.nick = None
        self.joined_at = _dt.datetime.now(_dt.timezone.utc) - _dt.timedelta(days=1)
        self.timed_out_until = None

    @property
    def roles(self):
        return [self.guild.default_role] + sorted(self._roles, key=lambda r: r.position)

    @property
    def top_role(self):
        return max(self.roles, key=lambda r: r.position)

    @property
    def guild_permissions(self) -> Permissions:
        if self.id == self.guild.owner_id:
            return Permissions(-1 & ((1 << 41) - 1))
        value = 0
        for r in self.roles:
            value |= r.permissions.value
        if value >> 3 & 1:
            value = (1 << 41) - 1
        return Permissions(value)

    async def add_roles(self, *roles, reason=None):
        for r in roles:
            if r not in self._roles:
                self._roles.append(r)

    async def remove_roles(self, *roles, reason=None):
        self._roles = [r for r in self._roles if r not in roles]

    async def timeout(self, until, *, reason=None):
        self.timed_out_until = None if until is None else _dt.datetime.now(_dt.timezone.utc) + until

    def is_timed_out(self) -> bool:
        return self.timed_out_until is not None


class _GuildChannel:
    def __init__(self, guild, name, *, category=None, overwrites=None, id=None) -> None:
        self.id = id or _next_id()
        self.guild, self.name = guild, name
        self.category = category
        self.overwrites = dict(overwrites or {})
        self.deleted = False

    @property
    def category_id(self):
        return self.category.id if self.category else None

    @property
    def mention(self) -> str:
        return f"<#{self.id}>"

    async def edit(self, **kw):
        for key, value in kw.items():
            if key == "reason":
                continue
            setattr(self, key, value)

    async def delete(self, *, reason=None):
        self.deleted = True
        self.guild._channels.remove(self)

    async def set_permissions(self, target, *, overwrite=None, reason=None):
        if overwrite is None:
            self.overwrites.pop(target, None)
        else:
            self.overwrites[target] = overwrite

    def overwrites_for(self, target):
        return PermissionOverwrite(**self.overwrites.get(target, PermissionOverwrite())._values)


class CategoryChannel(_GuildChannel):
    pass


class VoiceChannel(_GuildChannel):
    def __init__(self, *a, user_limit=0, **kw) -> None:
        super().__init__(*a, **kw)
        self.user_limit = user_limit


class Message:
    def __init__(self, channel, author, content=None, *, embeds=None, view=None, id=None) -> None:
        self.id = id or _next_id()
        self.channel, self.author, self.content = channel, author, content or ""
        self.clean_content = self.content
        self.embeds = list(embeds or [])
        self.view = view
        self.attachments = []
        self.raw_mentions: list[int] = []
        self.raw_role_mentions: list[int] = []
        self.created_at = _dt.datetime.now(_dt.timezone.utc)
        self.guild = getattr(channel, "guild", None)
        self.jump_url = f"https://discord.com/channels/x/{getattr(channel, 'id', 0)}/{self.id}"
        self.deleted = False
        self.published = False
        self.threads = []

    async def edit(self, *, content=None, embed=None, embeds=None, view=None, **_):
        if embed is not None:
            self.embeds = [embed]
        if embeds is not None:
            self.embeds = list(embeds)
        self.view = view

    async def delete(self):
        self.deleted = True

    async def publish(self):
        self.published = True

    async def create_thread(self, *, name, auto_archive_duration=None):
        self.threads.append(name)


class TextChannel(_GuildChannel):
    def __init__(self, *a, topic=None, slowmode_delay=0, **kw) -> None:
        super().__init__(*a, **kw)
        self.topic, self.slowmode_delay = topic, slowmode_delay
        self.messages: list[Message] = []

    def is_news(self) -> bool:
        return False

    async def send(self, content=None, *, embed=None, embeds=None, view=None, file=None,
                   allowed_mentions=None, delete_after=None):
        if embed is not None and embeds is not None:
            raise TypeError("cannot pass both embed and embeds")
        msg = Message(self, self.guild.me, content, embeds=[embed] if embed else embeds, view=view)
        msg.file = file
        self.messages.append(msg)
        return msg

    async def fetch_message(self, message_id):
        for m in self.messages:
            if m.id == message_id:
                return m
        raise NotFound("message")

    async def history(self, *, limit=100, oldest_first=False):
        msgs = self.messages if oldest_first else list(reversed(self.messages))
        for m in msgs[:limit]:
            yield m

    async def purge(self, *, limit=100, check=None, reason=None, bulk=True):
        deleted = []
        for m in list(reversed(self.messages))[:limit]:
            if check is None or check(m):
                deleted.append(m)
                self.messages.remove(m)
        return deleted

    async def delete_messages(self, messages, *, reason=None):
        ids = {m.id for m in messages}
        self.messages = [m for m in self.messages if m.id not in ids]


class Thread(TextChannel):
    pass


class _AuditIter:
    def __init__(self, entries) -> None:
        self._entries = list(entries)

    def __aiter__(self):
        self._it = iter(self._entries)
        return self

    async def __anext__(self):
        try:
            return next(self._it)
        except StopIteration:
            raise StopAsyncIteration from None


class BanEntry:
    def __init__(self, user, reason=None) -> None:
        self.user, self.reason = user, reason


class Guild:
    def __init__(self, name="PolyBattle", *, owner=None, id=None) -> None:
        self.id = id or _next_id()
        self.name = name
        self.default_role = Role(self, "@everyone", position=0, id=self.id)
        self._roles = [self.default_role]
        self._channels: list[_GuildChannel] = []
        self._members: dict[int, Member] = {}
        self.bans: dict[int, BanEntry] = {}
        self.audit_entries: list = []
        self.owner_id = 0
        self.me: Member | None = None
        self.verification_level = 0

    # helpers de teste
    def add_member(self, member: Member) -> Member:
        self._members[member.id] = member
        return member

    @property
    def roles(self):
        return sorted(self._roles, key=lambda r: r.position)

    @property
    def channels(self):
        return list(self._channels)

    @property
    def members(self):
        return list(self._members.values())

    @property
    def member_count(self):
        return len(self._members)

    def get_role(self, rid):
        return next((r for r in self._roles if r.id == rid), None)

    def get_channel(self, cid):
        return next((c for c in self._channels if c.id == cid), None)

    get_channel_or_thread = get_channel

    def get_member(self, uid):
        return self._members.get(uid)

    async def create_role(self, *, name, colour=None, permissions=None, hoist=False, mentionable=False,
                          reason=None):
        for r in self._roles:
            if r.position >= 1:
                r.position += 1
        role = Role(self, name, position=1, permissions=permissions, colour=colour, hoist=hoist,
                    mentionable=mentionable)
        self._roles.append(role)
        return role

    async def edit_role_positions(self, positions, *, reason=None):
        for role, pos in positions.items():
            role.position = pos

    async def create_category(self, name, *, overwrites=None, reason=None, position=None):
        ch = CategoryChannel(self, name, overwrites=overwrites)
        self._channels.append(ch)
        return ch

    async def create_text_channel(self, name, *, category=None, overwrites=None, topic=None,
                                  slowmode_delay=0, reason=None):
        if len(name) > 100:
            raise HTTPException("name too long")
        ch = TextChannel(self, name, category=category, overwrites=overwrites, topic=topic,
                         slowmode_delay=slowmode_delay)
        self._channels.append(ch)
        return ch

    async def create_voice_channel(self, name, *, category=None, overwrites=None, user_limit=0, reason=None):
        ch = VoiceChannel(self, name, category=category, overwrites=overwrites, user_limit=user_limit)
        self._channels.append(ch)
        return ch

    async def kick(self, user, *, reason=None):
        self._members.pop(user.id, None)

    async def ban(self, user, *, reason=None, delete_message_seconds=0):
        self._members.pop(user.id, None)
        self.bans[user.id] = BanEntry(user, reason)

    async def unban(self, user, *, reason=None):
        self.bans.pop(user.id, None)

    async def fetch_ban(self, obj):
        if obj.id not in self.bans:
            raise NotFound("ban")
        return self.bans[obj.id]

    def audit_logs(self, *, limit=100, action=None):
        return _AuditIter([e for e in self.audit_entries if action is None or e.action == action][:limit])


class Interaction:
    pass  # o cliente de teste fornece um objeto próprio


from . import app_commands, ui  # noqa: E402,F401
