"""
Configuração dos testes.

Os testes usam SEMPRE o Discord simulado de tests/stubs (mesmo que o
discord.py real esteja instalado), para exercitar a lógica do bot sem
conectar ao Discord. O stub é colocado na frente do sys.path apenas no
processo do pytest; o bot em produção usa a biblioteca real.
"""
from __future__ import annotations

import asyncio
import importlib.util
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

sys.path.insert(0, str(ROOT / "tests" / "stubs"))
USING_STUB = "stubs" in str(importlib.util.find_spec("discord").origin)

os.environ.setdefault("DISCORD_TOKEN", "test-token-not-real")
os.environ.setdefault("VERIFY_MIN_ACCOUNT_AGE_DAYS", "3")


def run(coro):
    return asyncio.run(coro)


@pytest.fixture
def settings(tmp_path):
    from core.config import load_settings

    os.environ["DATABASE_PATH"] = str(tmp_path / "test.db")
    os.environ["LOG_DIR"] = str(tmp_path / "logs")
    return load_settings(env_file=tmp_path / "missing.env")
