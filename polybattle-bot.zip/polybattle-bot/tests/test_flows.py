"""
Testes de fluxo ponta a ponta com um Discord simulado em memória (tests/stubs).

Cobrem: setup idempotente, permissões, verificação, boas-vindas, tickets
(abertura, limite, assumir, fechar + transcript), sugestões, denúncias,
moderação com escalonamento, automod, anti-raid, segurança de cargos e Veteran.
"""
from __future__ import annotations

import asyncio
import datetime as dt
import importlib
import inspect

import pytest
from conftest import USING_STUB, run

pytestmark = pytest.mark.skipif(not USING_STUB, reason="fluxos usam o Discord simulado (stub)")

if USING_STUB:
    import discord

    from core import blueprint as bp
    from core.bot import EXTENSIONS, PolyBattleBot


# ---------------------------------------------------------------- infraestrutura
class Response:
    def __init__(self) -> None:
        self.done = False
        self.messages: list[dict] = []
        self.modal = None
        self.edited = None

    def is_done(self):
        return self.done

    async def send_message(self, content=None, **kw):
        assert not self.done, "interação respondida duas vezes"
        self.done = True
        self.messages.append({"content": content, **kw})

    async def send_modal(self, modal):
        assert not self.done, "interação respondida duas vezes"
        self.done = True
        self.modal = modal

    async def defer(self, **kw):
        assert not self.done
        self.done = True

    async def edit_message(self, **kw):
        assert not self.done
        self.done = True
        self.edited = kw


class Followup:
    def __init__(self) -> None:
        self.messages: list[dict] = []

    async def send(self, content=None, **kw):
        self.messages.append({"content": content, **kw})


class Inter:
    def __init__(self, bot, user, channel=None, message=None) -> None:
        self.client = bot
        self.user = user
        self.guild = user.guild
        self.guild_id = user.guild.id
        self.channel = channel
        self.channel_id = channel.id if channel else None
        self.message = message
        self.response = Response()
        self.followup = Followup()
        self.command = None

    def all_embeds(self):
        out = []
        for m in self.response.messages + self.followup.messages:
            if m.get("embed") is not None:
                out.append(m["embed"])
        return out

    def text(self):
        return " ".join(f"{e.title or ''} {e.description or ''}" for e in self.all_embeds())


async def call(bot, func, inter, *args, **kwargs):
    """Executa as checks do comando e depois o callback (como o Discord faria)."""
    from discord import app_commands

    for pred in getattr(func, "__checks__", []):
        try:
            await pred(inter)
        except app_commands.CheckFailure as exc:
            await bot.on_tree_error(inter, exc)
            return False
    await func(inter, *args, **kwargs)
    return True


class World:
    """Servidor simulado + bot carregado com todas as extensões."""

    def __init__(self, settings) -> None:
        self.settings = settings

    async def start(self):
        self.bot = PolyBattleBot(self.settings)
        await self.bot.db.connect()
        self.bot.on_tree_error = self.bot.on_tree_error  # noqa: PLW0127
        for ext in EXTENSIONS:
            module = importlib.import_module(ext)
            await module.setup(self.bot)

        g = discord.Guild("PolyBattle")
        self.guild = g
        bot_role = discord.Role(g, "PolyBattle Bot", position=50, managed=True,
                                permissions=discord.Permissions(administrator=True))
        g._roles.append(bot_role)
        me = discord.Member(g, "PolyBattleBot", bot=True, roles=[bot_role])
        g.me = g.add_member(me)
        self.owner = g.add_member(discord.Member(g, "Owner"))
        g.owner_id = self.owner.id
        self.bot.guilds = [g]
        return self

    def cog(self, name):
        return self.bot.get_cog(name)

    def member(self, name, *role_keys, age_days=400):
        m = discord.Member(self.guild, name, roles=[self.bot.role(self.guild, k) for k in role_keys])
        m.created_at = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=age_days)
        return self.guild.add_member(m)

    async def install(self):
        cog = self.cog("Setup")
        import cogs.setup as setup_mod

        async def auto_confirm(view):
            view.confirmed = True
            return True

        original = setup_mod.ConfirmView.wait
        setup_mod.ConfirmView.wait = auto_confirm
        try:
            inter = Inter(self.bot, self.owner)
            await call(self.bot, cog.install, inter)
        finally:
            setup_mod.ConfirmView.wait = original
        return inter

    def channel(self, key):
        return self.bot.channel(self.guild, key)


@pytest.fixture
def no_sleep(monkeypatch):
    real_sleep = asyncio.sleep

    async def fast(_delay, *a, **k):
        await real_sleep(0)

    monkeypatch.setattr(asyncio, "sleep", fast)


def visible(member, channel) -> bool:
    """Calcula se o membro enxerga o canal (overwrites @everyone → cargos), como o Discord."""
    perms = member.guild_permissions
    if perms.administrator:
        return True
    allowed = perms.view_channel
    ow = channel.overwrites
    everyone = ow.get(member.guild.default_role)
    if everyone is not None and everyone.view_channel is not None:
        allowed = everyone.view_channel
    role_allow = role_deny = False
    for role in member.roles[1:]:
        o = ow.get(role)
        if o is None or o.view_channel is None:
            continue
        role_allow |= o.view_channel is True
        role_deny |= o.view_channel is False
    if role_deny:
        allowed = False
    if role_allow:
        allowed = True
    member_ow = ow.get(member)
    if member_ow is not None and member_ow.view_channel is not None:
        allowed = member_ow.view_channel
    return bool(allowed)


# ---------------------------------------------------------------- testes
def test_every_modal_and_view_is_valid(settings):
    """Instancia todos os modals/views para validar títulos, labels e custom_ids."""
    async def scenario():
        w = await World(settings).start()
        from cogs import announcements, reports, tickets, verification
        modals = [
            verification.CodeModal(w.cog("Verification")),
            *[tickets.TicketModal(t) for t in bp.TICKET_TYPES],
            tickets.CloseReasonModal(),
            reports.PanelReportModal(),
            reports.MessageReportModal(discord.Message(None, w.owner, "x")),
            announcements.AnnounceModal(w.cog("Announcements"), "none"),
            announcements.ChangelogModal(w.cog("Announcements"), "none", True),
            announcements.DevUpdateModal(w.cog("Announcements"), "development_updates"),
        ]
        assert all(m.children for m in modals)
        ids = [c.custom_id for v in w.bot.persistent_views for c in v.children]
        assert len(ids) == len(set(ids)), "custom_ids persistentes duplicados"
        assert {"pb:verify:start", "pb:ticket:select", "pb:ticket:claim", "pb:ticket:close",
                "pb:report:open", "pb:suggest:up"} <= set(ids)
        assert any(c.name == "Report Message" for c in w.bot.tree.commands)
    run(scenario())


def test_command_names_are_unique():
    seen = {}
    for ext in EXTENSIONS:
        module = importlib.import_module(ext)
        for _, cls in inspect.getmembers(module, inspect.isclass):
            if cls.__module__ != module.__name__:
                continue
            groups = {name: g.name for name, g in vars(cls).items()
                      if isinstance(g, discord.app_commands.Group)}
            top = [(f"{getattr(f, '__group__', '')} {f.__app_command__}").strip()
                   for f in vars(cls).values() if getattr(f, "__app_command__", None)]
            for name in top:
                assert name not in seen, f"comando duplicado: {name}"
                seen[name] = ext
            for g in groups.values():
                assert g not in seen, f"grupo duplicado: {g}"
                seen[g] = ext
    assert {"setup", "ticket", "warn", "ban", "suggest", "report", "announce", "changelog",
            "raidmode", "automod"} <= set(seen)


def test_setup_creates_structure_idempotently(settings, no_sleep):
    async def scenario():
        w = await World(settings).start()
        inter = await w.install()
        g = w.guild
        assert "Instalação concluída" in inter.text()

        names = [r.name for r in g.roles]
        for spec in bp.ROLES:
            assert names.count(spec.name) == 1
        # hierarquia: ordem do blueprint, tudo abaixo do bot
        positions = [w.bot.role(g, s.key).position for s in bp.ROLES]
        assert positions == sorted(positions, reverse=True)
        assert max(positions) < g.me.top_role.position
        # dono recebeu Founder
        assert w.bot.role(g, "founder") in w.owner.roles

        n_channels = len(g.channels)
        assert n_channels == len(bp.CATEGORIES) + len(bp.ALL_CHANNELS)
        assert g.default_role.permissions.send_messages is False
        assert g.default_role.permissions.view_channel is True

        # painéis publicados
        for key in ("verify", "open_a_ticket", "player_reports", "server_rules", "game_information",
                    "useful_links", "suggestions"):
            assert w.channel(key).messages, key
        verify_msg = w.channel("verify").messages[0]
        assert verify_msg.view is not None

        # segunda execução: nada duplicado, painéis editados (não reenviados)
        inter2 = await w.install()
        assert len(g.channels) == n_channels
        assert sum(1 for r in g.roles if r.name == "Founder") == 1
        assert len(w.channel("verify").messages) == 1
        assert "Criados | Created:** 0" in inter2.text()
    run(scenario())


def test_channel_visibility(settings, no_sleep):
    async def scenario():
        w = await World(settings).start()
        await w.install()
        unverified = w.member("novato")
        verified = w.member("soldado", "verified", "member")
        mod = w.member("mod", "moderator", "verified")
        tester = w.member("tester", "tester", "verified")
        ch = w.channel
        assert visible(unverified, ch("verify")) and visible(unverified, ch("server_rules"))
        assert not visible(unverified, ch("general_chat"))
        assert visible(verified, ch("general_chat")) and not visible(verified, ch("verify"))
        assert not visible(verified, ch("staff_chat")) and not visible(verified, ch("testing"))
        assert visible(tester, ch("testing")) and not visible(tester, ch("staff_logs"))
        assert visible(mod, ch("staff_chat")) and visible(mod, ch("staff_logs"))
        # ninguém escreve nos canais informativos além do bot/admins
        ann = ch("announcements").overwrites
        assert ann[w.guild.default_role].send_messages is False
    run(scenario())


def test_verification_flow(settings, no_sleep):
    async def scenario():
        w = await World(settings).start()
        await w.install()
        from cogs.verification import VerifyView

        cog = w.cog("Verification")
        newbie = w.member("recruta")
        inter = Inter(w.bot, newbie, w.channel("verify"))
        await VerifyView().start.callback(inter)
        code = cog._pending[(w.guild.id, newbie.id)][0]
        assert code in inter.response.messages[0]["embed"].description

        wrong = Inter(w.bot, newbie)
        await cog.finish(wrong, "ZZZZZ" if code != "ZZZZZ" else "YYYYY")
        assert "incorreto" in wrong.text()
        assert w.bot.role(w.guild, "verified") not in newbie.roles

        ok = Inter(w.bot, newbie)
        await cog.finish(ok, code.lower())
        assert w.bot.role(w.guild, "verified") in newbie.roles
        assert w.bot.role(w.guild, "member") in newbie.roles
        assert ("member_verified", newbie) in w.bot.dispatched

        await w.cog("Welcome").on_member_verified(newbie)
        assert any(newbie.mention in (m.content or "") for m in w.channel("general_chat").messages)

        again = Inter(w.bot, newbie)
        await VerifyView().start.callback(again)
        assert "já está verificado" in again.text()

        young = w.member("conta-nova", age_days=0)
        inter = Inter(w.bot, young)
        await VerifyView().start.callback(inter)
        assert "pelo menos" in inter.text()
        assert (w.guild.id, young.id) not in cog._pending
    run(scenario())


def test_ticket_flow(settings, no_sleep):
    async def scenario():
        w = await World(settings).start()
        await w.install()
        from cogs.tickets import TicketControlView, TicketPanelView

        user = w.member("player", "verified", "member")
        user_dm_before = len(user.dms)
        support = w.member("suporte", "support_team", "verified")
        panel_channel = w.channel("open_a_ticket")
        panel_msg = panel_channel.messages[0]

        inter = Inter(w.bot, user, panel_channel, panel_msg)
        view = TicketPanelView()
        view.select.values = ["general"]
        await view.select.callback(inter)
        modal = inter.response.modal
        modal.subject._value = "Não consigo entrar"
        modal.details._value = "O jogo trava na tela de carregamento."
        submit = Inter(w.bot, user, panel_channel)
        await modal.on_submit(submit)
        assert "Ticket criado" in submit.text()

        ticket_ch = next(c for c in w.guild.channels if c.name.startswith("support-0001"))
        assert ticket_ch.category is w.bot.category(w.guild, "cat_tickets")
        assert visible(user, ticket_ch) and visible(support, ticket_ch)
        outsider = w.member("curioso", "verified", "member")
        assert not visible(outsider, ticket_ch)

        # limite de tickets abertos
        view.select.values = ["bug"]
        inter = Inter(w.bot, user, panel_channel, panel_msg)
        await view.select.callback(inter)
        m2 = inter.response.modal
        m2.subject._value, m2.details._value = "Outro", "Outro problema qualquer aqui"
        dup = Inter(w.bot, user, panel_channel)
        await m2.on_submit(dup)
        assert "já possui" in dup.text()

        # parceria: apenas administração enxerga
        partner_user = w.member("parceiro", "verified")
        inter = Inter(w.bot, partner_user, panel_channel, panel_msg)
        view.select.values = ["partnership"]
        await view.select.callback(inter)
        m3 = inter.response.modal
        m3.subject._value, m3.details._value = "Parceria", "Proposta de parceria com clã"
        await m3.on_submit(Inter(w.bot, partner_user, panel_channel))
        partner_ch = next(c for c in w.guild.channels if c.name.startswith("partner-"))
        assert not visible(support, partner_ch)
        admin = w.member("admin", "administrator", "verified")
        assert visible(admin, partner_ch)

        # assumir: membro comum não pode; suporte pode; duplo bloqueado
        controls = TicketControlView()
        denied = Inter(w.bot, outsider, ticket_ch)
        await controls.claim.callback(denied)
        assert "Apenas a equipe" in denied.text()
        claim = Inter(w.bot, support, ticket_ch)
        await controls.claim.callback(claim)
        assert (await w.bot.db.get_ticket_by_channel(ticket_ch.id))["claimed_by"] == support.id
        again = Inter(w.bot, support, ticket_ch)
        await controls.claim.callback(again)
        assert "já assumido" in again.text()

        # /ticket add
        tickets_cog = w.cog("Tickets")
        add = Inter(w.bot, support, ticket_ch)
        await call(w.bot, tickets_cog.add, add, outsider)
        assert visible(outsider, ticket_ch)

        # fechar: abre modal → transcript nos logs + DM + canal excluído
        close = Inter(w.bot, user, ticket_ch)
        await controls.close.callback(close)
        reason_modal = close.response.modal
        reason_modal.reason._value = "Resolvido"
        done = Inter(w.bot, user, ticket_ch)
        await reason_modal.on_submit(done)
        assert ticket_ch.deleted
        row = await w.bot.db.get_ticket_by_channel(ticket_ch.id)
        assert row["status"] == "closed" and row["close_reason"] == "Resolvido"
        logs = w.channel("staff_logs").messages
        transcript_logs = [m for m in logs if getattr(m, "file", None)]
        assert transcript_logs and transcript_logs[-1].file.filename == "ticket-0001.html"
        assert b"O jogo trava" in transcript_logs[-1].file.data
        assert len(user.dms) > user_dm_before and user.dms[-1]["file"].filename == "ticket-0001.html"
        assert await w.bot.db.count_open_tickets(w.guild.id, user.id) == 0
    run(scenario())


def test_suggestions_and_reports(settings, no_sleep):
    async def scenario():
        w = await World(settings).start()
        await w.install()
        from cogs.reports import ReportActionView, ReportPanelView
        from cogs.suggestions import SuggestionVoteView

        player = w.member("player", "verified", "member")
        voter = w.member("voter", "verified", "member")
        head = w.member("head", "head_moderator", "verified")

        # sugestão
        sugg_cog = w.cog("Suggestions")
        inter = Inter(w.bot, player)
        await call(w.bot, sugg_cog.suggest, inter, "Novo mapa urbano", "Um mapa urbano com prédios destrutíveis.")
        msg = w.channel("suggestions").messages[-1]
        assert msg.threads
        v = SuggestionVoteView()
        vi = Inter(w.bot, voter, w.channel("suggestions"), msg)
        await v.upvote.callback(vi)
        assert vi.response.edited["view"].upvote.label == "1"
        vi2 = Inter(w.bot, voter, w.channel("suggestions"), msg)
        await v.upvote.callback(vi2)  # remove o voto
        assert vi2.response.edited["view"].upvote.label == "0"

        denied = Inter(w.bot, player)
        assert not await call(w.bot, sugg_cog.review, denied, 1, discord.app_commands.Choice(name="x", value="denied"))
        assert "permissão" in denied.text()
        review = Inter(w.bot, head)
        await call(w.bot, sugg_cog.review, review, 1, discord.app_commands.Choice(name="Recusada", value="denied"),
                   "Fora do escopo")
        assert msg.view.upvote.disabled
        assert player.dms

        # denúncias pelo painel + limite
        rep_cog = w.cog("Reports")
        for i in range(4):
            open_inter = Inter(w.bot, player, w.channel("player_reports"))
            await ReportPanelView().open.callback(open_inter)
            modal = open_inter.response.modal
            modal.target._value = f"cheater{i}"
            modal.reason._value = "Usando aimbot em todas as partidas"
            sub = Inter(w.bot, player)
            await modal.on_submit(sub)
        assert "muitas denúncias" in sub.text()
        staff_reports = w.channel("staff_reports").messages
        assert len(staff_reports) == 3

        report_msg = staff_reports[0]
        bad = Inter(w.bot, player, w.channel("staff_reports"), report_msg)
        await ReportActionView().resolved.callback(bad)
        assert "Apenas moderadores" in bad.text()
        good = Inter(w.bot, head, w.channel("staff_reports"), report_msg)
        await ReportActionView().resolved.callback(good)
        assert good.response.edited["view"] is None
        row = await w.bot.db.get_report_by_message(report_msg.id)
        assert row["status"] == "resolved" and row["handled_by"] == head.id

        # /report por comando
        cmd = Inter(w.bot, voter)
        await call(w.bot, rep_cog.report, cmd, player, "Ofendendo membros no chat geral")
        assert "enviada" in cmd.text()
    run(scenario())


def test_moderation(settings, no_sleep):
    async def scenario():
        w = await World(settings).start()
        await w.install()
        mod_cog = w.cog("Moderation")
        mod = w.member("mod", "moderator", "verified")
        admin = w.member("admin", "administrator", "verified")
        target = w.member("toxico", "verified", "member")

        # hierarquia: moderador não pune administrador
        inter = Inter(w.bot, mod)
        await call(w.bot, mod_cog.warn_cmd, inter, admin, "teste")
        assert "igual ou superior" in inter.text()

        # membro comum não usa comandos de moderação
        inter = Inter(w.bot, target)
        assert not await call(w.bot, mod_cog.warn_cmd, inter, mod, "teste")

        # 3 avisos → timeout automático (padrão do .env)
        for i in range(3):
            inter = Inter(w.bot, mod)
            await call(w.bot, mod_cog.warn_cmd, inter, target, f"spam {i}")
        assert "timeout" in inter.text()
        assert target.is_timed_out()
        assert len(await w.bot.db.active_warnings(w.guild.id, target.id)) == 3

        inter = Inter(w.bot, mod)
        await call(w.bot, mod_cog.mute, inter, target, "abc", "teste")
        assert "Duração inválida" in inter.text()

        inter = Inter(w.bot, mod)
        await call(w.bot, mod_cog.unmute, inter, target, None)
        assert not target.is_timed_out()

        # moderador não pode banir (exige Head Moderator+)
        inter = Inter(w.bot, mod)
        assert not await call(w.bot, mod_cog.ban, inter, target, "cheat")
        head = w.member("head", "head_moderator", "verified")
        inter = Inter(w.bot, head)
        await call(w.bot, mod_cog.ban, inter, target, "cheat confirmado", None)
        assert target.id in w.guild.bans and w.guild.get_member(target.id) is None
        inter = Inter(w.bot, head)
        await call(w.bot, mod_cog.unban, inter, str(target.id), "recurso aceito")
        assert target.id not in w.guild.bans

        hist = Inter(w.bot, mod)
        await call(w.bot, mod_cog.history, hist, target)
        assert "ban" in hist.text() and "unban" in hist.text()
    run(scenario())


def test_automod_and_raid(settings, no_sleep):
    async def scenario():
        w = await World(settings).start()
        await w.install()
        am = w.cog("AutoMod")
        chat = w.channel("general_chat")
        spammer = w.member("spammer", "verified", "member")
        mod = w.member("mod", "moderator", "verified")

        def msg(author, text):
            m = discord.Message(chat, author, text)
            chat.messages.append(m)
            return m

        m = msg(spammer, "entra no meu server discord.gg/abc")
        await am.on_message(m)
        assert m not in chat.messages or m.deleted
        assert len(await w.bot.db.active_warnings(w.guild.id, spammer.id)) == 1

        staff_msg = msg(mod, "discord.gg/parceiro")
        await am.on_message(staff_msg)
        assert not staff_msg.deleted  # equipe isenta

        am._cooldown.clear()
        mal = msg(spammer, "FREE NITRO https://claim-gift.ru")
        await am.on_message(mal)
        assert mal.deleted and spammer.is_timed_out()

        # flood
        flooder = w.member("flooder", "verified", "member")
        for i in range(w.settings.automod_flood_messages):
            await am.on_message(msg(flooder, f"oi {i}"))
        assert flooder.is_timed_out()
        assert not any(m.author is flooder and m.content.startswith("oi") for m in chat.messages)

        # anti-raid
        for i in range(w.settings.raid_join_threshold):
            joiner = w.member(f"raider{i}", age_days=1)
            await am.on_member_join(joiner)
        assert am.raid_active(w.guild.id)
        late = w.member("depois", age_days=100)
        await am.on_member_join(late)
        assert w.guild.get_member(late.id) is None
        off = Inter(w.bot, w.member("head", "head_moderator", "verified"))
        await call(w.bot, am.raid_off, off)
        assert not am.raid_active(w.guild.id)
    run(scenario())


def test_security_blocks_unauthorized_grants(settings, no_sleep):
    async def scenario():
        w = await World(settings).start()
        await w.install()
        sec = w.cog("Security")
        g = w.guild

        class Entry:
            def __init__(self, action, user, target, roles=()):
                self.action, self.user, self.target = action, user, target
                self.created_at = dt.datetime.now(dt.timezone.utc)
                self.after = type("A", (), {"roles": list(roles)})()

        mod = w.member("mod", "moderator", "verified")
        friend = w.member("amigo", "verified")
        admin_role = w.bot.role(g, "administrator")

        # Moderador concede Administrator → revertido
        before = discord.Member(g, "amigo", id=friend.id, roles=list(friend._roles))
        await friend.add_roles(admin_role)
        g.audit_entries = [Entry(discord.AuditLogAction.member_role_update, mod, friend, [admin_role])]
        await sec.on_member_update(before, friend)
        assert admin_role not in friend.roles
        assert any("Escalonamento" in (m.embeds[0].title or "") for m in w.channel("staff_logs").messages)

        # Head Moderator concede Moderator → permitido
        head = w.member("head", "head_moderator", "verified")
        mod_role = w.bot.role(g, "moderator")
        before = discord.Member(g, "amigo", id=friend.id, roles=list(friend._roles))
        await friend.add_roles(mod_role)
        g.audit_entries = [Entry(discord.AuditLogAction.member_role_update, head, friend, [mod_role])]
        await sec.on_member_update(before, friend)
        assert mod_role in friend.roles

        # cargo comum ganha "administrator" por não confiável → revertido
        vip = w.bot.role(g, "vip")
        before_role = discord.Role(g, vip.name, id=vip.id, position=vip.position, permissions=vip.permissions)
        vip.permissions = discord.Permissions(vip.permissions.value | discord.Permissions(administrator=True).value)
        g.audit_entries = [Entry(discord.AuditLogAction.role_update, head, vip)]
        await sec.on_guild_role_update(before_role, vip)
        assert not vip.permissions.administrator

        # dono pode
        before_role = discord.Role(g, vip.name, id=vip.id, position=vip.position, permissions=vip.permissions)
        vip.permissions = discord.Permissions(vip.permissions.value | discord.Permissions(manage_guild=True).value)
        g.audit_entries = [Entry(discord.AuditLogAction.role_update, w.owner, vip)]
        await sec.on_guild_role_update(before_role, vip)
        assert vip.permissions.manage_guild
    run(scenario())


def test_autoroles_veteran(settings, no_sleep):
    async def scenario():
        w = await World(settings).start()
        await w.install()
        old = w.member("antigo", "verified", "member")
        old.joined_at = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=w.settings.veteran_days + 1)
        new = w.member("novo", "verified", "member")
        unverified = w.member("sem-verificacao")
        unverified.joined_at = old.joined_at
        n = await w.cog("AutoRoles").promote_veterans(w.guild)
        veteran = w.bot.role(w.guild, "veteran")
        assert n == 1 and veteran in old.roles and veteran not in new.roles and veteran not in unverified.roles

        # cargo de equipe concede Verified automaticamente
        dev = w.member("dev")
        before = discord.Member(w.guild, "dev", id=dev.id, roles=[])
        await dev.add_roles(w.bot.role(w.guild, "developer"))
        await w.cog("AutoRoles").on_member_update(before, dev)
        assert w.bot.role(w.guild, "verified") in dev.roles
    run(scenario())


def test_setup_requires_admin(settings, no_sleep):
    async def scenario():
        w = await World(settings).start()
        player = w.member("player")
        inter = Inter(w.bot, player)
        await call(w.bot, w.cog("Setup").install, inter)
        assert "Apenas o dono" in inter.text()
        # comandos de staff antes do setup avisam que falta configurar
        mod_inter = Inter(w.bot, player)
        await call(w.bot, w.cog("Moderation").warn_cmd, mod_inter, w.owner, "x")
        assert "não foi configurado" in mod_inter.text()
    run(scenario())


def test_unverified_cannot_suggest_or_report(settings, no_sleep):
    async def scenario():
        w = await World(settings).start()
        await w.install()
        newbie = w.member("novato")
        inter = Inter(w.bot, newbie)
        assert not await call(w.bot, w.cog("Suggestions").suggest, inter, "Titulo", "Descricao longa o bastante")
        inter = Inter(w.bot, newbie)
        assert not await call(w.bot, w.cog("Reports").report, inter, w.owner, "motivo qualquer aqui")
        assert w.channel("suggestions").messages[-1].embeds[0].title.startswith("💡 SUGGESTIONS")
    run(scenario())
