# Manual de utilização e administração — POLYBATTLE | OFFICIAL

## 1. Hierarquia de cargos

Do topo para a base. As permissões abaixo são as **de servidor**; o acesso a cada canal é
controlado pelas permissões das categorias/canais (seção 2).

| # | Cargo | Cor | Permissões principais |
|---|---|---|---|
| 1 | **Founder** | branco `#F2F2F2` | Administrador |
| 2 | **Owner** | cinza claro `#C9C9C9` | Administrador |
| 3 | **Administrator** | vermelho `#9E2A2B` | Gerenciar servidor, cargos, canais, webhooks e eventos; banir; moderação completa; mencionar @everyone |
| 4 | **Head Moderator** | laranja `#D9822B` | Banir, expulsar, timeout, gerenciar mensagens/tópicos/apelidos, mover/silenciar em voz, ver auditoria |
| 5 | **Moderator** | âmbar `#E3B341` | Igual ao Head Moderator, **sem banir** |
| 6 | **Support Team** | azul `#4FA3D1` | Membro + gerenciar tópicos; acesso aos tickets e canais da staff |
| 7 | **Developer** | verde `#6FBF73` | Membro; publica em changelog/dev updates; acessa #testing |
| 8 | **Builder** | marrom `#A67C52` | Membro; acessa #testing |
| 9 | **Tester** | roxo `#9B7EDE` | Membro; acessa #testing |
| 10 | **VIP** | dourado `#E5C07B` | Membro (destaque) |
| 11 | **Veteran** | oliva `#6B8E23` | Membro (automático após `VETERAN_DAYS`) |
| 12 | **Verified** | sálvia `#8A9A5B` | Libera os canais da comunidade (não aparece separado na lista) |
| 13 | **Member** | cinza `#9AA0A6` | Cargo padrão de membro verificado |

**@everyone** fica apenas com: ver canais, ler histórico e usar comandos. Quem não é verificado só
enxerga INFORMATION (somente leitura) e `✅┃verify`.

### Quem pode conceder cada cargo (proteção contra escalonamento)

O Discord já impede dar cargos acima do seu. O bot adiciona uma regra extra: cargos protegidos só
podem ser concedidos pelos cargos abaixo. Concessões fora da regra são **revertidas** e geram
alerta em `#staff-logs`.

| Cargo concedido | Pode conceder |
|---|---|
| Founder | Founder |
| Owner | Founder |
| Administrator | Founder, Owner |
| Head Moderator, Developer, Builder, Tester, VIP | Founder, Owner, Administrator |
| Moderator, Support Team | Founder, Owner, Administrator, Head Moderator* |

\* Head Moderator não tem "Gerenciar cargos" por padrão; a regra só vale se você der essa
permissão a ele manualmente.

Na prática, isso bloqueia quem recebeu "Gerenciar cargos" por um cargo improvisado (fora do
blueprint) de distribuir cargos de equipe.

Dono do servidor, o próprio bot e membros com a permissão **Administrador** (Founder/Owner) são
sempre confiáveis. Também é revertida qualquer concessão de permissões perigosas (Administrador,
Gerenciar Servidor/Cargos/Canais/Webhooks, Banir, Expulsar, Timeout, Mencionar @everyone) a um
cargo feita por alguém não confiável. Bots adicionados ao servidor geram alerta com quem os adicionou.

Quem recebe qualquer cargo de equipe, desenvolvimento ou VIP ganha **Verified** automaticamente.

---

## 2. Canais e acesso

| Categoria | Canais | Quem vê | Quem escreve |
|---|---|---|---|
| ◤ INFORMATION ◢ | verify, announcements, server-rules, game-information, changelog, useful-links | todos (verify: só não verificados) | ninguém; Administrator em announcements; Developer em changelog |
| ◤ COMMUNITY ◢ | general-chat, in-game-chat, screenshots, clips-and-highlights, looking-for-team | Verified | Verified (com modo lento) |
| ◤ GAME SUPPORT ◢ | open-a-ticket, bug-reports, suggestions, player-reports | Verified | bug-reports livre; demais via painéis/comandos; tópicos das sugestões liberados |
| ◤ DEVELOPMENT ◢ | development-updates, upcoming-features, testing, community-feedback | Verified (testing: Tester/Builder/Developer/staff) | Developer nos dois primeiros; community-feedback livre |
| ◤ VOICE CHANNELS ◢ | General Voice, Squad 01–04 (limite 5) | Verified | Verified |
| ◤ STAFF ◢ | staff-chat, staff-logs, staff-reports, staff-announcements, Staff Voice | Founder → Support Team | staff-logs: só o bot; staff-announcements: Administrator+ |
| ◤ TICKETS ◢ | um canal por ticket | autor + cargos do tipo de ticket | idem |

---

## 3. Comandos

Legenda de acesso: o dono do servidor e membros com permissão **Administrador** passam em todas as
checagens. Alguns comandos ficam ocultos no menu para quem não tem a permissão do Discord
correspondente (ex.: `/setup` só aparece para quem tem Administrador).

### Configuração
| Comando | Quem | Função |
|---|---|---|
| `/setup install` | Dono / Founder / Owner | Cria/atualiza cargos, canais, permissões e painéis |
| `/setup panels` | Dono / Founder / Owner | Republica os painéis (após editar `core/content.py`) |
| `/setup status` | Dono / Founder / Owner | Diagnóstico: intents, hierarquia, recursos ausentes, tickets abertos |
| `/autoroles sync` | Administrator+ | Promove agora os membros elegíveis a Veteran |

### Comunidade
| Comando | Quem | Função |
|---|---|---|
| `/suggest título descrição` | Verified (1 a cada 5 min) | Publica sugestão com votação e tópico de discussão |
| `/report membro motivo [provas]` | Verified | Denúncia privada para a staff |
| Clique direito na mensagem → **Apps → Report Message** | Verified | Denuncia a mensagem (link e trecho vão junto) |
| `/gamestatus` | Todos | Jogadores online, visitas e última atualização no Roblox |

### Tickets
| Comando | Quem | Função |
|---|---|---|
| Painel em `🎫┃open-a-ticket` | Verified | Abre ticket (General Support, Bug Report, Player Report, Partnership, Other Issues) |
| Botão **Assumir** / `/ticket claim` | Equipe do tipo de ticket | Marca o responsável |
| Botão **Fechar** / `/ticket close [motivo]` | Autor ou equipe | Gera transcript, envia aos logs e ao autor, exclui o canal |
| `/ticket add membro` / `/ticket remove membro` | Equipe do ticket | Dá/retira acesso ao ticket |

Quem vê cada tipo: General/Other → toda a staff · Bug Report → staff + Developer ·
Player Report → Moderator+ · Partnership → Founder/Owner/Administrator.

### Moderação
| Comando | Quem | Função |
|---|---|---|
| `/warn membro motivo` | Moderator+ | Aviso + punição automática por acúmulo |
| `/warnings membro` · `/history usuário` | Staff | Avisos ativos · histórico de casos |
| `/unwarn id` | Moderator+ | Remove um aviso |
| `/clearwarnings membro` | Head Moderator+ | Remove todos os avisos |
| `/mute membro duração motivo` · `/unmute` | Moderator+ | Timeout nativo (`30m`, `2h`, `1d`… máx. 28d) |
| `/kick membro motivo` | Moderator+ | Expulsa |
| `/ban usuário motivo [apagar mensagens]` · `/unban id motivo` | Head Moderator+ | Bane/desbane (aceita ID de quem já saiu) |
| `/purge quantidade [membro]` | Moderator+ | Apaga até 100 mensagens recentes |
| `/slowmode segundos` · `/lock` · `/unlock` | Moderator+ | Controle do canal atual |
| `/raidmode on [minutos]` · `/raidmode off` | Head Moderator+ | Modo anti-raid manual |
| `/raidmode status` | Staff | Estado do anti-raid |
| `/automod blocklink-add/remove domínio` | Founder/Owner/Administrator | Blocklist de domínios |
| `/automod blocklink-list` · `/automod settings` | Staff | Consulta |

Toda punição valida a hierarquia (ninguém pune cargo igual/superior ao seu, o dono ou o bot),
avisa o alvo por DM (antes do kick/ban), gera um **número de caso** e é registrada no banco e
em `#staff-logs`.

### Comunicação oficial
| Comando | Quem | Função |
|---|---|---|
| `/announce [ping]` | Founder/Owner/Administrator | Formulário → comunicado em `#announcements` |
| `/changelog [ping] [notify]` | Administrator+ e Developer | Formulário → patch notes em `#changelog` (+ aviso em announcements). Linhas com `+` `*` `-` viram 🟢 🟡 🔴 |
| `/devupdate canal` | Administrator+ e Developer | Publica em development-updates ou upcoming-features |

**Atualização automática:** com `ROBLOX_UNIVERSE_ID` no `.env`, o bot consulta a API pública do
Roblox a cada `UPDATE_CHECK_MINUTES` minutos; quando a data de atualização do jogo muda, publica
um aviso em `#changelog` com botão "Jogar". A primeira consulta apenas registra a referência.

---

## 4. Sistemas automáticos

**Verificação** — botão no `✅┃verify` → código de 5 caracteres (válido 3 min, 3 tentativas) →
formulário. Contas com menos de `VERIFY_MIN_ACCOUNT_AGE_DAYS` dias são recusadas e registradas.
Sucesso: cargos Verified + Member e boas-vindas públicas em `#general-chat`.

**Boas-vindas e registro** — ao entrar: DM com instruções e log (com alerta de conta recente).
Ao sair: log com tempo no servidor e cargos que tinha.

**AutoMod** (staff isenta):
| Detecção | Ação |
|---|---|
| Convite de outro servidor | apaga + aviso |
| Link que imita marca (ex.: `dlscord-gift`, `rob1ox-…`) | apaga + aviso |
| Link malicioso (blocklist, punycode, "free nitro/robux") | apaga + timeout `AUTOMOD_MALICIOUS_LINK_TIMEOUT_MINUTES` + aviso |
| Menções em excesso / tentativa de @everyone | apaga + timeout |
| Flood / mensagens repetidas | apaga as mensagens + timeout |

**Punições por acúmulo de avisos** (padrão): 3 avisos → timeout de 60 min · 5 → kick ·
ban automático desativado (`WARN_BAN_THRESHOLD=0`). Ajuste no `.env`.

**Anti-raid** — `RAID_JOIN_THRESHOLD` entradas em `RAID_JOIN_SECONDS` ativam o modo raid por
`RAID_MODE_MINUTES`: novos membros recebem DM e são expulsos; Head Moderators+ são mencionados em
`#staff-chat`. Encerra sozinho ou com `/raidmode off`.

**Logs administrativos** (`#staff-logs`) — mensagens apagadas/editadas, exclusões em massa,
cargos e apelidos de membros (com autor via auditoria), timeouts encerrados, bans/unbans manuais,
criação/edição/exclusão de canais e cargos, mudanças no servidor, tickets, denúncias, sugestões,
setup e todas as punições. Durante o `/setup install` os eventos ficam silenciados para não poluir.

---

## 5. Fluxo de atendimento recomendado

1. Ticket aberto → alguém da equipe clica **Assumir**.
2. Atendimento no canal; use `/ticket add` se precisar de outra pessoa.
3. Ao concluir, **Fechar** com um motivo curto. O transcript HTML fica em `#staff-logs` e vai por
   DM ao jogador.
4. Denúncias em `#staff-reports`: **Em análise** → **Resolvida**/**Rejeitada** (o denunciante é
   avisado por DM). Aplique a punição com os comandos de moderação.

---

## 6. Personalização

- **Textos** (regras, apresentação, painéis, boas-vindas): `core/content.py` → `/setup panels`.
  Referências como `<#open_a_ticket>` são trocadas pelo canal real automaticamente.
- **Cargos, cores, canais, permissões e tipos de ticket**: `core/blueprint.py` → `/setup install`.
  Rode `python -m pytest` depois de editar: o teste do blueprint aponta inconsistências.
- **Limites** (automod, avisos, anti-raid, Veteran, tickets por usuário): `.env` → reinicie o bot.
- Renomear canais/cargos manualmente é seguro: o vínculo é pelo ID salvo no banco. Porém,
  `/setup install` reaplica as permissões e configurações definidas no blueprint.

---

## 7. Segurança operacional

- O token fica só no `.env` (já no `.gitignore`). Se vazar: **Reset Token** imediatamente.
- Mantenha 2FA obrigatório para moderação (*Configurações → Segurança*).
- Dê Founder/Owner apenas a pessoas de confiança total — eles têm Administrador.
- Revise `#staff-logs` regularmente; alertas 🚨 indicam tentativas bloqueadas.

---

## 8. Banco de dados

`data/polybattle.db` (SQLite) guarda: configurações, IDs dos cargos/canais/painéis, tickets,
avisos, histórico de punições, sugestões e votos, denúncias, blocklist e estado do monitor de
atualizações. O schema é criado/migrado na inicialização. Faça backup com o bot desligado
(ou copie também os arquivos `-wal`/`-shm`).

---

## 9. Roteiro de homologação (servidor de teste)

Faça uma vez em um servidor de teste antes de usar no oficial:

1. `python bot.py --check` → tudo OK; `python bot.py` → "comandos sincronizados".
2. `/setup install` → confira cargos, ordem, cores, canais e painéis. Rode de novo: "Criados: 0".
3. `/setup status` → tudo 🟢.
4. Com uma conta secundária: só vê INFORMATION e verify → verifica → vê a comunidade; boas-vindas
   aparecem.
5. Abra um ticket de cada tipo e confira quem enxerga; assuma, adicione alguém, feche; confira o
   transcript em `#staff-logs` e na DM.
6. `/suggest`, vote, `/suggestion review`. Denuncie pelo painel e pelo menu de contexto.
7. `/warn` três vezes na conta secundária → timeout automático. `/unmute`, `/kick`, `/ban`, `/unban`.
8. Envie um convite `discord.gg/...` e um link `https://dlscord-test.com` com a conta secundária
   → mensagens apagadas e avisos registrados.
9. Crie um cargo de teste com "Gerenciar cargos" e "Banir membros", posicione-o acima de
   Moderator e dê à conta secundária. Com ela, dê o cargo Moderator a alguém → revertido com
   alerta 🚨. Depois ative "Banir membros" no cargo VIP → revertido. Apague o cargo de teste.
