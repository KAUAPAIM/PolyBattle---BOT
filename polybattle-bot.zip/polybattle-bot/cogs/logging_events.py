"""
Logs administrativos em #staff-logs.

Mensagens apagadas/editadas, alterações de cargos e apelidos de membros,
timeouts, banimentos/desbanimentos feitos fora do bot, criação/remoção/edição
de canais e cargos e alterações nas configurações do servidor.
"""

from __future__ import annotations

import asyncio
import datetime as dt
import logging

import discord
from discord.ext import commands

from core import blueprint as bp
from core import ui
from core.bot import PolyBattleBot
from core.text import truncate

log = logging.getLogger("polybattle.logs")


class LoggingEvents(commands.Cog):
    def __init__(self, bot: PolyBattleBot) -> None:
        self.bot = bot

    def _enabled(self, guild: discord.Guild | None) -> bool:
        return guild is not None and self.bot.is_setup(guild.id) and guild.id not in self.bot.quiet_guilds

    def _is_log_channel(self, channel: discord.abc.GuildChannel | discord.Thread) -> bool:
        logs = self.bot.channel(channel.guild, "staff_logs")
        return logs is not None and channel.id == logs.id

    async def _actor(self, guild: discord.Guild, action: discord.AuditLogAction, target_id: int) -> str:
        await asyncio.sleep(1.0)
        cutoff = dt.datetime.now(dt.timezone.utc) - dt.timedelta(seconds=30)
        try:
            async for entry in guild.audit_logs(limit=5, action=action):
                if entry.created_at < cutoff:
                    break
                if entry.target is not None and entry.target.id == target_id:
                    return ui.user_field(entry.user)
        except discord.Forbidden:
            pass
        return "desconhecido"

    # ------------------------------------------------------------------ mensagens
    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message) -> None:
        if message.author.bot or not self._enabled(message.guild) or self._is_log_channel(message.channel):
            return
        embed = ui.log_embed("🗑️ Mensagem apagada | Message deleted",
                             truncate(message.content, 3500) or "*(sem texto)*",
                             color=bp.COLOR_GRAY, user=message.author)
        embed.add_field(name="Canal", value=message.channel.mention)  # type: ignore[union-attr]
        if message.attachments:
            embed.add_field(name="Anexos", value=truncate("\n".join(a.filename for a in message.attachments), 1024))
        await self.bot.send_log(message.guild, embed)  # type: ignore[arg-type]

    @commands.Cog.listener()
    async def on_bulk_message_delete(self, messages: list[discord.Message]) -> None:
        if not messages or not self._enabled(messages[0].guild):
            return
        channel = messages[0].channel
        await self.bot.send_log(messages[0].guild, ui.log_embed(  # type: ignore[arg-type]
            "🧹 Exclusão em massa | Bulk delete", f"{len(messages)} mensagens em {channel.mention}",  # type: ignore[union-attr]
            color=bp.COLOR_GRAY))

    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message) -> None:
        if after.author.bot or not self._enabled(after.guild) or before.content == after.content:
            return
        embed = ui.log_embed("✏️ Mensagem editada | Message edited", color=bp.COLOR_GRAY, user=after.author)
        embed.add_field(name="Antes", value=truncate(before.content, 1024) or "—", inline=False)
        embed.add_field(name="Depois", value=truncate(after.content, 1024) or "—", inline=False)
        embed.add_field(name="Link", value=after.jump_url, inline=False)
        await self.bot.send_log(after.guild, embed)  # type: ignore[arg-type]

    # ------------------------------------------------------------------ membros
    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member) -> None:
        guild = after.guild
        if not self._enabled(guild):
            return
        if before.roles != after.roles:
            added = [r.mention for r in after.roles if r not in before.roles]
            removed = [r.mention for r in before.roles if r not in after.roles]
            desc = ""
            if added:
                desc += f"➕ {' '.join(added)}\n"
            if removed:
                desc += f"➖ {' '.join(removed)}"
            actor = await self._actor(guild, discord.AuditLogAction.member_role_update, after.id)
            embed = ui.log_embed("🎖️ Cargos alterados | Roles updated", desc, user=after)
            embed.add_field(name="Por", value=actor)
            await self.bot.send_log(guild, embed)
        if before.nick != after.nick:
            await self.bot.send_log(guild, ui.log_embed(
                "🏷️ Apelido alterado | Nickname changed",
                f"`{before.nick or before.name}` → `{after.nick or after.name}`", user=after))
        if before.timed_out_until != after.timed_out_until and after.timed_out_until is None and before.is_timed_out():
            await self.bot.send_log(guild, ui.log_embed("🔊 Timeout encerrado", after.mention, user=after,
                                                        color=bp.COLOR_GREEN_LIGHT))

    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: discord.User) -> None:
        if not self._enabled(guild):
            return
        actor = await self._actor(guild, discord.AuditLogAction.ban, user.id)
        if str(guild.me.id) in actor:
            return  # já registrado pelo módulo de moderação
        await self.bot.send_log(guild, ui.log_embed("🔨 Banimento (manual)", f"Por: {actor}", user=user,
                                                    color=bp.COLOR_DANGER))

    @commands.Cog.listener()
    async def on_member_unban(self, guild: discord.Guild, user: discord.User) -> None:
        if not self._enabled(guild):
            return
        actor = await self._actor(guild, discord.AuditLogAction.unban, user.id)
        if str(guild.me.id) in actor:
            return
        await self.bot.send_log(guild, ui.log_embed("♻️ Desbanimento (manual)", f"Por: {actor}", user=user,
                                                    color=bp.COLOR_GREEN_LIGHT))

    # ------------------------------------------------------------------ canais
    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: discord.abc.GuildChannel) -> None:
        if not self._enabled(channel.guild):
            return
        actor = await self._actor(channel.guild, discord.AuditLogAction.channel_create, channel.id)
        await self.bot.send_log(channel.guild, ui.log_embed(
            "📁 Canal criado", f"{channel.mention} (`{channel.name}`)\nPor: {actor}"))

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel) -> None:
        if not self._enabled(channel.guild) or self._is_log_channel(channel):
            return
        actor = await self._actor(channel.guild, discord.AuditLogAction.channel_delete, channel.id)
        await self.bot.send_log(channel.guild, ui.log_embed(
            "🗑️ Canal excluído", f"`{channel.name}`\nPor: {actor}", color=bp.COLOR_WARNING))

    @commands.Cog.listener()
    async def on_guild_channel_update(self, before: discord.abc.GuildChannel,
                                      after: discord.abc.GuildChannel) -> None:
        if not self._enabled(after.guild):
            return
        changes = []
        if before.name != after.name:
            changes.append(f"Nome: `{before.name}` → `{after.name}`")
        if before.overwrites != after.overwrites:
            changes.append("Permissões alteradas")
        if not changes:
            return
        actor_action = (discord.AuditLogAction.channel_update if before.name != after.name
                        else discord.AuditLogAction.overwrite_update)
        actor = await self._actor(after.guild, actor_action, after.id)
        await self.bot.send_log(after.guild, ui.log_embed(
            "🛠️ Canal alterado", f"{after.mention}\n" + "\n".join(changes) + f"\nPor: {actor}"))

    # ------------------------------------------------------------------ cargos / servidor
    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role) -> None:
        if self._enabled(role.guild):
            await self.bot.send_log(role.guild, ui.log_embed("➕ Cargo criado", f"{role.mention} (`{role.name}`)"))

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role) -> None:
        if not self._enabled(role.guild):
            return
        actor = await self._actor(role.guild, discord.AuditLogAction.role_delete, role.id)
        await self.bot.send_log(role.guild, ui.log_embed("➖ Cargo excluído", f"`{role.name}`\nPor: {actor}",
                                                         color=bp.COLOR_WARNING))

    @commands.Cog.listener()
    async def on_guild_role_update(self, before: discord.Role, after: discord.Role) -> None:
        if not self._enabled(after.guild):
            return
        changes = []
        if before.name != after.name:
            changes.append(f"Nome: `{before.name}` → `{after.name}`")
        if before.permissions != after.permissions:
            gained = [n for n, v in after.permissions if v and not getattr(before.permissions, n)]
            lost = [n for n, v in before.permissions if v and not getattr(after.permissions, n)]
            if gained:
                changes.append(f"➕ `{', '.join(gained)}`")
            if lost:
                changes.append(f"➖ `{', '.join(lost)}`")
        if before.colour != after.colour:
            changes.append(f"Cor: {before.colour} → {after.colour}")
        if not changes:
            return
        actor = await self._actor(after.guild, discord.AuditLogAction.role_update, after.id)
        await self.bot.send_log(after.guild, ui.log_embed(
            "🛠️ Cargo alterado", f"{after.mention}\n" + "\n".join(changes) + f"\nPor: {actor}"))

    @commands.Cog.listener()
    async def on_guild_update(self, before: discord.Guild, after: discord.Guild) -> None:
        if not self._enabled(after):
            return
        changes = []
        if before.name != after.name:
            changes.append(f"Nome: `{before.name}` → `{after.name}`")
        if before.verification_level != after.verification_level:
            changes.append(f"Nível de verificação: {before.verification_level} → {after.verification_level}")
        if before.owner_id != after.owner_id:
            changes.append(f"Dono: <@{before.owner_id}> → <@{after.owner_id}>")
        if changes:
            await self.bot.send_log(after, ui.log_embed("🏛️ Servidor alterado", "\n".join(changes),
                                                        color=bp.COLOR_WARNING))


async def setup(bot: PolyBattleBot) -> None:
    await bot.add_cog(LoggingEvents(bot))
