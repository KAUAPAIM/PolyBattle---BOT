"""
Comunicados e atualizações do jogo.

* /announce   — comunicado oficial em #announcements (formulário).
* /changelog  — notas de atualização em #changelog, com aviso opcional em #announcements.
* /devupdate  — publicação em #development-updates ou #upcoming-features.
* /gamestatus — jogadores online e visitas (API pública do Roblox).
* Monitor automático: se ROBLOX_UNIVERSE_ID estiver definido, o bot consulta a
  API do Roblox a cada UPDATE_CHECK_MINUTES e publica em #changelog quando o
  jogo recebe uma nova versão.
"""

from __future__ import annotations

import datetime as dt
import logging
from typing import Optional

import aiohttp
import discord
from discord import app_commands
from discord.ext import commands, tasks

from core import blueprint as bp
from core import ui
from core.bot import BaseModal, PolyBattleBot, require_roles, respond
from core.text import truncate

log = logging.getLogger("polybattle.announcements")

ROBLOX_GAMES_API = "https://games.roblox.com/v1/games?universeIds={universe_id}"
PING_CHOICES = [
    app_commands.Choice(name="Sem menção | No ping", value="none"),
    app_commands.Choice(name="@here", value="here"),
    app_commands.Choice(name="@everyone", value="everyone"),
]


def _ping_content(ping: str) -> tuple[str | None, discord.AllowedMentions]:
    if ping == "everyone":
        return "@everyone", discord.AllowedMentions(everyone=True)
    if ping == "here":
        return "@here", discord.AllowedMentions(everyone=True)
    return None, discord.AllowedMentions.none()


def _valid_image(url: str) -> bool:
    return url.startswith("https://") and len(url) < 1000


class AnnounceModal(BaseModal, title="Comunicado oficial | Announcement"):
    heading = discord.ui.TextInput(label="Título | Title", max_length=200)
    body = discord.ui.TextInput(label="Mensagem | Message", style=discord.TextStyle.paragraph, max_length=3800)
    image = discord.ui.TextInput(label="URL da imagem (opcional) | Image URL", required=False, max_length=500)

    def __init__(self, cog: "Announcements", ping: str) -> None:
        super().__init__()
        self.cog = cog
        self.ping = ping

    async def on_submit(self, interaction: discord.Interaction) -> None:
        embed = ui.brand(f"📢 {self.heading.value}", str(self.body.value), color=bp.COLOR_GREEN)
        if self.image.value and _valid_image(str(self.image.value)):
            embed.set_image(url=str(self.image.value))
        embed.set_author(name="POLYBATTLE COMMAND")
        await self.cog.post(interaction, "announcements", embed, self.ping, "Comunicado")


class ChangelogModal(BaseModal, title="Changelog"):
    version = discord.ui.TextInput(label="Versão | Version", max_length=30, placeholder="v1.4.0")
    heading = discord.ui.TextInput(label="Título | Title", max_length=150, placeholder="Operation Nightfall")
    changes = discord.ui.TextInput(label="Mudanças (uma por linha) | Changes", style=discord.TextStyle.paragraph,
                                   max_length=3500, placeholder="+ Nova arma\n* Correção no mapa\n- Removido X")

    def __init__(self, cog: "Announcements", ping: str, notify: bool) -> None:
        super().__init__()
        self.cog = cog
        self.ping = ping
        self.notify = notify

    async def on_submit(self, interaction: discord.Interaction) -> None:
        lines = []
        for raw in str(self.changes.value).splitlines():
            line = raw.strip()
            if not line:
                continue
            if line[0] in "+-*":
                icon = {"+": "🟢", "-": "🔴", "*": "🟡"}[line[0]]
                line = f"{icon} {line[1:].strip()}"
            else:
                line = f"▪️ {line}"
            lines.append(line)
        embed = ui.brand(f"🛠 PATCH {self.version.value} — {self.heading.value}", truncate("\n".join(lines), 4000))
        embed.set_author(name="POLYBATTLE CHANGELOG")
        embed.add_field(name="Legenda", value="🟢 Adicionado • 🟡 Alterado/Corrigido • 🔴 Removido", inline=False)
        await self.cog.post(interaction, "changelog", embed, self.ping, f"Changelog {self.version.value}",
                            also_announce=self.notify)


class DevUpdateModal(BaseModal, title="Development update"):
    heading = discord.ui.TextInput(label="Título | Title", max_length=200)
    body = discord.ui.TextInput(label="Conteúdo | Content", style=discord.TextStyle.paragraph, max_length=3800)
    image = discord.ui.TextInput(label="URL da imagem (opcional) | Image URL", required=False, max_length=500)

    def __init__(self, cog: "Announcements", channel_key: str) -> None:
        super().__init__()
        self.cog = cog
        self.channel_key = channel_key

    async def on_submit(self, interaction: discord.Interaction) -> None:
        icon = "🧪" if self.channel_key == "development_updates" else "🚀"
        embed = ui.brand(f"{icon} {self.heading.value}", str(self.body.value))
        if self.image.value and _valid_image(str(self.image.value)):
            embed.set_image(url=str(self.image.value))
        embed.set_author(name=str(interaction.user), icon_url=interaction.user.display_avatar.url)
        await self.cog.post(interaction, self.channel_key, embed, "none", "Dev update")


class Announcements(commands.Cog):
    def __init__(self, bot: PolyBattleBot) -> None:
        self.bot = bot
        self.session: aiohttp.ClientSession | None = None

    async def cog_load(self) -> None:
        self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15),
                                             headers={"User-Agent": "PolyBattleBot/1.0"})
        if self.bot.settings.roblox_universe_id:
            self.update_watcher.change_interval(minutes=self.bot.settings.update_check_minutes)
            self.update_watcher.start()

    async def cog_unload(self) -> None:
        self.update_watcher.cancel()
        if self.session:
            await self.session.close()

    # ------------------------------------------------------------------ publicação
    async def post(self, interaction: discord.Interaction, channel_key: str, embed: discord.Embed, ping: str,
                   label: str, *, also_announce: bool = False) -> None:
        guild = interaction.guild
        if guild is None:
            return
        channel = self.bot.channel(guild, channel_key)
        if not isinstance(channel, discord.TextChannel):
            await respond(interaction, ui.error("Canal de destino não configurado. Rode /setup install."))
            return
        content, mentions = _ping_content(ping)
        msg = await channel.send(content=content, embed=embed, allowed_mentions=mentions)
        if channel.is_news():
            try:
                await msg.publish()
            except discord.HTTPException:
                pass
        if also_announce:
            ann = self.bot.channel(guild, "announcements")
            if isinstance(ann, discord.TextChannel) and ann.id != channel.id:
                short = ui.brand("🛠 Nova atualização disponível | New update",
                                 f"{embed.title}\n\nConfira as notas completas: {msg.jump_url}")
                await ann.send(content=content, embed=short, allowed_mentions=mentions)
        await respond(interaction, ui.success(f"{label} publicado em {channel.mention}."))
        await self.bot.send_log(guild, ui.log_embed(f"📢 {label} publicado", msg.jump_url, user=interaction.user))

    @app_commands.command(name="announce", description="Publica um comunicado oficial em #announcements")
    @app_commands.choices(ping=PING_CHOICES)
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_guild=True)
    @require_roles(*bp.ADMIN_ROLES)
    async def announce(self, interaction: discord.Interaction,
                       ping: Optional[app_commands.Choice[str]] = None) -> None:
        await interaction.response.send_modal(AnnounceModal(self, ping.value if ping else "none"))

    @app_commands.command(name="changelog", description="Publica notas de atualização em #changelog")
    @app_commands.describe(ping="Menção no aviso", notify="Também avisar em #announcements")
    @app_commands.choices(ping=PING_CHOICES)
    @app_commands.guild_only()
    @require_roles(*bp.ADMIN_ROLES, "developer")
    async def changelog(self, interaction: discord.Interaction, ping: Optional[app_commands.Choice[str]] = None,
                        notify: bool = True) -> None:
        await interaction.response.send_modal(ChangelogModal(self, ping.value if ping else "none", notify))

    @app_commands.command(name="devupdate", description="Publica em #development-updates ou #upcoming-features")
    @app_commands.choices(channel=[
        app_commands.Choice(name="development-updates", value="development_updates"),
        app_commands.Choice(name="upcoming-features", value="upcoming_features"),
    ])
    @app_commands.guild_only()
    @require_roles(*bp.ADMIN_ROLES, "developer")
    async def devupdate(self, interaction: discord.Interaction, channel: app_commands.Choice[str]) -> None:
        await interaction.response.send_modal(DevUpdateModal(self, channel.value))

    # ------------------------------------------------------------------ Roblox
    async def fetch_game(self) -> dict | None:
        uid = self.bot.settings.roblox_universe_id
        if not uid or self.session is None:
            return None
        try:
            async with self.session.get(ROBLOX_GAMES_API.format(universe_id=uid)) as resp:
                if resp.status != 200:
                    log.warning("API do Roblox respondeu %s", resp.status)
                    return None
                data = await resp.json()
        except (aiohttp.ClientError, TimeoutError, ValueError) as exc:
            log.warning("Falha ao consultar a API do Roblox: %s", exc)
            return None
        items = data.get("data") or []
        return items[0] if items else None

    @app_commands.command(name="gamestatus", description="Status do PolyBattle no Roblox (jogadores e visitas)")
    @app_commands.guild_only()
    async def gamestatus(self, interaction: discord.Interaction) -> None:
        if not self.bot.settings.roblox_universe_id:
            await respond(interaction, ui.error("ROBLOX_UNIVERSE_ID não configurado no .env."))
            return
        await interaction.response.defer(ephemeral=True)
        game = await self.fetch_game()
        if game is None:
            await respond(interaction, ui.error("Não foi possível consultar o Roblox agora."))
            return
        embed = ui.brand(f"🎮 {game.get('name', self.bot.settings.game_name)}")
        embed.add_field(name="🟢 Jogando agora | Playing", value=f"{game.get('playing', 0):,}".replace(",", "."))
        embed.add_field(name="👁️ Visitas | Visits", value=f"{game.get('visits', 0):,}".replace(",", "."))
        embed.add_field(name="⭐ Favoritos | Favorites", value=f"{game.get('favoritedCount', 0):,}".replace(",", "."))
        updated = game.get("updated")
        if updated:
            try:
                ts = dt.datetime.fromisoformat(updated.replace("Z", "+00:00"))
                embed.add_field(name="🛠 Última atualização", value=f"<t:{int(ts.timestamp())}:R>", inline=False)
            except ValueError:
                pass
        if self.bot.settings.roblox_game_url:
            embed.url = self.bot.settings.roblox_game_url
        await respond(interaction, embed)

    @tasks.loop(minutes=10)
    async def update_watcher(self) -> None:
        game = await self.fetch_game()
        if not game or not game.get("updated"):
            return
        key = f"roblox_updated:{self.bot.settings.roblox_universe_id}"
        last = await self.bot.db.get_state(key)
        current = str(game["updated"])
        if last == current:
            return
        await self.bot.db.set_state(key, current)
        if last is None:
            log.info("Monitor de atualizações inicializado (%s)", current)
            return  # primeira execução: apenas grava a referência
        name = game.get("name", self.bot.settings.game_name)
        for guild in self.bot.guilds:
            channel = self.bot.channel(guild, "changelog")
            if not isinstance(channel, discord.TextChannel):
                continue
            embed = ui.brand(f"🛠 {name} foi atualizado | {name} has been updated",
                             "Uma nova versão do jogo acabou de ser publicada no Roblox. "
                             "Reinicie o jogo para receber as novidades.\n\n"
                             "A new version has just been published on Roblox. Rejoin to get the latest changes.")
            view = None
            url = self.bot.settings.roblox_game_url
            if url.startswith("https://"):
                view = discord.ui.View()
                view.add_item(discord.ui.Button(label="Jogar | Play", url=url, emoji="🎮"))
            try:
                if view is not None:
                    await channel.send(embed=embed, view=view)
                else:
                    await channel.send(embed=embed)
            except discord.HTTPException as exc:
                log.warning("Falha ao publicar atualização automática: %s", exc)

    @update_watcher.before_loop
    async def _before_watcher(self) -> None:
        await self.bot.wait_until_ready()


async def setup(bot: PolyBattleBot) -> None:
    await bot.add_cog(Announcements(bot))
