"""
Boas-vindas automáticas e registro de entradas e saídas.

* Entrada: DM com instruções de verificação + log em #staff-logs.
* Verificação concluída: mensagem pública de boas-vindas em #general-chat.
* Saída: log com tempo de permanência e cargos que o membro possuía.
"""

from __future__ import annotations

import datetime as dt
import logging

import discord
from discord.ext import commands

from core import blueprint as bp
from core import content, ui
from core.bot import PolyBattleBot
from core.text import truncate

log = logging.getLogger("polybattle.welcome")


class Welcome(commands.Cog):
    def __init__(self, bot: PolyBattleBot) -> None:
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        if member.bot or not self.bot.is_setup(member.guild.id):
            return
        age = dt.datetime.now(dt.timezone.utc) - member.created_at
        new_account = age < dt.timedelta(days=7)
        embed = ui.log_embed(
            "📥 Membro entrou | Member joined",
            f"{member.mention}\nConta criada <t:{int(member.created_at.timestamp())}:R>"
            + ("\n⚠️ **Conta recente**" if new_account else "")
            + f"\nTotal de membros: **{member.guild.member_count}**",
            color=bp.COLOR_WARNING if new_account else bp.COLOR_GREEN_LIGHT,
            user=member,
        )
        await self.bot.send_log(member.guild, embed)

        automod = self.bot.get_cog("AutoMod")
        if automod is not None and automod.raid_active(member.guild.id):  # type: ignore[attr-defined]
            return  # durante raid o anti-raid envia o próprio aviso
        dm = ui.brand(f"🪖 {content.SERVER_NAME}", content.WELCOME_DM.format(name=member.display_name))
        try:
            await member.send(embed=dm)
        except (discord.Forbidden, discord.HTTPException):
            pass  # DMs fechadas: o painel de #verify continua disponível

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member) -> None:
        if member.bot or not self.bot.is_setup(member.guild.id):
            return
        stayed = "—"
        if member.joined_at:
            stayed = f"entrou <t:{int(member.joined_at.timestamp())}:R>"
        roles = [r.mention for r in reversed(member.roles) if r != member.guild.default_role]
        embed = ui.log_embed(
            "📤 Membro saiu | Member left",
            f"{member.mention} — {stayed}\nCargos: {truncate(' '.join(roles), 900) or 'nenhum'}",
            color=bp.COLOR_GRAY, user=member,
        )
        await self.bot.send_log(member.guild, embed)

    @commands.Cog.listener()
    async def on_member_verified(self, member: discord.Member) -> None:
        guild = member.guild
        channel = self.bot.channel(guild, "general_chat")
        if isinstance(channel, discord.TextChannel):
            embed = ui.brand(
                "🎖️ NOVO RECRUTA | NEW RECRUIT",
                content.WELCOME_PUBLIC.format(mention=member.mention, count=guild.member_count),
            )
            embed.set_thumbnail(url=member.display_avatar.url)
            try:
                await channel.send(content=member.mention, embed=embed,
                                   allowed_mentions=discord.AllowedMentions(users=[member]))
            except discord.HTTPException as exc:
                log.warning("Falha ao enviar boas-vindas: %s", exc)
        await self.bot.send_log(guild, ui.log_embed(
            "✅ Membro verificado | Member verified", member.mention, color=bp.COLOR_GREEN_LIGHT, user=member))


async def setup(bot: PolyBattleBot) -> None:
    await bot.add_cog(Welcome(bot))
