"""
Proteção contra escalonamento indevido de permissões.

* Cargos protegidos (staff/dev/VIP) só podem ser concedidos por quem está em
  ``GRANT_RULES`` (core/blueprint.py). Concessões fora da regra são revertidas
  e registradas com alerta.
* Se qualquer cargo ganhar permissões perigosas (Administrador, Gerenciar
  Servidor/Cargos/Canais, Banir…) por alguém que não seja de confiança, a
  alteração é revertida.
* Cargos novos criados com permissões perigosas por não confiáveis têm essas
  permissões removidas.
* Entrada de outros bots é registrada com quem os adicionou.

"De confiança" = dono do servidor, o próprio bot, membros com permissão de
Administrador ou com os cargos Founder/Owner.
"""

from __future__ import annotations

import asyncio
import datetime as dt
import logging

import discord
from discord.ext import commands

from core import blueprint as bp
from core import ui
from core.bot import PolyBattleBot

log = logging.getLogger("polybattle.security")

AUDIT_DELAY = 1.5      # aguarda o registro de auditoria ser gravado
AUDIT_WINDOW = 30      # segundos

_DANGEROUS_VALUE = discord.Permissions(**{p: True for p in bp.DANGEROUS_PERMS}).value


def dangerous_gained(before: discord.Permissions, after: discord.Permissions) -> list[str]:
    gained = after.value & ~before.value & _DANGEROUS_VALUE
    return [name for name, value in discord.Permissions(gained) if value]


class Security(commands.Cog):
    def __init__(self, bot: PolyBattleBot) -> None:
        self.bot = bot
        self._reverting: set[int] = set()  # ids de cargos sendo revertidos (evita laço)

    # ------------------------------------------------------------------ util
    def is_trusted(self, guild: discord.Guild, user: discord.abc.User | None) -> bool:
        if user is None:
            return False
        if user.id in (guild.owner_id, guild.me.id):
            return True
        member = guild.get_member(user.id)
        if member is None:
            return False
        return member.guild_permissions.administrator or self.bot.member_has_any(member, ("founder", "owner"))

    async def _find_actor(self, guild: discord.Guild, action: discord.AuditLogAction, target_id: int,
                          predicate=None) -> discord.AuditLogEntry | None:
        await asyncio.sleep(AUDIT_DELAY)
        cutoff = dt.datetime.now(dt.timezone.utc) - dt.timedelta(seconds=AUDIT_WINDOW)
        try:
            async for entry in guild.audit_logs(limit=10, action=action):
                if entry.created_at < cutoff:
                    break
                if entry.target is not None and entry.target.id == target_id and (predicate is None or predicate(entry)):
                    return entry
        except discord.Forbidden:
            log.warning("Sem permissão para ler o registro de auditoria em %s", guild.id)
        return None

    async def _alert(self, guild: discord.Guild, title: str, description: str) -> None:
        await self.bot.send_log(guild, ui.log_embed(title, description, color=bp.COLOR_DANGER))

    # ------------------------------------------------------------------ concessão de cargos
    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member) -> None:
        guild = after.guild
        if not self.bot.is_setup(guild.id):
            return
        added = set(after.roles) - set(before.roles)
        if not added:
            return
        protected = {}
        for key in bp.GRANT_RULES:
            role = self.bot.role(guild, key)
            if role is not None and role in added:
                protected[key] = role
        if not protected:
            return

        entry = await self._find_actor(
            guild, discord.AuditLogAction.member_role_update, after.id,
            lambda e: any(r.id in {p.id for p in protected.values()} for r in getattr(e.after, "roles", []) or []),
        )
        if entry is None:
            await self._alert(guild, "⚠️ Cargo protegido concedido (autor desconhecido)",
                              f"{after.mention} recebeu {', '.join(r.mention for r in protected.values())}, "
                              "mas o autor não foi encontrado no registro de auditoria.")
            return
        actor = entry.user
        if self.is_trusted(guild, actor):
            return
        actor_member = guild.get_member(actor.id) if actor else None
        to_remove = []
        for key, role in protected.items():
            allowed = actor_member is not None and self.bot.member_has_any(actor_member, bp.GRANT_RULES[key])
            if not allowed:
                to_remove.append(role)
        if not to_remove:
            await self.bot.send_log(guild, ui.log_embed(
                "🎖️ Cargo protegido concedido",
                f"{after.mention} recebeu {', '.join(r.mention for r in protected.values())} de {actor.mention}",  # type: ignore[union-attr]
                color=bp.COLOR_WARNING))
            return
        try:
            await after.remove_roles(*to_remove, reason=f"Segurança: concessão não autorizada por {actor}")
            result = "Revertido automaticamente."
        except discord.HTTPException as exc:
            result = f"⛔ Não foi possível reverter: {exc}"
        await self._alert(guild, "🚨 Escalonamento de permissão bloqueado",
                          f"**Autor:** {ui.user_field(actor)}\n**Alvo:** {ui.user_field(after)}\n"
                          f"**Cargos:** {', '.join(r.mention for r in to_remove)}\n{result}")

    # ------------------------------------------------------------------ permissões de cargos
    @commands.Cog.listener()
    async def on_guild_role_update(self, before: discord.Role, after: discord.Role) -> None:
        guild = after.guild
        if after.id in self._reverting or not self.bot.is_setup(guild.id):
            return
        gained = dangerous_gained(before.permissions, after.permissions)
        if not gained:
            return
        entry = await self._find_actor(guild, discord.AuditLogAction.role_update, after.id)
        actor = entry.user if entry else None
        if entry is not None and self.is_trusted(guild, actor):
            await self.bot.send_log(guild, ui.log_embed(
                "🔐 Permissões perigosas concedidas a cargo",
                f"{after.mention}: `{', '.join(gained)}` por {actor.mention}",  # type: ignore[union-attr]
                color=bp.COLOR_WARNING))
            return
        if entry is None:
            await self._alert(guild, "⚠️ Cargo ganhou permissões perigosas (autor desconhecido)",
                              f"{after.mention}: `{', '.join(gained)}` — verifique manualmente.")
            return
        if after >= guild.me.top_role:
            await self._alert(guild, "🚨 Alteração perigosa em cargo acima do bot",
                              f"{after.mention}: `{', '.join(gained)}` por {ui.user_field(actor)}. "
                              "Não foi possível reverter (hierarquia).")
            return
        self._reverting.add(after.id)
        try:
            await after.edit(permissions=before.permissions, reason=f"Segurança: alteração não autorizada por {actor}")
            result = "Revertido automaticamente."
        except discord.HTTPException as exc:
            result = f"⛔ Não foi possível reverter: {exc}"
        finally:
            await asyncio.sleep(2)
            self._reverting.discard(after.id)
        await self._alert(guild, "🚨 Alteração de permissões bloqueada",
                          f"**Cargo:** {after.mention}\n**Permissões:** `{', '.join(gained)}`\n"
                          f"**Autor:** {ui.user_field(actor)}\n{result}")

    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role) -> None:
        guild = role.guild
        if role.managed or not self.bot.is_setup(guild.id):
            return
        gained = dangerous_gained(discord.Permissions.none(), role.permissions)
        if not gained:
            return
        entry = await self._find_actor(guild, discord.AuditLogAction.role_create, role.id)
        actor = entry.user if entry else None
        if self.is_trusted(guild, actor):
            return
        safe = discord.Permissions(role.permissions.value & ~_DANGEROUS_VALUE)
        self._reverting.add(role.id)
        try:
            await role.edit(permissions=safe, reason="Segurança: cargo criado com permissões perigosas")
            result = "Permissões perigosas removidas."
        except discord.HTTPException as exc:
            result = f"⛔ Não foi possível corrigir: {exc}"
        finally:
            await asyncio.sleep(2)
            self._reverting.discard(role.id)
        await self._alert(guild, "🚨 Cargo perigoso criado",
                          f"**Cargo:** {role.mention}\n**Permissões:** `{', '.join(gained)}`\n"
                          f"**Autor:** {ui.user_field(actor)}\n{result}")

    # ------------------------------------------------------------------ bots
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        if not member.bot or not self.bot.is_setup(member.guild.id):
            return
        entry = await self._find_actor(member.guild, discord.AuditLogAction.bot_add, member.id)
        actor = entry.user if entry else None
        await self._alert(member.guild, "🤖 Bot adicionado ao servidor",
                          f"**Bot:** {ui.user_field(member)}\n**Adicionado por:** {ui.user_field(actor)}")


async def setup(bot: PolyBattleBot) -> None:
    await bot.add_cog(Security(bot))
