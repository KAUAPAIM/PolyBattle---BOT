"""
Instalação e configuração inicial do servidor.

/setup install  — cria/atualiza cargos, categorias, canais, permissões e painéis.
/setup panels   — republica os painéis (regras, verificação, tickets, etc.).
/setup status   — diagnóstico de permissões, hierarquia e recursos ausentes.

Todo o processo é idempotente: os IDs criados ficam salvos no banco e são
reutilizados em execuções futuras, evitando cargos e canais duplicados.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field

import discord
from discord import app_commands
from discord.ext import commands

from core import blueprint as bp
from core import content, ui
from core.bot import BaseView, PolyBattleBot, respond
from core.text import resolve_channel_refs

log = logging.getLogger("polybattle.setup")


@dataclass
class SetupReport:
    created: list[str] = field(default_factory=list)
    updated: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def summary(self) -> str:
        lines = [
            f"**Criados | Created:** {len(self.created)}",
            f"**Atualizados | Updated:** {len(self.updated)}",
        ]
        if self.created:
            lines.append("```" + ", ".join(self.created)[:900] + "```")
        if self.warnings:
            lines.append("**⚠️ Avisos | Warnings:**")
            lines.extend(f"• {w}" for w in self.warnings[:15])
        return "\n".join(lines)


def build_permissions(names: frozenset[str] | set[str]) -> discord.Permissions:
    return discord.Permissions(**{name: True for name in names})


class ConfirmView(BaseView):
    def __init__(self, author_id: int) -> None:
        super().__init__(timeout=60)
        self.author_id = author_id
        self.confirmed: bool | None = None

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message("Apenas quem executou o comando pode confirmar.",
                                                    ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Confirmar instalação", style=discord.ButtonStyle.success, emoji="✅")
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.confirmed = True
        await interaction.response.edit_message(
            embed=ui.brand("⚙️ Instalando… | Installing…",
                           "Isso pode levar alguns minutos. | This may take a few minutes."),
            view=None,
        )
        self.stop()

    @discord.ui.button(label="Cancelar", style=discord.ButtonStyle.secondary, emoji="✖️")
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.confirmed = False
        await interaction.response.edit_message(embed=ui.warning("Instalação cancelada."), view=None)
        self.stop()


class Setup(commands.Cog):
    setup_group = app_commands.Group(
        name="setup",
        description="Instalação e manutenção da estrutura do servidor",
        guild_only=True,
        default_permissions=discord.Permissions(administrator=True),
    )

    def __init__(self, bot: PolyBattleBot) -> None:
        self.bot = bot
        self._locks: dict[int, asyncio.Lock] = {}

    # ------------------------------------------------------------------ validações
    @staticmethod
    def _authorized(interaction: discord.Interaction) -> bool:
        member = interaction.user
        return isinstance(member, discord.Member) and (
            member.id == member.guild.owner_id or member.guild_permissions.administrator
        )

    @staticmethod
    def _bot_ready_error(guild: discord.Guild) -> str | None:
        me = guild.me
        if not me.guild_permissions.administrator:
            return ("O bot precisa da permissão **Administrador** para criar cargos com permissões e "
                    "aplicar overwrites. Reconvide o bot com o link do README ou ative a permissão no "
                    "cargo do bot.")
        return None

    # ------------------------------------------------------------------ cargos
    async def _ensure_roles(self, guild: discord.Guild, report: SetupReport) -> dict[str, discord.Role]:
        db = self.bot.db
        me = guild.me
        roles: dict[str, discord.Role] = {}
        for spec in bp.ROLES:
            stored = await db.get_resource(guild.id, "role", spec.key)
            role = guild.get_role(stored) if stored else None
            if role is None:
                role = discord.utils.get(guild.roles, name=spec.name)
            perms = build_permissions(spec.permissions)
            if role is None:
                role = await guild.create_role(
                    name=spec.name, colour=discord.Colour(spec.color), permissions=perms,
                    hoist=spec.hoist, mentionable=spec.mentionable,
                    reason="PolyBattle setup: criação de cargo",
                )
                report.created.append(f"@{spec.name}")
            elif role.managed:
                report.warnings.append(f"O cargo {role.name} é gerenciado por uma integração e foi ignorado.")
                continue
            elif role >= me.top_role:
                report.warnings.append(
                    f"O cargo **{role.name}** está acima do cargo do bot; permissões não foram ajustadas. "
                    "Mova o cargo do bot para o topo da lista."
                )
            elif (role.permissions != perms or role.colour.value != spec.color
                  or role.hoist != spec.hoist or role.mentionable != spec.mentionable):
                await role.edit(permissions=perms, colour=discord.Colour(spec.color), hoist=spec.hoist,
                                mentionable=spec.mentionable, reason="PolyBattle setup: sincronização")
                report.updated.append(f"@{role.name}")
            await db.set_resource(guild.id, "role", spec.key, role.id)
            roles[spec.key] = role
        await self._order_roles(guild, roles, report)
        return roles

    async def _order_roles(self, guild: discord.Guild, roles: dict[str, discord.Role],
                           report: SetupReport) -> None:
        me = guild.me
        movable = [roles[s.key] for s in bp.ROLES if s.key in roles and roles[s.key] < me.top_role]
        if not movable:
            return
        current = sorted(movable, key=lambda r: r.position, reverse=True)
        if current == movable and all(r.position < me.top_role.position for r in movable):
            return
        top = me.top_role.position - 1
        positions = {role: max(1, top - i) for i, role in enumerate(movable)}
        try:
            await guild.edit_role_positions(positions=positions, reason="PolyBattle setup: hierarquia")
            report.updated.append("hierarquia de cargos")
        except discord.HTTPException as exc:
            report.warnings.append(f"Não foi possível reordenar os cargos: {exc.text or exc}")

    # ------------------------------------------------------------------ canais
    @staticmethod
    def _overwrites(guild: discord.Guild, roles: dict[str, discord.Role],
                    spec: dict[str, dict[str, bool]]) -> dict[discord.Role, discord.PermissionOverwrite]:
        result: dict[discord.Role, discord.PermissionOverwrite] = {}
        for target, perms in spec.items():
            obj = guild.default_role if target == "@everyone" else roles.get(target)
            if obj is not None:
                result[obj] = discord.PermissionOverwrite(**perms)
        return result

    async def _find(self, guild: discord.Guild, kind: str, key: str, name: str, cls: type):
        stored = await self.bot.db.get_resource(guild.id, kind, key)
        ch = guild.get_channel(stored) if stored else None
        if isinstance(ch, cls):
            return ch
        ch = discord.utils.get(guild.channels, name=name)
        return ch if isinstance(ch, cls) else None

    async def _ensure_channels(self, guild: discord.Guild, roles: dict[str, discord.Role],
                               report: SetupReport) -> None:
        db = self.bot.db
        for cat_spec in bp.CATEGORIES:
            cat_ow = self._overwrites(guild, roles, cat_spec.overwrites)
            category = await self._find(guild, "category", cat_spec.key, cat_spec.name,
                                        discord.CategoryChannel)
            if category is None:
                category = await guild.create_category(cat_spec.name, overwrites=cat_ow,
                                                       reason="PolyBattle setup")
                report.created.append(f"[{cat_spec.name}]")
            elif category.overwrites != cat_ow:
                await category.edit(overwrites=cat_ow, reason="PolyBattle setup: permissões")
                report.updated.append(f"[{category.name}]")
            await db.set_resource(guild.id, "category", cat_spec.key, category.id)

            for ch_spec in cat_spec.channels:
                merged = bp.merge_overwrites(cat_spec.overwrites, ch_spec.overwrites)
                ow = self._overwrites(guild, roles, merged)
                if ch_spec.kind == "voice":
                    channel = await self._find(guild, "channel", ch_spec.key, ch_spec.name,
                                               discord.VoiceChannel)
                    if channel is None:
                        channel = await guild.create_voice_channel(
                            ch_spec.name, category=category, overwrites=ow,
                            user_limit=ch_spec.user_limit, reason="PolyBattle setup")
                        report.created.append(ch_spec.name)
                    elif (channel.category_id != category.id or channel.overwrites != ow
                          or channel.user_limit != ch_spec.user_limit):
                        await channel.edit(category=category, overwrites=ow, user_limit=ch_spec.user_limit,
                                           reason="PolyBattle setup: sincronização")
                        report.updated.append(channel.name)
                else:
                    channel = await self._find(guild, "channel", ch_spec.key, ch_spec.name,
                                               discord.TextChannel)
                    if channel is None:
                        extra = {"topic": ch_spec.topic} if ch_spec.topic else {}
                        channel = await guild.create_text_channel(
                            ch_spec.name, category=category, overwrites=ow,
                            slowmode_delay=ch_spec.slowmode, reason="PolyBattle setup", **extra)
                        report.created.append(f"#{ch_spec.name}")
                    elif (channel.category_id != category.id or channel.overwrites != ow
                          or (channel.topic or "") != ch_spec.topic
                          or channel.slowmode_delay != ch_spec.slowmode):
                        await channel.edit(category=category, overwrites=ow, topic=ch_spec.topic,
                                           slowmode_delay=ch_spec.slowmode,
                                           reason="PolyBattle setup: sincronização")
                        report.updated.append(f"#{channel.name}")
                await db.set_resource(guild.id, "channel", ch_spec.key, channel.id)

    # ------------------------------------------------------------------ painéis
    async def _publish(self, guild: discord.Guild, panel_key: str, channel_key: str,
                       embeds: list[discord.Embed], view: discord.ui.View | None,
                       report: SetupReport) -> None:
        channel = self.bot.channel(guild, channel_key)
        if not isinstance(channel, discord.TextChannel):
            report.warnings.append(f"Canal para o painel '{panel_key}' não encontrado.")
            return
        stored = await self.bot.db.get_panel(guild.id, panel_key)
        if stored and stored["channel_id"] == channel.id:
            try:
                msg = await channel.fetch_message(stored["message_id"])
                await msg.edit(embeds=embeds, view=view)
                report.updated.append(f"painel {panel_key}")
                return
            except discord.NotFound:
                pass
        msg = await channel.send(embeds=embeds, view=view)
        await self.bot.db.set_panel(guild.id, panel_key, channel.id, msg.id)
        report.created.append(f"painel {panel_key}")

    def _link_view(self) -> discord.ui.View | None:
        s = self.bot.settings
        links = [("Play on Roblox", s.roblox_game_url, "🎮"),
                 ("Roblox Group", s.roblox_group_url, "🪖"),
                 ("Website", s.website_url, "🌐")]
        links = [(label, url, emoji) for label, url, emoji in links if url.startswith("https://")]
        if not links:
            return None
        view = discord.ui.View(timeout=None)
        for label, url, emoji in links:
            view.add_item(discord.ui.Button(label=label, url=url, emoji=emoji))
        return view

    async def publish_panels(self, guild: discord.Guild, report: SetupReport) -> None:
        # Imports locais para evitar dependência circular entre cogs.
        from cogs.reports import ReportPanelView
        from cogs.tickets import TicketPanelView
        from cogs.verification import VerifyView

        refs = self.bot.channel_map(guild.id)
        r = lambda text: resolve_channel_refs(text, refs)  # noqa: E731
        s = self.bot.settings

        # Regras
        rules = ui.brand("📜 SERVER RULES | REGRAS DO SERVIDOR",
                         "O descumprimento das regras resulta em punição.\n"
                         "-# Breaking the rules will result in punishment.")
        for num, pt, en in content.RULES:
            rules.add_field(name=f"§{num} — {pt}", value=en, inline=False)
        punish = ui.brand(None, content.PUNISHMENT_LADDER, color=bp.COLOR_BLACK, timestamp=False)
        await self._publish(guild, "rules", "server_rules", [rules, punish], None, report)

        # Apresentação + informações do jogo
        intro = ui.brand(content.PRESENTATION_TITLE, content.PRESENTATION, color=bp.COLOR_BLACK)
        info = ui.brand("🎮 GAME INFORMATION | INFORMAÇÕES DO JOGO")
        for name, value in content.GAME_INFO_SECTIONS:
            info.add_field(name=name, value=r(value), inline=False)
        await self._publish(guild, "game_info", "game_information", [intro, info], self._link_view(), report)

        # Links úteis
        lines = []
        if s.roblox_game_url:
            lines.append(f"🎮 **Roblox Game:** {s.roblox_game_url}")
        if s.roblox_group_url:
            lines.append(f"🪖 **Roblox Group:** {s.roblox_group_url}")
        if s.website_url:
            lines.append(f"🌐 **Website:** {s.website_url}")
        lines.append(r("🎫 **Suporte | Support:** <#open_a_ticket>"))
        lines.append(r("📜 **Regras | Rules:** <#server_rules>"))
        links = ui.brand("🔗 USEFUL LINKS | LINKS ÚTEIS", "\n".join(lines))
        await self._publish(guild, "links", "useful_links", [links], self._link_view(), report)

        # Verificação
        verify = ui.brand("🛡️ VERIFICATION | VERIFICAÇÃO", r(content.VERIFY_TEXT))
        await self._publish(guild, "verify", "verify", [verify], VerifyView(), report)

        # Tickets
        tickets = ui.brand("🎫 SUPPORT CENTER | CENTRAL DE SUPORTE", content.TICKET_PANEL_TEXT)
        await self._publish(guild, "tickets", "open_a_ticket", [tickets], TicketPanelView(), report)

        # Denúncias
        reports_embed = ui.brand("🚨 PLAYER REPORTS | DENÚNCIAS", content.REPORT_PANEL_TEXT,
                                 color=bp.COLOR_BLACK)
        await self._publish(guild, "reports", "player_reports", [reports_embed], ReportPanelView(), report)

        # Sugestões
        sugg = ui.brand("💡 SUGGESTIONS | SUGESTÕES", content.SUGGESTION_PANEL_TEXT)
        await self._publish(guild, "suggestions", "suggestions", [sugg], None, report)

    # ------------------------------------------------------------------ comandos
    @setup_group.command(name="install", description="Cria/atualiza toda a estrutura oficial do PolyBattle")
    async def install(self, interaction: discord.Interaction) -> None:
        guild = interaction.guild
        assert guild is not None
        if not self._authorized(interaction):
            await respond(interaction, ui.error("Apenas o dono do servidor ou administradores."))
            return
        if err := self._bot_ready_error(guild):
            await respond(interaction, ui.error(err))
            return

        lock = self._locks.setdefault(guild.id, asyncio.Lock())
        if lock.locked():
            await respond(interaction, ui.warning("Uma instalação já está em andamento."))
            return

        view = ConfirmView(interaction.user.id)
        await interaction.response.send_message(
            embed=ui.warning(
                "Esta operação irá:\n"
                "• Criar/atualizar **13 cargos** e a hierarquia\n"
                "• Redefinir as permissões de **@everyone** para o mínimo seguro\n"
                "• Criar/atualizar **categorias, canais e permissões**\n"
                "• Publicar os painéis oficiais\n\n"
                "Canais e cargos existentes **com o mesmo nome** serão reaproveitados (sem duplicação). "
                "Nada é apagado.",
                title="⚙️ Confirmar instalação | Confirm install",
            ),
            view=view, ephemeral=True,
        )
        await view.wait()
        if not view.confirmed:
            return

        async with lock:
            started = time.monotonic()
            report = SetupReport()
            self.bot.quiet_guilds.add(guild.id)
            try:
                roles = await self._ensure_roles(guild, report)
                everyone_perms = build_permissions(bp.EVERYONE_GUILD_PERMS)
                if guild.default_role.permissions != everyone_perms:
                    await guild.default_role.edit(permissions=everyone_perms,
                                                  reason="PolyBattle setup: @everyone seguro")
                    report.updated.append("@everyone")
                await self._ensure_channels(guild, roles, report)
                await self.bot.refresh_resources(guild.id)
                await self.publish_panels(guild, report)

                member = interaction.user
                if (isinstance(member, discord.Member) and member.id == guild.owner_id
                        and roles.get("founder") and roles["founder"] < guild.me.top_role
                        and roles["founder"] not in member.roles):
                    await member.add_roles(roles["founder"], roles["verified"],
                                           reason="PolyBattle setup: dono do servidor")
                    report.updated.append(f"{member} recebeu @Founder")

                await self.bot.db.set_config(guild.id, "setup_completed_at", str(time.time()))
            except discord.HTTPException as exc:
                log.exception("Falha durante o setup em %s", guild.id)
                report.warnings.append(f"Erro do Discord: {exc.text or exc}")
            finally:
                await self.bot.refresh_resources(guild.id)
                await asyncio.sleep(5)  # deixa os eventos gerados pelo setup passarem antes de reativar os logs
                self.bot.quiet_guilds.discard(guild.id)

            elapsed = time.monotonic() - started
            embed = ui.brand("✅ Instalação concluída | Setup complete",
                             report.summary() + f"\n\n-# {elapsed:.1f}s")
            await interaction.followup.send(embed=embed, ephemeral=True)
            await self.bot.send_log(guild, ui.log_embed(
                "⚙️ Setup executado", report.summary()[:4000], user=interaction.user))

    @setup_group.command(name="panels", description="Republica todos os painéis oficiais")
    async def panels(self, interaction: discord.Interaction) -> None:
        guild = interaction.guild
        assert guild is not None
        if not self._authorized(interaction):
            await respond(interaction, ui.error("Apenas o dono do servidor ou administradores."))
            return
        if not self.bot.is_setup(guild.id):
            await respond(interaction, ui.error("Execute `/setup install` primeiro."))
            return
        await interaction.response.defer(ephemeral=True, thinking=True)
        report = SetupReport()
        await self.publish_panels(guild, report)
        await interaction.followup.send(embed=ui.success(report.summary()), ephemeral=True)

    @setup_group.command(name="status", description="Diagnóstico de permissões, hierarquia e estrutura")
    async def status(self, interaction: discord.Interaction) -> None:
        guild = interaction.guild
        assert guild is not None
        me = guild.me
        lines: list[str] = []
        ok, bad = "🟢", "🔴"
        lines.append(f"{ok if me.guild_permissions.administrator else bad} Permissão Administrador do bot")
        intents = self.bot.intents
        lines.append(f"{ok if intents.members else bad} Intent Server Members")
        lines.append(f"{ok if intents.message_content else bad} Intent Message Content")

        missing_roles, above_bot = [], []
        for spec in bp.ROLES:
            role = self.bot.role(guild, spec.key)
            if role is None:
                missing_roles.append(spec.name)
            elif role >= me.top_role:
                above_bot.append(role.name)
        missing_channels = [c.name for k, c in bp.ALL_CHANNELS.items() if self.bot.channel(guild, k) is None]

        lines.append(f"{ok if not missing_roles else bad} Cargos ausentes: {', '.join(missing_roles) or 'nenhum'}")
        lines.append(f"{ok if not above_bot else bad} Cargos acima do bot: {', '.join(above_bot) or 'nenhum'}")
        lines.append(f"{ok if not missing_channels else bad} Canais ausentes: "
                     f"{', '.join(missing_channels) or 'nenhum'}")
        open_tickets = await self.bot.db.open_tickets(guild.id)
        lines.append(f"🎫 Tickets abertos: {len(open_tickets)}")
        lines.append(f"🗄️ Banco: `{self.bot.settings.database_path.name}`")
        await respond(interaction, ui.brand("🩺 STATUS DO SISTEMA", "\n".join(lines)))


async def setup(bot: PolyBattleBot) -> None:
    await bot.add_cog(Setup(bot))
