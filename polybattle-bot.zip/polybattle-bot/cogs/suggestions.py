"""
Sistema de sugestões com votação.

* /suggest <título> <descrição> — publica em #suggestions com botões 👍/👎
  e abre um tópico (thread) para discussão.
* Votos ficam no banco: 1 voto por membro; clicar no mesmo botão remove o voto,
  clicar no outro troca o voto.
* /suggestion review <id> <status> [motivo] — equipe aprova, recusa ou marca
  como implementada (atualiza a embed e notifica o autor por DM).
"""

from __future__ import annotations

import logging
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from core import blueprint as bp
from core import ui
from core.bot import BaseView, PolyBattleBot, require_roles, respond
from core.text import bi, truncate

log = logging.getLogger("polybattle.suggestions")

STATUS_INFO = {
    "pending": ("🟡 Em votação | Voting", bp.COLOR_GREEN),
    "approved": ("🟢 Aprovada | Approved", bp.COLOR_GREEN_LIGHT),
    "denied": ("🔴 Recusada | Denied", bp.COLOR_DANGER),
    "implemented": ("🚀 Implementada | Implemented", bp.COLOR_WHITE),
}
REVIEW_ROLES = bp.SENIOR_MOD_ROLES + ("developer",)


class SuggestionVoteView(BaseView):
    def __init__(self, up: int = 0, down: int = 0, *, disabled: bool = False) -> None:
        super().__init__(timeout=None)
        self.upvote.label = str(up)
        self.downvote.label = str(down)
        self.upvote.disabled = disabled
        self.downvote.disabled = disabled

    async def _vote(self, interaction: discord.Interaction, value: int) -> None:
        cog: Suggestions | None = interaction.client.get_cog("Suggestions")  # type: ignore[union-attr]
        if cog is not None:
            await cog.handle_vote(interaction, value)

    @discord.ui.button(label="0", emoji="👍", style=discord.ButtonStyle.success, custom_id="pb:suggest:up")
    async def upvote(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._vote(interaction, 1)

    @discord.ui.button(label="0", emoji="👎", style=discord.ButtonStyle.danger, custom_id="pb:suggest:down")
    async def downvote(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._vote(interaction, -1)


def build_embed(row, author: discord.abc.User | None, up: int, down: int) -> discord.Embed:
    label, color = STATUS_INFO.get(row["status"], STATUS_INFO["pending"])
    embed = ui.brand(f"💡 SUGESTÃO #{row['id']:04d} — {truncate(row['title'], 200)}",
                     truncate(row["content"], 3500), color=color)
    if author is not None:
        embed.set_author(name=str(author), icon_url=author.display_avatar.url)
    total = up + down
    pct = f"{(up / total * 100):.0f}%" if total else "—"
    embed.add_field(name="Votos | Votes", value=f"👍 **{up}** • 👎 **{down}** • aprovação {pct}", inline=True)
    embed.add_field(name="Status", value=label, inline=True)
    if row["staff_reason"]:
        embed.add_field(name="Resposta da equipe | Staff response",
                        value=f"{truncate(row['staff_reason'], 900)}\n— <@{row['staff_id']}>", inline=False)
    return embed


class Suggestions(commands.Cog):
    suggestion_group = app_commands.Group(name="suggestion", description="Gestão de sugestões (equipe)",
                                          guild_only=True)

    def __init__(self, bot: PolyBattleBot) -> None:
        self.bot = bot

    async def cog_load(self) -> None:
        self.bot.add_view(SuggestionVoteView())

    async def _refresh_message(self, guild: discord.Guild, row) -> None:
        channel = guild.get_channel(row["channel_id"]) if row["channel_id"] else None
        if not isinstance(channel, discord.TextChannel) or not row["message_id"]:
            return
        up, down = await self.bot.db.suggestion_tally(row["id"])
        author = guild.get_member(row["author_id"]) or self.bot.get_user(row["author_id"])
        try:
            msg = await channel.fetch_message(row["message_id"])
            await msg.edit(embed=build_embed(row, author, up, down),
                           view=SuggestionVoteView(up, down, disabled=row["status"] in ("denied", "implemented")))
        except discord.NotFound:
            log.info("Mensagem da sugestão %s não existe mais", row["id"])

    # ------------------------------------------------------------------ votos
    async def handle_vote(self, interaction: discord.Interaction, value: int) -> None:
        if interaction.message is None or interaction.guild is None:
            return
        row = await self.bot.db.get_suggestion_by_message(interaction.message.id)
        if row is None:
            await respond(interaction, ui.error("Sugestão não encontrada."))
            return
        if row["status"] in ("denied", "implemented"):
            await respond(interaction, ui.warning("A votação desta sugestão foi encerrada."))
            return
        result = await self.bot.db.vote_suggestion(row["id"], interaction.user.id, value)
        up, down = await self.bot.db.suggestion_tally(row["id"])
        author = interaction.guild.get_member(row["author_id"]) or self.bot.get_user(row["author_id"])
        await interaction.response.edit_message(embed=build_embed(row, author, up, down),
                                                view=SuggestionVoteView(up, down))
        text = {"added": bi("Voto registrado.", "Vote recorded."),
                "changed": bi("Voto alterado.", "Vote changed."),
                "removed": bi("Voto removido.", "Vote removed.")}[result]
        await interaction.followup.send(text, ephemeral=True)

    # ------------------------------------------------------------------ comandos
    @app_commands.command(name="suggest", description="Envia uma sugestão para o PolyBattle | Submit a suggestion")
    @app_commands.describe(title="Título curto", description="Descreva sua ideia em detalhes")
    @app_commands.guild_only()
    @app_commands.checks.cooldown(1, 300, key=lambda i: (i.guild_id, i.user.id))
    @require_roles("verified")
    async def suggest(self, interaction: discord.Interaction,
                      title: app_commands.Range[str, 5, 100],
                      description: app_commands.Range[str, 20, 1500]) -> None:
        guild = interaction.guild
        assert guild is not None
        channel = self.bot.channel(guild, "suggestions")
        if not isinstance(channel, discord.TextChannel):
            await respond(interaction, ui.error("Canal de sugestões não configurado."))
            return
        sid = await self.bot.db.create_suggestion(guild.id, interaction.user.id, title, description)
        row = await self.bot.db.get_suggestion(guild.id, sid)
        msg = await channel.send(embed=build_embed(row, interaction.user, 0, 0), view=SuggestionVoteView())
        await self.bot.db.set_suggestion_message(sid, channel.id, msg.id)
        try:
            await msg.create_thread(name=f"Sugestão #{sid:04d} — discussão", auto_archive_duration=10080)
        except discord.HTTPException as exc:
            log.info("Não foi possível criar thread da sugestão %s: %s", sid, exc)
        await respond(interaction, ui.success(bi(f"Sugestão #{sid:04d} publicada em {channel.mention}.",
                                                 f"Suggestion #{sid:04d} posted.")))

    @suggestion_group.command(name="review", description="Aprova, recusa ou marca uma sugestão como implementada")
    @app_commands.describe(suggestion_id="Número da sugestão", status="Novo status", reason="Resposta da equipe")
    @app_commands.choices(status=[
        app_commands.Choice(name="Aprovada | Approved", value="approved"),
        app_commands.Choice(name="Recusada | Denied", value="denied"),
        app_commands.Choice(name="Implementada | Implemented", value="implemented"),
        app_commands.Choice(name="Reabrir votação | Reopen", value="pending"),
    ])
    @require_roles(*REVIEW_ROLES)
    async def review(self, interaction: discord.Interaction, suggestion_id: int,
                     status: app_commands.Choice[str], reason: Optional[app_commands.Range[str, 1, 900]] = None) -> None:
        guild = interaction.guild
        assert guild is not None
        row = await self.bot.db.get_suggestion(guild.id, suggestion_id)
        if row is None:
            await respond(interaction, ui.error("Sugestão não encontrada."))
            return
        await self.bot.db.set_suggestion_status(row["id"], status.value, interaction.user.id, reason)
        row = await self.bot.db.get_suggestion(guild.id, suggestion_id)
        await self._refresh_message(guild, row)
        await respond(interaction, ui.success(f"Sugestão #{suggestion_id:04d} → **{status.name}**."))

        author = guild.get_member(row["author_id"])
        if author is not None:
            try:
                await author.send(embed=ui.brand(
                    f"💡 Sua sugestão #{suggestion_id:04d} foi atualizada",
                    f"**{truncate(row['title'], 200)}**\nStatus: {STATUS_INFO[status.value][0]}"
                    + (f"\n\n{truncate(reason, 900)}" if reason else "")))
            except (discord.Forbidden, discord.HTTPException):
                pass
        await self.bot.send_log(guild, ui.log_embed(
            f"💡 Sugestão #{suggestion_id:04d} → {status.value}", truncate(reason or "", 1000) or None,
            user=interaction.user))


async def setup(bot: PolyBattleBot) -> None:
    await bot.add_cog(Suggestions(bot))
