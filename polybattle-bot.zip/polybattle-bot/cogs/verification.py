"""
Sistema de verificação de novos membros.

Fluxo: botão "Verificar" (persistente) → o bot mostra um código de segurança
temporário → o membro digita o código em um formulário → recebe os cargos
Verified e Member. Contas mais novas que VERIFY_MIN_ACCOUNT_AGE_DAYS são
recusadas. Ao concluir, o evento customizado ``member_verified`` é disparado
(boas-vindas e logs escutam esse evento).
"""

from __future__ import annotations

import datetime as dt
import logging
import secrets
import time

import discord
from discord.ext import commands

from core import blueprint as bp
from core import ui
from core.bot import BaseModal, BaseView, PolyBattleBot, respond
from core.text import bi

log = logging.getLogger("polybattle.verify")

CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # sem caracteres ambíguos (0/O, 1/I)
CODE_TTL = 180
MAX_ATTEMPTS = 3


def generate_code(length: int = 5) -> str:
    return "".join(secrets.choice(CODE_ALPHABET) for _ in range(length))


class VerifyView(BaseView):
    """Painel persistente publicado em #verify."""

    def __init__(self) -> None:
        super().__init__(timeout=None)

    @discord.ui.button(label="Verificar | Verify", style=discord.ButtonStyle.success, emoji="🛡️",
                       custom_id="pb:verify:start")
    async def start(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        cog: Verification | None = interaction.client.get_cog("Verification")  # type: ignore[union-attr]
        if cog is None:
            await respond(interaction, ui.error("Sistema de verificação indisponível."))
            return
        await cog.begin(interaction)


class CodeModal(BaseModal, title="Verificação | Verification"):
    code = discord.ui.TextInput(label="Código de segurança | Security code", min_length=5, max_length=5,
                                placeholder="XXXXX")

    def __init__(self, cog: "Verification") -> None:
        super().__init__(timeout=CODE_TTL)
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction) -> None:
        await self.cog.finish(interaction, str(self.code.value))


class EnterCodeView(BaseView):
    def __init__(self, cog: "Verification", user_id: int) -> None:
        super().__init__(timeout=CODE_TTL)
        self.cog = cog
        self.user_id = user_id

    @discord.ui.button(label="Inserir código | Enter code", style=discord.ButtonStyle.primary, emoji="⌨️")
    async def enter(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message("Este código não é seu.", ephemeral=True)
            return
        await interaction.response.send_modal(CodeModal(self.cog))


class Verification(commands.Cog):
    def __init__(self, bot: PolyBattleBot) -> None:
        self.bot = bot
        # (guild_id, user_id) -> (código, expira_em, tentativas)
        self._pending: dict[tuple[int, int], tuple[str, float, int]] = {}

    async def cog_load(self) -> None:
        self.bot.add_view(VerifyView())

    def _cleanup(self) -> None:
        now = time.time()
        for key in [k for k, (_, exp, _) in self._pending.items() if exp < now]:
            self._pending.pop(key, None)

    async def begin(self, interaction: discord.Interaction) -> None:
        guild = interaction.guild
        member = interaction.user
        if guild is None or not isinstance(member, discord.Member):
            return
        verified = self.bot.role(guild, "verified")
        if verified is None:
            await respond(interaction, ui.error(bi("O servidor ainda não foi configurado.",
                                                   "The server has not been set up yet.")))
            return
        if verified in member.roles:
            await respond(interaction, ui.success(bi("Você já está verificado.", "You are already verified.")))
            return

        min_days = self.bot.settings.verify_min_account_age_days
        age = dt.datetime.now(dt.timezone.utc) - member.created_at
        if min_days and age < dt.timedelta(days=min_days):
            await respond(interaction, ui.error(bi(
                f"Sua conta do Discord precisa ter pelo menos {min_days} dia(s) para entrar. "
                "Se acredita que isso é um erro, contate a equipe.",
                f"Your Discord account must be at least {min_days} day(s) old.",
            )))
            await self.bot.send_log(guild, ui.log_embed(
                "🛡️ Verificação recusada (conta nova)",
                f"Conta criada <t:{int(member.created_at.timestamp())}:R>", color=bp.COLOR_WARNING,
                user=member))
            return

        self._cleanup()
        code = generate_code()
        self._pending[(guild.id, member.id)] = (code, time.time() + CODE_TTL, 0)
        embed = ui.brand("🛡️ Código de segurança | Security code",
                         f"Digite o código abaixo no formulário:\n# `{code}`\n"
                         f"-# Expira em {CODE_TTL // 60} minutos. | Expires in {CODE_TTL // 60} minutes.",
                         timestamp=False)
        await interaction.response.send_message(embed=embed, view=EnterCodeView(self, member.id),
                                                ephemeral=True)

    async def finish(self, interaction: discord.Interaction, typed: str) -> None:
        guild = interaction.guild
        member = interaction.user
        if guild is None or not isinstance(member, discord.Member):
            return
        key = (guild.id, member.id)
        entry = self._pending.get(key)
        if entry is None or entry[1] < time.time():
            self._pending.pop(key, None)
            await respond(interaction, ui.error(bi("Código expirado. Clique em Verificar novamente.",
                                                   "Code expired. Click Verify again.")))
            return
        code, expires, attempts = entry
        if typed.strip().upper() != code:
            attempts += 1
            if attempts >= MAX_ATTEMPTS:
                self._pending.pop(key, None)
                await respond(interaction, ui.error(bi("Código incorreto. Tentativas esgotadas; gere um novo código.",
                                                       "Wrong code. Out of attempts; request a new one.")))
            else:
                self._pending[key] = (code, expires, attempts)
                await respond(interaction, ui.error(bi(
                    f"Código incorreto. Tentativas restantes: {MAX_ATTEMPTS - attempts}.",
                    f"Wrong code. Attempts left: {MAX_ATTEMPTS - attempts}.")))
            return

        self._pending.pop(key, None)
        roles = [r for r in (self.bot.role(guild, "verified"), self.bot.role(guild, "member")) if r]
        try:
            await member.add_roles(*roles, reason="Verificação concluída")
        except discord.Forbidden:
            await respond(interaction, ui.error(bi(
                "Não consegui atribuir seus cargos. A equipe foi avisada.",
                "I couldn't assign your roles. Staff has been notified.")))
            await self.bot.send_log(guild, ui.log_embed(
                "⛔ Falha na verificação", "O bot não tem permissão para atribuir Verified/Member. "
                "Verifique a hierarquia (`/setup status`).", color=bp.COLOR_DANGER, user=member))
            return

        await respond(interaction, ui.success(bi(
            "Verificação concluída! Bem-vindo(a) ao campo de batalha.",
            "Verification complete! Welcome to the battlefield.")))
        self.bot.dispatch("member_verified", member)


async def setup(bot: PolyBattleBot) -> None:
    await bot.add_cog(Verification(bot))
