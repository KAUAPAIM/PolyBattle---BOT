"""
Sistema de tickets.

* Painel persistente com menu de seleção (5 categorias) em #open-a-ticket.
* Cada ticket gera um canal privado em ◤ TICKETS ◢ visível apenas para o autor
  e para os cargos autorizados daquele tipo.
* Botões persistentes: Assumir (staff) e Fechar (autor ou staff).
* Ao fechar: transcript HTML enviado para #staff-logs e por DM ao autor;
  abertura e encerramento ficam registrados no banco e nos logs.
"""

from __future__ import annotations

import asyncio
import datetime as dt
import io
import logging

import discord
from discord import app_commands
from discord.ext import commands

from core import blueprint as bp
from core import ui
from core.bot import BaseModal, BaseView, PolyBattleBot, require_setup, respond
from core.text import bi, slugify_username, truncate
from core.transcript import TranscriptMessage, render_html

log = logging.getLogger("polybattle.tickets")

TRANSCRIPT_LIMIT = 5000
TICKET_MEMBER_PERMS = dict(view_channel=True, send_messages=True, read_message_history=True,
                           attach_files=True, embed_links=True, add_reactions=True)


def _cog(interaction: discord.Interaction) -> "Tickets | None":
    return interaction.client.get_cog("Tickets")  # type: ignore[union-attr,return-value]


# --------------------------------------------------------------------------- views / modals
class TicketPanelView(BaseView):
    def __init__(self) -> None:
        super().__init__(timeout=None)

    @discord.ui.select(
        custom_id="pb:ticket:select",
        placeholder="Selecione o tipo de ticket | Select a ticket type",
        min_values=1, max_values=1,
        options=[discord.SelectOption(label=t.label, value=t.key, emoji=t.emoji,
                                      description=t.description[:100]) for t in bp.TICKET_TYPES],
    )
    async def select(self, interaction: discord.Interaction, select: discord.ui.Select) -> None:
        ticket_type = bp.TICKET_BY_KEY.get(select.values[0])
        if ticket_type is None:
            await respond(interaction, ui.error("Tipo de ticket inválido."))
            return
        await interaction.response.send_modal(TicketModal(ticket_type))
        # Reseta a seleção do menu para o próximo uso.
        if interaction.message is not None:
            try:
                await interaction.message.edit(view=TicketPanelView())
            except discord.HTTPException:
                pass


class TicketModal(BaseModal):
    subject = discord.ui.TextInput(label="Assunto | Subject", max_length=100, min_length=3)
    details = discord.ui.TextInput(label="Descreva o problema | Describe the issue",
                                   style=discord.TextStyle.paragraph, max_length=1500, min_length=10)

    def __init__(self, ticket_type: bp.TicketType) -> None:
        super().__init__(title=f"{ticket_type.label} — Ticket", timeout=600)
        self.ticket_type = ticket_type

    async def on_submit(self, interaction: discord.Interaction) -> None:
        cog = _cog(interaction)
        if cog is None:
            await respond(interaction, ui.error("Sistema de tickets indisponível."))
            return
        await cog.open_ticket(interaction, self.ticket_type, str(self.subject.value), str(self.details.value))


class CloseReasonModal(BaseModal, title="Fechar ticket | Close ticket"):
    reason = discord.ui.TextInput(label="Motivo (opcional) | Reason (optional)", required=False,
                                  max_length=300, style=discord.TextStyle.paragraph)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        cog = _cog(interaction)
        if cog is not None:
            await cog.close_ticket(interaction, str(self.reason.value or "").strip() or None)


class TicketControlView(BaseView):
    def __init__(self) -> None:
        super().__init__(timeout=None)

    @discord.ui.button(label="Assumir | Claim", style=discord.ButtonStyle.primary, emoji="🛡️",
                       custom_id="pb:ticket:claim")
    async def claim(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        cog = _cog(interaction)
        if cog is not None:
            await cog.claim_ticket(interaction)

    @discord.ui.button(label="Fechar | Close", style=discord.ButtonStyle.danger, emoji="🔒",
                       custom_id="pb:ticket:close")
    async def close(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        cog = _cog(interaction)
        if cog is None:
            return
        ticket = await cog.bot.db.get_ticket_by_channel(interaction.channel_id or 0)
        if ticket is None or ticket["status"] != "open":
            await respond(interaction, ui.error("Este canal não é um ticket aberto."))
            return
        if not cog.can_close(interaction.user, ticket):  # type: ignore[arg-type]
            await respond(interaction, ui.error("Você não pode fechar este ticket."))
            return
        await interaction.response.send_modal(CloseReasonModal())


# --------------------------------------------------------------------------- cog
class Tickets(commands.Cog):
    ticket_group = app_commands.Group(name="ticket", description="Gerenciamento de tickets", guild_only=True)

    def __init__(self, bot: PolyBattleBot) -> None:
        self.bot = bot
        self._open_locks: dict[int, asyncio.Lock] = {}

    async def cog_load(self) -> None:
        self.bot.add_view(TicketPanelView())
        self.bot.add_view(TicketControlView())

    # ------------------------------------------------------------------ permissões
    def is_ticket_staff(self, member: discord.Member, ticket_type_key: str) -> bool:
        if member.guild_permissions.administrator or member.id == member.guild.owner_id:
            return True
        ttype = bp.TICKET_BY_KEY.get(ticket_type_key)
        return bool(ttype and self.bot.member_has_any(member, ttype.roles))

    def can_close(self, member: discord.Member, ticket) -> bool:
        return member.id == ticket["user_id"] or self.is_ticket_staff(member, ticket["ticket_type"])

    # ------------------------------------------------------------------ abrir
    async def open_ticket(self, interaction: discord.Interaction, ttype: bp.TicketType,
                          subject: str, details: str) -> None:
        guild = interaction.guild
        member = interaction.user
        if guild is None or not isinstance(member, discord.Member):
            return
        category = self.bot.category(guild, "cat_tickets")
        if category is None:
            await respond(interaction, ui.error(bi("Sistema de tickets não configurado.",
                                                   "Ticket system not configured.")))
            return

        lock = self._open_locks.setdefault(member.id, asyncio.Lock())
        async with lock:  # impede tickets duplicados por cliques repetidos
            limit = self.bot.settings.max_open_tickets_per_user
            if await self.bot.db.count_open_tickets(guild.id, member.id) >= limit:
                await respond(interaction, ui.error(bi(
                    f"Você já possui {limit} ticket(s) aberto(s). Feche-o antes de abrir outro.",
                    "You already have an open ticket. Close it before opening another.")))
                return

            await interaction.response.defer(ephemeral=True, thinking=True)
            ticket_id = await self.bot.db.create_ticket(guild.id, member.id, ttype.key, subject)

            overwrites: dict[discord.abc.Snowflake, discord.PermissionOverwrite] = {
                guild.default_role: discord.PermissionOverwrite(view_channel=False),
                member: discord.PermissionOverwrite(**TICKET_MEMBER_PERMS),
                guild.me: discord.PermissionOverwrite(**TICKET_MEMBER_PERMS, manage_channels=True,
                                                      manage_messages=True),
            }
            staff_roles = [r for r in (self.bot.role(guild, k) for k in ttype.roles) if r]
            for role in staff_roles:
                overwrites[role] = discord.PermissionOverwrite(**TICKET_MEMBER_PERMS, manage_messages=True)

            name = f"{ttype.prefix}-{ticket_id:04d}-{slugify_username(member.name)}"
            try:
                channel = await guild.create_text_channel(
                    name, category=category, overwrites=overwrites,
                    topic=f"Ticket #{ticket_id} • {ttype.label} • {member} ({member.id})",
                    reason=f"Ticket #{ticket_id} aberto por {member}",
                )
            except discord.HTTPException:
                await self.bot.db.delete_ticket(ticket_id)
                raise
            await self.bot.db.set_ticket_channel(ticket_id, channel.id)

        embed = ui.brand(f"{ttype.emoji} {ttype.label.upper()} — TICKET #{ticket_id:04d}")
        embed.add_field(name="Autor | Author", value=ui.user_field(member), inline=False)
        embed.add_field(name="Assunto | Subject", value=truncate(subject, 1024), inline=False)
        embed.add_field(name="Detalhes | Details", value=truncate(details, 1024), inline=False)
        embed.add_field(name="Status", value="🟢 Aberto | Open", inline=True)
        ping_roles = [r for r in (self.bot.role(guild, k) for k in ttype.roles
                                  if k in ("administrator", "moderator", "support_team")) if r]
        pings = " ".join(r.mention for r in ping_roles)
        await channel.send(
            content=f"{member.mention} {pings}".strip(),
            embed=embed,
            view=TicketControlView(),
            allowed_mentions=discord.AllowedMentions(users=[member], roles=ping_roles),
        )
        await channel.send(embed=ui.brand(None, bi(
            "A equipe responderá em breve. Envie prints, vídeos ou IDs que ajudem no atendimento.",
            "Staff will reply soon. Share screenshots, videos or IDs that help."), timestamp=False))

        await interaction.followup.send(
            embed=ui.success(bi(f"Ticket criado: {channel.mention}", f"Ticket created: {channel.mention}")),
            ephemeral=True)
        await self.bot.send_log(guild, ui.log_embed(
            f"🎫 Ticket #{ticket_id:04d} aberto",
            f"Tipo: **{ttype.label}**\nCanal: {channel.mention}\nAssunto: {truncate(subject, 200)}",
            color=bp.COLOR_GREEN_LIGHT, user=member))

    # ------------------------------------------------------------------ assumir
    async def claim_ticket(self, interaction: discord.Interaction) -> None:
        member = interaction.user
        if not isinstance(member, discord.Member):
            return
        ticket = await self.bot.db.get_ticket_by_channel(interaction.channel_id or 0)
        if ticket is None or ticket["status"] != "open":
            await respond(interaction, ui.error("Este canal não é um ticket aberto."))
            return
        if not self.is_ticket_staff(member, ticket["ticket_type"]):
            await respond(interaction, ui.error("Apenas a equipe pode assumir tickets."))
            return
        if ticket["claimed_by"]:
            await respond(interaction, ui.warning(f"Ticket já assumido por <@{ticket['claimed_by']}>."))
            return
        await self.bot.db.claim_ticket(ticket["id"], member.id)
        await interaction.response.send_message(embed=ui.brand(None, bi(
            f"🛡️ {member.mention} assumiu este ticket.", f"{member.display_name} claimed this ticket."),
            timestamp=False))
        if interaction.guild:
            await self.bot.send_log(interaction.guild, ui.log_embed(
                f"🛡️ Ticket #{ticket['id']:04d} assumido", f"Canal: <#{ticket['channel_id']}>", user=member))

    # ------------------------------------------------------------------ fechar
    async def _build_transcript(self, channel: discord.TextChannel, ticket) -> tuple[bytes, str]:
        messages: list[TranscriptMessage] = []
        async for m in channel.history(limit=TRANSCRIPT_LIMIT, oldest_first=True):
            embeds = [
                "\n".join([x for x in (e.title, e.description) if x]
                          + [f"{f.name}: {f.value}" for f in e.fields])
                for e in m.embeds
            ]
            messages.append(TranscriptMessage(
                author=str(m.author), author_id=m.author.id, content=m.clean_content,
                created_at=m.created_at, is_bot=m.author.bot,
                attachments=[a.url for a in m.attachments], embeds=[e for e in embeds if e],
            ))
        ttype = bp.TICKET_BY_KEY.get(ticket["ticket_type"])
        opened = dt.datetime.fromtimestamp(ticket["opened_at"], dt.timezone.utc)
        doc = render_html(
            title=f"Ticket #{ticket['id']:04d} — {ttype.label if ttype else ticket['ticket_type']}",
            subtitle_lines=[
                f"Autor: {ticket['user_id']}",
                f"Assunto: {ticket['subject'] or '—'}",
                f"Aberto em: {opened.strftime('%Y-%m-%d %H:%M UTC')}",
                f"Canal: #{channel.name}",
            ],
            messages=messages,
        )
        return doc.encode("utf-8"), f"ticket-{ticket['id']:04d}.html"

    async def close_ticket(self, interaction: discord.Interaction, reason: str | None) -> None:
        guild = interaction.guild
        member = interaction.user
        channel = interaction.channel
        if guild is None or not isinstance(member, discord.Member) or not isinstance(channel, discord.TextChannel):
            return
        ticket = await self.bot.db.get_ticket_by_channel(channel.id)
        if ticket is None or ticket["status"] != "open":
            await respond(interaction, ui.error("Este canal não é um ticket aberto."))
            return
        if not self.can_close(member, ticket):
            await respond(interaction, ui.error("Você não pode fechar este ticket."))
            return
        if not await self.bot.db.close_ticket(ticket["id"], member.id, reason):
            await respond(interaction, ui.warning("Este ticket já está sendo fechado."))
            return

        await interaction.response.send_message(embed=ui.brand(
            "🔒 Fechando ticket | Closing ticket",
            bi("Gerando transcript. O canal será excluído em 5 segundos.",
               "Generating transcript. This channel will be deleted in 5 seconds."),
            color=bp.COLOR_DANGER, timestamp=False))

        data, filename = await self._build_transcript(channel, ticket)
        ttype = bp.TICKET_BY_KEY.get(ticket["ticket_type"])
        summary = ui.log_embed(f"🔒 Ticket #{ticket['id']:04d} fechado", color=bp.COLOR_GRAY, user=member)
        summary.add_field(name="Tipo", value=ttype.label if ttype else ticket["ticket_type"])
        summary.add_field(name="Autor", value=f"<@{ticket['user_id']}>")
        summary.add_field(name="Assumido por",
                          value=f"<@{ticket['claimed_by']}>" if ticket["claimed_by"] else "—")
        summary.add_field(name="Motivo", value=truncate(reason or "—", 1024), inline=False)
        await self.bot.send_log(guild, summary,
                                file=discord.File(io.BytesIO(data), filename=filename))

        author = guild.get_member(ticket["user_id"])
        if author is not None:
            try:
                await author.send(
                    embed=ui.brand(f"🔒 Seu ticket #{ticket['id']:04d} foi fechado",
                                   bi("Segue o transcript da conversa.", "Here is the conversation transcript.")
                                   + (f"\n\n**Motivo | Reason:** {truncate(reason, 500)}" if reason else "")),
                    file=discord.File(io.BytesIO(data), filename=filename),
                )
            except (discord.Forbidden, discord.HTTPException):
                pass

        await asyncio.sleep(5)
        try:
            await channel.delete(reason=f"Ticket #{ticket['id']} fechado por {member}")
        except discord.HTTPException as exc:
            log.warning("Não foi possível excluir o canal do ticket %s: %s", ticket["id"], exc)

    # ------------------------------------------------------------------ consistência
    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel) -> None:
        ticket = await self.bot.db.get_ticket_by_channel(channel.id)
        if ticket is not None and ticket["status"] == "open":
            await self.bot.db.close_ticket(ticket["id"], 0, "Canal excluído manualmente")
            await self.bot.send_log(channel.guild, ui.log_embed(
                f"🗑️ Ticket #{ticket['id']:04d} encerrado",
                "O canal foi excluído manualmente; o ticket foi marcado como fechado (sem transcript).",
                color=bp.COLOR_WARNING))

    # ------------------------------------------------------------------ comandos
    async def _current_ticket(self, interaction: discord.Interaction):
        ticket = await self.bot.db.get_ticket_by_channel(interaction.channel_id or 0)
        if ticket is None or ticket["status"] != "open":
            await respond(interaction, ui.error("Use este comando dentro de um ticket aberto."))
            return None
        if not self.is_ticket_staff(interaction.user, ticket["ticket_type"]):  # type: ignore[arg-type]
            await respond(interaction, ui.error("Apenas a equipe responsável por este ticket."))
            return None
        return ticket

    @ticket_group.command(name="add", description="Adiciona um membro ao ticket atual")
    @app_commands.describe(member="Membro a adicionar")
    @require_setup()
    async def add(self, interaction: discord.Interaction, member: discord.Member) -> None:
        if await self._current_ticket(interaction) is None:
            return
        channel = interaction.channel
        assert isinstance(channel, discord.TextChannel)
        await channel.set_permissions(member, overwrite=discord.PermissionOverwrite(**TICKET_MEMBER_PERMS),
                                      reason=f"Adicionado ao ticket por {interaction.user}")
        await respond(interaction, ui.success(f"{member.mention} foi adicionado ao ticket."), ephemeral=False)

    @ticket_group.command(name="remove", description="Remove um membro do ticket atual")
    @app_commands.describe(member="Membro a remover")
    @require_setup()
    async def remove(self, interaction: discord.Interaction, member: discord.Member) -> None:
        ticket = await self._current_ticket(interaction)
        if ticket is None:
            return
        if member.id == ticket["user_id"]:
            await respond(interaction, ui.error("Não é possível remover o autor do ticket."))
            return
        channel = interaction.channel
        assert isinstance(channel, discord.TextChannel)
        await channel.set_permissions(member, overwrite=None,
                                      reason=f"Removido do ticket por {interaction.user}")
        await respond(interaction, ui.success(f"{member.mention} foi removido do ticket."), ephemeral=False)

    @ticket_group.command(name="close", description="Fecha o ticket atual e gera o transcript")
    @app_commands.describe(reason="Motivo do fechamento")
    @require_setup()
    async def close(self, interaction: discord.Interaction, reason: str | None = None) -> None:
        await self.close_ticket(interaction, reason)

    @ticket_group.command(name="claim", description="Assume o ticket atual")
    @require_setup()
    async def claim(self, interaction: discord.Interaction) -> None:
        await self.claim_ticket(interaction)


async def setup(bot: PolyBattleBot) -> None:
    await bot.add_cog(Tickets(bot))
