"""
Sistema de denúncias.

Entradas:
* Painel em #player-reports (botão → formulário) — permite denunciar jogadores
  do Roblox ou do Discord por nome.
* /report <membro> <motivo> [evidência]
* Menu de contexto "Report Message" (clique direito em uma mensagem).

Todas as denúncias são salvas no banco e enviadas a #staff-reports com botões
persistentes de status (Em análise / Resolvida / Rejeitada), restritos à moderação.
"""

from __future__ import annotations

import logging
import time
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from core import blueprint as bp
from core import ui
from core.bot import BaseModal, BaseView, PolyBattleBot, require_roles, respond
from core.text import bi, truncate

log = logging.getLogger("polybattle.reports")

RATE_WINDOW = 600     # segundos
RATE_MAX = 3          # denúncias por janela
STATUS_LABEL = {
    "open": "🟡 Aberta | Open",
    "reviewing": "🔵 Em análise | Under review",
    "resolved": "🟢 Resolvida | Resolved",
    "rejected": "🔴 Rejeitada | Rejected",
}


def _cog(interaction: discord.Interaction) -> "Reports | None":
    return interaction.client.get_cog("Reports")  # type: ignore[union-attr,return-value]


class ReportPanelView(BaseView):
    def __init__(self) -> None:
        super().__init__(timeout=None)

    @discord.ui.button(label="Denunciar jogador | Report player", style=discord.ButtonStyle.danger,
                       emoji="🚨", custom_id="pb:report:open")
    async def open(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.send_modal(PanelReportModal())


class PanelReportModal(BaseModal, title="Denúncia | Player report"):
    target = discord.ui.TextInput(label="Jogador (Roblox ou Discord) | Player", max_length=100)
    reason = discord.ui.TextInput(label="O que aconteceu? | What happened?",
                                  style=discord.TextStyle.paragraph, min_length=10, max_length=1000)
    evidence = discord.ui.TextInput(label="Provas (links) | Evidence (links)", required=False,
                                    style=discord.TextStyle.paragraph, max_length=500)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        cog = _cog(interaction)
        if cog is not None:
            await cog.submit(interaction, target_text=str(self.target.value), target_id=None,
                             reason=str(self.reason.value), evidence=str(self.evidence.value or ""),
                             source="panel")


class MessageReportModal(BaseModal, title="Denunciar mensagem | Report message"):
    reason = discord.ui.TextInput(label="Motivo | Reason", style=discord.TextStyle.paragraph,
                                  min_length=5, max_length=800)

    def __init__(self, message: discord.Message) -> None:
        super().__init__()
        self.message = message

    async def on_submit(self, interaction: discord.Interaction) -> None:
        cog = _cog(interaction)
        if cog is None:
            return
        m = self.message
        evidence = f"{m.jump_url}\n> {truncate(m.content, 400) or '(sem texto)'}"
        await cog.submit(interaction, target_text=str(m.author), target_id=m.author.id,
                         reason=str(self.reason.value), evidence=evidence, source="message")


class ReportActionView(BaseView):
    def __init__(self) -> None:
        super().__init__(timeout=None)

    async def _set(self, interaction: discord.Interaction, status: str) -> None:
        cog = _cog(interaction)
        if cog is not None:
            await cog.update_status(interaction, status)

    @discord.ui.button(label="Em análise", style=discord.ButtonStyle.primary, emoji="🔎",
                       custom_id="pb:report:reviewing")
    async def reviewing(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._set(interaction, "reviewing")

    @discord.ui.button(label="Resolvida", style=discord.ButtonStyle.success, emoji="✅",
                       custom_id="pb:report:resolved")
    async def resolved(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._set(interaction, "resolved")

    @discord.ui.button(label="Rejeitada", style=discord.ButtonStyle.secondary, emoji="✖️",
                       custom_id="pb:report:rejected")
    async def rejected(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._set(interaction, "rejected")


class Reports(commands.Cog):
    def __init__(self, bot: PolyBattleBot) -> None:
        self.bot = bot
        self.ctx_menu = app_commands.ContextMenu(name="Report Message", callback=self.report_message)

    async def cog_load(self) -> None:
        self.bot.add_view(ReportPanelView())
        self.bot.add_view(ReportActionView())
        self.bot.tree.add_command(self.ctx_menu)

    async def cog_unload(self) -> None:
        self.bot.tree.remove_command(self.ctx_menu.name, type=self.ctx_menu.type)

    # ------------------------------------------------------------------ envio
    async def submit(self, interaction: discord.Interaction, *, target_text: str, target_id: int | None,
                     reason: str, evidence: str, source: str) -> None:
        guild = interaction.guild
        if guild is None:
            return
        channel = self.bot.channel(guild, "staff_reports")
        if not isinstance(channel, discord.TextChannel):
            await respond(interaction, ui.error(bi("Sistema de denúncias não configurado.",
                                                   "Report system not configured.")))
            return
        recent = await self.bot.db.recent_reports_by(guild.id, interaction.user.id, time.time() - RATE_WINDOW)
        if recent >= RATE_MAX:
            await respond(interaction, ui.error(bi(
                "Você enviou muitas denúncias em pouco tempo. Aguarde alguns minutos.",
                "Too many reports in a short time. Please wait a few minutes.")))
            return

        report_id = await self.bot.db.create_report(guild.id, interaction.user.id, target_text, target_id,
                                                    reason, evidence or None, source)
        embed = ui.brand(f"🚨 DENÚNCIA #{report_id:04d}", color=bp.COLOR_DANGER)
        embed.add_field(name="Denunciante | Reporter", value=ui.user_field(interaction.user), inline=False)
        target_value = f"<@{target_id}> `{target_text}` (`{target_id}`)" if target_id else f"`{target_text}`"
        embed.add_field(name="Denunciado | Reported", value=target_value, inline=False)
        embed.add_field(name="Motivo | Reason", value=truncate(reason, 1024), inline=False)
        embed.add_field(name="Provas | Evidence", value=truncate(evidence, 1024) or "—", inline=False)
        embed.add_field(name="Origem", value=source, inline=True)
        embed.add_field(name="Status", value=STATUS_LABEL["open"], inline=True)
        msg = await channel.send(embed=embed, view=ReportActionView())
        await self.bot.db.set_report_message(report_id, msg.id)
        await respond(interaction, ui.success(bi(
            f"Denúncia #{report_id:04d} enviada à equipe. Obrigado!",
            f"Report #{report_id:04d} sent to staff. Thank you!")))

    async def update_status(self, interaction: discord.Interaction, status: str) -> None:
        member = interaction.user
        if not isinstance(member, discord.Member) or interaction.message is None:
            return
        if not (member.guild_permissions.administrator or self.bot.member_has_any(member, bp.MOD_ROLES)):
            await respond(interaction, ui.error("Apenas moderadores podem alterar o status."))
            return
        report = await self.bot.db.get_report_by_message(interaction.message.id)
        if report is None:
            await respond(interaction, ui.error("Denúncia não encontrada no banco."))
            return
        await self.bot.db.set_report_status(report["id"], status, member.id)
        embed = interaction.message.embeds[0] if interaction.message.embeds else ui.brand("Denúncia")
        for i, field in enumerate(embed.fields):
            if field.name == "Status":
                embed.set_field_at(i, name="Status", value=f"{STATUS_LABEL[status]}\npor {member.mention}",
                                   inline=True)
                break
        if status in ("resolved", "rejected"):
            embed.color = discord.Colour(bp.COLOR_GREEN_LIGHT if status == "resolved" else bp.COLOR_GRAY)
        view = None if status in ("resolved", "rejected") else ReportActionView()
        await interaction.response.edit_message(embed=embed, view=view)

        if status in ("resolved", "rejected") and interaction.guild:
            reporter = interaction.guild.get_member(report["reporter_id"])
            if reporter is not None:
                try:
                    await reporter.send(embed=ui.brand(
                        f"🚨 Denúncia #{report['id']:04d}",
                        bi(f"Sua denúncia foi marcada como **{STATUS_LABEL[status]}**.",
                           "Your report status has been updated.")))
                except (discord.Forbidden, discord.HTTPException):
                    pass
            await self.bot.send_log(interaction.guild, ui.log_embed(
                f"🚨 Denúncia #{report['id']:04d} → {status}", user=member))

    # ------------------------------------------------------------------ comandos
    @app_commands.command(name="report", description="Denuncia um membro à equipe | Report a member")
    @app_commands.describe(member="Membro denunciado", reason="O que aconteceu", evidence="Links de provas")
    @app_commands.guild_only()
    @require_roles("verified")
    async def report(self, interaction: discord.Interaction, member: discord.Member,
                     reason: app_commands.Range[str, 10, 1000],
                     evidence: Optional[app_commands.Range[str, 1, 500]] = None) -> None:
        if member.id == interaction.user.id or member.bot:
            await respond(interaction, ui.error("Alvo inválido para denúncia."))
            return
        await self.submit(interaction, target_text=str(member), target_id=member.id, reason=reason,
                          evidence=evidence or "", source="command")

    @app_commands.guild_only()
    async def report_message(self, interaction: discord.Interaction, message: discord.Message) -> None:
        if interaction.guild is None or not self.bot.is_setup(interaction.guild.id):
            await respond(interaction, ui.error("Servidor não configurado."))
            return
        verified = self.bot.role(interaction.guild, "verified")
        if isinstance(interaction.user, discord.Member) and verified and verified not in interaction.user.roles:
            await respond(interaction, ui.error("Verifique-se antes de enviar denúncias."))
            return
        if message.author.bot or message.author.id == interaction.user.id:
            await respond(interaction, ui.error("Esta mensagem não pode ser denunciada."))
            return
        await interaction.response.send_modal(MessageReportModal(message))


async def setup(bot: PolyBattleBot) -> None:
    await bot.add_cog(Reports(bot))
