"""
Moderação automática e proteção anti-raid.

Proteções (membros da equipe são isentos):
* Convites de outros servidores → mensagem apagada + aviso.
* Link suspeito (imita marca) → mensagem apagada + aviso.
* Link malicioso (blocklist, punycode, golpe) → apagada + timeout longo.
* Excesso de menções → apagada + timeout.
* Flood / mensagens repetidas → mensagens apagadas + timeout.

Anti-raid: se RAID_JOIN_THRESHOLD contas entrarem em RAID_JOIN_SECONDS, o
modo raid é ativado por RAID_MODE_MINUTES — novos membros são expulsos com
aviso por DM e a equipe é alertada. Pode ser controlado com /raidmode.
"""

from __future__ import annotations

import logging
import time

import discord
from discord import app_commands
from discord.ext import commands, tasks

from core import blueprint as bp
from core import ui
from core.automod_rules import JoinRateMonitor, MessageTracker, check_links, count_mentions, has_invite
from core.bot import PolyBattleBot, require_roles, respond
from core.text import bi, format_duration, truncate

log = logging.getLogger("polybattle.automod")

PUNISH_COOLDOWN = 15  # segundos sem nova punição após uma ação do automod


class AutoMod(commands.Cog):
    automod_group = app_commands.Group(name="automod", description="Configuração do automod",
                                       guild_only=True,
                                       default_permissions=discord.Permissions(manage_guild=True))
    raid_group = app_commands.Group(name="raidmode", description="Controle do modo anti-raid",
                                    guild_only=True,
                                    default_permissions=discord.Permissions(ban_members=True))

    def __init__(self, bot: PolyBattleBot) -> None:
        self.bot = bot
        s = bot.settings
        self.tracker = MessageTracker(s.automod_flood_messages, s.automod_flood_seconds,
                                      s.automod_duplicate_messages, s.automod_duplicate_seconds)
        self.joins = JoinRateMonitor(s.raid_join_threshold, s.raid_join_seconds)
        self.raid_until: dict[int, float] = {}
        self._cooldown: dict[tuple[int, int], float] = {}
        self._blocklist: dict[int, set[str]] = {}

    async def cog_load(self) -> None:
        self.housekeeping.start()

    async def cog_unload(self) -> None:
        self.housekeeping.cancel()

    # ------------------------------------------------------------------ util
    async def _blocked(self, guild_id: int) -> set[str]:
        if guild_id not in self._blocklist:
            self._blocklist[guild_id] = await self.bot.db.blocked_domains(guild_id)
        return self._blocklist[guild_id]

    def _exempt(self, member: discord.Member) -> bool:
        return (member.guild_permissions.manage_messages or member.guild_permissions.administrator
                or self.bot.is_staff(member))

    async def _notice(self, channel: discord.abc.Messageable, member: discord.Member, pt: str, en: str) -> None:
        try:
            await channel.send(f"{member.mention} {bi(pt, en)}", delete_after=10,
                               allowed_mentions=discord.AllowedMentions(users=[member]))
        except discord.HTTPException:
            pass

    async def _punish(self, message: discord.Message, member: discord.Member, *, kind: str,
                      reason: str, timeout_minutes: int | None, warn: bool) -> None:
        guild = member.guild
        key = (guild.id, member.id)
        self._cooldown[key] = time.monotonic() + PUNISH_COOLDOWN
        self.tracker.reset(guild.id, member.id)
        moderation = self.bot.get_cog("Moderation")
        me = guild.me
        full_reason = f"[AutoMod] {reason}"
        try:
            if timeout_minutes and moderation and member.top_role < me.top_role:
                await moderation.apply(guild, member, "timeout", me, full_reason, timeout_minutes * 60,  # type: ignore[attr-defined]
                                       extra=f"Canal: {message.channel.mention}\nConteúdo: {truncate(message.content, 500)}")
            if warn and moderation and member.top_role < me.top_role:
                await moderation.warn(guild, member, me, full_reason)  # type: ignore[attr-defined]
            if not timeout_minutes and not warn:
                await self.bot.send_log(guild, ui.log_embed(f"🤖 AutoMod — {kind}", reason, user=member,
                                                            color=bp.COLOR_WARNING))
        except discord.HTTPException as exc:
            log.warning("AutoMod não conseguiu punir %s: %s", member.id, exc)

    async def _delete(self, message: discord.Message) -> None:
        try:
            await message.delete()
        except discord.NotFound:
            pass
        except discord.HTTPException as exc:
            log.warning("AutoMod não conseguiu apagar mensagem %s: %s", message.id, exc)

    # ------------------------------------------------------------------ mensagens
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        if message.author.bot or message.guild is None or not isinstance(message.author, discord.Member):
            return
        member = message.author
        guild = message.guild
        if not self.bot.is_setup(guild.id) or self._exempt(member):
            return
        if self._cooldown.get((guild.id, member.id), 0) > time.monotonic():
            return
        s = self.bot.settings
        content = message.content or ""

        # 1. Convites
        if has_invite(content):
            await self._delete(message)
            await self._notice(message.channel, member, "convites de outros servidores não são permitidos.",
                               "server invites are not allowed.")
            await self._punish(message, member, kind="invite", reason="Convite de servidor", timeout_minutes=None,
                               warn=True)
            return

        # 2. Links maliciosos / suspeitos
        verdict = check_links(content, await self._blocked(guild.id))
        if verdict is not None:
            await self._delete(message)
            if verdict.severity == "malicious":
                await self._notice(message.channel, member, "link malicioso removido.", "malicious link removed.")
                await self._punish(message, member, kind="malicious_link",
                                   reason=f"Link malicioso ({verdict.domain}: {verdict.reason})",
                                   timeout_minutes=s.automod_malicious_link_timeout_minutes, warn=True)
            else:
                await self._notice(message.channel, member, "link suspeito removido.", "suspicious link removed.")
                await self._punish(message, member, kind="suspicious_link",
                                   reason=f"Link suspeito ({verdict.domain}: {verdict.reason})",
                                   timeout_minutes=None, warn=True)
            return

        # 3. Excesso de menções
        everyone_attempt = "@everyone" in content or "@here" in content
        mentions = count_mentions(len(set(message.raw_mentions)), len(set(message.raw_role_mentions)),
                                  everyone_attempt)
        if mentions >= s.automod_max_mentions:
            await self._delete(message)
            await self._notice(message.channel, member, "excesso de menções.", "too many mentions.")
            await self._punish(message, member, kind="mention_spam", reason=f"Excesso de menções ({mentions})",
                               timeout_minutes=s.automod_timeout_minutes, warn=False)
            return

        # 4. Flood / spam repetido
        now = time.monotonic()
        result = self.tracker.add(guild.id, member.id, now, content, message.channel.id, message.id)
        if result is not None:
            window = max(s.automod_flood_seconds, s.automod_duplicate_seconds)
            recent = self.tracker.recent_messages(guild.id, member.id, now, window)
            await self._bulk_delete(guild, recent)
            label = ("flood de mensagens", "message flood") if result == "flood" else \
                    ("mensagens repetidas", "repeated messages")
            await self._notice(message.channel, member, f"{label[0]} detectado.", f"{label[1]} detected.")
            await self._punish(message, member, kind=result, reason=label[0].capitalize(),
                               timeout_minutes=s.automod_timeout_minutes, warn=False)

    async def _bulk_delete(self, guild: discord.Guild, items: list[tuple[int, int]]) -> None:
        by_channel: dict[int, list[int]] = {}
        for channel_id, message_id in items:
            by_channel.setdefault(channel_id, []).append(message_id)
        for channel_id, ids in by_channel.items():
            channel = guild.get_channel_or_thread(channel_id)
            if not isinstance(channel, (discord.TextChannel, discord.Thread, discord.VoiceChannel)):
                continue
            try:
                await channel.delete_messages([discord.Object(id=i) for i in ids], reason="AutoMod: flood")
            except discord.HTTPException as exc:
                log.info("Falha ao limpar flood em %s: %s", channel_id, exc)

    # ------------------------------------------------------------------ anti-raid
    def raid_active(self, guild_id: int) -> bool:
        return self.raid_until.get(guild_id, 0) > time.time()

    async def _alert_raid(self, guild: discord.Guild, text: str) -> None:
        embed = ui.brand("🚨 ALERTA DE RAID | RAID ALERT", text, color=bp.COLOR_DANGER)
        await self.bot.send_log(guild, embed)
        staff_chat = self.bot.channel(guild, "staff_chat")
        if isinstance(staff_chat, discord.TextChannel):
            roles = [r for r in (self.bot.role(guild, k) for k in bp.SENIOR_MOD_ROLES) if r]
            try:
                await staff_chat.send(content=" ".join(r.mention for r in roles), embed=embed,
                                      allowed_mentions=discord.AllowedMentions(roles=roles))
            except discord.HTTPException:
                pass

    async def enable_raid_mode(self, guild: discord.Guild, minutes: int, reason: str) -> None:
        self.raid_until[guild.id] = time.time() + minutes * 60
        await self._alert_raid(guild, f"Modo raid **ATIVADO** por {minutes} min.\nMotivo: {reason}\n"
                                      "Novos membros serão expulsos automaticamente. Use `/raidmode off` para encerrar.")

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        guild = member.guild
        if member.bot or not self.bot.is_setup(guild.id):
            return
        if not self.raid_active(guild.id) and self.joins.add(guild.id, time.time()):
            s = self.bot.settings
            self.joins.reset(guild.id)
            await self.enable_raid_mode(guild, s.raid_mode_minutes,
                                        f"{s.raid_join_threshold} entradas em {s.raid_join_seconds}s")
        if self.raid_active(guild.id):
            try:
                await member.send(embed=ui.warning(bi(
                    f"O servidor **{guild.name}** está temporariamente em modo de proteção. Tente entrar novamente "
                    "em alguns minutos.",
                    "The server is temporarily in lockdown. Please try again in a few minutes.")))
            except (discord.Forbidden, discord.HTTPException):
                pass
            try:
                await guild.kick(member, reason="Anti-raid: modo raid ativo")
                await self.bot.db.log_action(guild.id, "kick", member.id, guild.me.id, "Anti-raid: modo raid ativo")
            except discord.HTTPException as exc:
                log.warning("Anti-raid não conseguiu expulsar %s: %s", member.id, exc)

    @tasks.loop(seconds=30)
    async def housekeeping(self) -> None:
        now = time.time()
        for guild_id, until in list(self.raid_until.items()):
            if until <= now:
                self.raid_until.pop(guild_id, None)
                guild = self.bot.get_guild(guild_id)
                if guild:
                    await self.bot.send_log(guild, ui.log_embed("🟢 Modo raid encerrado automaticamente",
                                                                color=bp.COLOR_GREEN_LIGHT))
        mono = time.monotonic()
        self.tracker.prune(mono)
        for key in [k for k, v in self._cooldown.items() if v < mono]:
            self._cooldown.pop(key, None)

    @housekeeping.before_loop
    async def _before(self) -> None:
        await self.bot.wait_until_ready()

    # ------------------------------------------------------------------ comandos
    @raid_group.command(name="on", description="Ativa o modo anti-raid manualmente")
    @app_commands.describe(minutes="Duração em minutos (1–720)")
    @require_roles(*bp.SENIOR_MOD_ROLES)
    async def raid_on(self, interaction: discord.Interaction,
                      minutes: app_commands.Range[int, 1, 720] = 30) -> None:
        await self.enable_raid_mode(interaction.guild, minutes, f"ativado por {interaction.user}")  # type: ignore[arg-type]
        await respond(interaction, ui.success(f"Modo raid ativo por {minutes} minutos."))

    @raid_group.command(name="off", description="Desativa o modo anti-raid")
    @require_roles(*bp.SENIOR_MOD_ROLES)
    async def raid_off(self, interaction: discord.Interaction) -> None:
        self.raid_until.pop(interaction.guild_id, None)  # type: ignore[arg-type]
        self.joins.reset(interaction.guild_id)  # type: ignore[arg-type]
        await respond(interaction, ui.success("Modo raid desativado."))
        await self.bot.send_log(interaction.guild, ui.log_embed(  # type: ignore[arg-type]
            "🟢 Modo raid desativado", user=interaction.user, color=bp.COLOR_GREEN_LIGHT))

    @raid_group.command(name="status", description="Mostra o estado do modo anti-raid")
    @require_roles(*bp.STAFF_ROLES)
    async def raid_status(self, interaction: discord.Interaction) -> None:
        until = self.raid_until.get(interaction.guild_id, 0)  # type: ignore[arg-type]
        if until > time.time():
            text = f"🔴 Ativo — termina <t:{int(until)}:R>"
        else:
            text = "🟢 Inativo"
        s = self.bot.settings
        text += (f"\nGatilho: {s.raid_join_threshold} entradas em {s.raid_join_seconds}s • "
                 f"duração {format_duration(s.raid_mode_minutes * 60)}")
        await respond(interaction, ui.brand("🛡️ Anti-raid", text))

    @automod_group.command(name="blocklink-add", description="Adiciona um domínio à blocklist")
    @app_commands.describe(domain="Ex.: site-malicioso.com")
    @require_roles(*bp.ADMIN_ROLES)
    async def block_add(self, interaction: discord.Interaction, domain: app_commands.Range[str, 3, 120]) -> None:
        domain = domain.lower().strip().removeprefix("https://").removeprefix("http://").split("/")[0]
        if "." not in domain:
            await respond(interaction, ui.error("Domínio inválido."))
            return
        added = await self.bot.db.add_blocked_domain(interaction.guild_id, domain, interaction.user.id)  # type: ignore[arg-type]
        self._blocklist.pop(interaction.guild_id, None)  # type: ignore[arg-type]
        await respond(interaction, ui.success(f"`{domain}` {'adicionado à' if added else 'já estava na'} blocklist."))

    @automod_group.command(name="blocklink-remove", description="Remove um domínio da blocklist")
    @require_roles(*bp.ADMIN_ROLES)
    async def block_remove(self, interaction: discord.Interaction, domain: str) -> None:
        removed = await self.bot.db.remove_blocked_domain(interaction.guild_id, domain.lower().strip())  # type: ignore[arg-type]
        self._blocklist.pop(interaction.guild_id, None)  # type: ignore[arg-type]
        await respond(interaction, ui.success("Removido.") if removed else ui.error("Domínio não estava na blocklist."))

    @automod_group.command(name="blocklink-list", description="Lista os domínios bloqueados")
    @require_roles(*bp.STAFF_ROLES)
    async def block_list(self, interaction: discord.Interaction) -> None:
        domains = sorted(await self._blocked(interaction.guild_id))  # type: ignore[arg-type]
        await respond(interaction, ui.brand("🔗 Blocklist", "\n".join(f"• `{d}`" for d in domains[:80])
                                            or "Nenhum domínio bloqueado."))

    @automod_group.command(name="settings", description="Mostra os limites atuais do automod")
    @require_roles(*bp.STAFF_ROLES)
    async def show_settings(self, interaction: discord.Interaction) -> None:
        s = self.bot.settings
        text = (f"Flood: **{s.automod_flood_messages}** msgs / {s.automod_flood_seconds}s\n"
                f"Repetição: **{s.automod_duplicate_messages}** iguais / {s.automod_duplicate_seconds}s\n"
                f"Menções máx.: **{s.automod_max_mentions}**\n"
                f"Timeout padrão: **{s.automod_timeout_minutes} min**\n"
                f"Timeout link malicioso: **{s.automod_malicious_link_timeout_minutes} min**\n"
                f"Avisos → timeout/kick/ban: **{s.warn_timeout_threshold} / {s.warn_kick_threshold} / "
                f"{s.warn_ban_threshold}** (0 = desativado)\n"
                "-# Ajuste no arquivo .env e reinicie o bot.")
        await respond(interaction, ui.brand("🤖 AutoMod", text))


async def setup(bot: PolyBattleBot) -> None:
    await bot.add_cog(AutoMod(bot))
