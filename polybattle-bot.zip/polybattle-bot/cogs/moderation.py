"""
Moderação e sistema de punições.

Comandos: /warn, /warnings, /unwarn, /clearwarnings, /mute, /unmute, /kick,
/ban, /unban, /purge, /slowmode, /lock, /unlock, /history.

* Todas as ações validam hierarquia (moderador x alvo x bot) antes de executar.
* Toda ação é registrada no banco (``mod_actions``) e em #staff-logs.
* Avisos acumulados disparam punições automáticas (configurável no .env).
* "Mute" usa o timeout nativo do Discord — não depende de cargo Muted.
"""

from __future__ import annotations

import datetime as dt
import logging
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from core import blueprint as bp
from core import ui
from core.bot import PolyBattleBot, hierarchy_error, require_roles, respond
from core.punishments import escalation_for
from core.text import MAX_TIMEOUT_SECONDS, format_duration, parse_duration, truncate

log = logging.getLogger("polybattle.moderation")

ACTION_LABEL = {
    "warn": ("⚠️", "Aviso | Warning", bp.COLOR_WARNING),
    "timeout": ("🔇", "Mute (timeout)", bp.COLOR_WARNING),
    "untimeout": ("🔊", "Unmute", bp.COLOR_GREEN_LIGHT),
    "kick": ("👢", "Kick", bp.COLOR_DANGER),
    "ban": ("🔨", "Ban", bp.COLOR_DANGER),
    "unban": ("♻️", "Unban", bp.COLOR_GREEN_LIGHT),
}


class Moderation(commands.Cog):
    def __init__(self, bot: PolyBattleBot) -> None:
        self.bot = bot

    # ------------------------------------------------------------------ núcleo
    async def _notify(self, user: discord.abc.User, guild: discord.Guild, action: str,
                      reason: str | None, duration: int | None) -> None:
        emoji, label, color = ACTION_LABEL[action]
        desc = f"**Servidor:** {guild.name}\n**Ação:** {label}\n**Motivo:** {truncate(reason or '—', 900)}"
        if duration:
            desc += f"\n**Duração:** {format_duration(duration)}"
        desc += "\n\n-# Contestações: abra um ticket. | Appeals: open a ticket."
        try:
            await user.send(embed=ui.brand(f"{emoji} Notificação de moderação", desc, color=color))
        except (discord.Forbidden, discord.HTTPException):
            pass

    async def record(self, guild: discord.Guild, action: str, target: discord.abc.User,
                     moderator: discord.abc.User, reason: str | None, duration: int | None = None,
                     extra: str | None = None) -> int:
        case_id = await self.bot.db.log_action(guild.id, action, target.id, moderator.id, reason, duration)
        emoji, label, color = ACTION_LABEL[action]
        embed = ui.log_embed(f"{emoji} {label} — caso #{case_id}", color=color, user=target)
        embed.add_field(name="Alvo | Target", value=ui.user_field(target), inline=False)
        embed.add_field(name="Moderador", value=ui.user_field(moderator), inline=False)
        embed.add_field(name="Motivo | Reason", value=truncate(reason or "—", 1024), inline=False)
        if duration:
            embed.add_field(name="Duração", value=format_duration(duration))
        if extra:
            embed.add_field(name="Info", value=truncate(extra, 1024), inline=False)
        await self.bot.send_log(guild, embed)
        return case_id

    async def apply(self, guild: discord.Guild, target: discord.Member | discord.User, action: str,
                    moderator: discord.abc.User, reason: str, duration: int | None = None,
                    *, notify: bool = True, extra: str | None = None) -> int:
        """
        Executa a ação no Discord, notifica o alvo e registra. Usado pelos comandos e pelo automod.
        Levanta discord.Forbidden/HTTPException em caso de falha.
        """
        audit_reason = truncate(f"{moderator} : {reason}", 500)
        delete_seconds = 0
        if action == "ban":
            delete_seconds, duration = duration or 0, None   # para ban, "duration" = segundos de mensagens a apagar
        if action in ("kick", "ban") and notify:
            await self._notify(target, guild, action, reason, duration)  # antes: depois não há DM possível
        if action == "timeout":
            assert isinstance(target, discord.Member) and duration
            await target.timeout(dt.timedelta(seconds=min(duration, MAX_TIMEOUT_SECONDS)), reason=audit_reason)
        elif action == "untimeout":
            assert isinstance(target, discord.Member)
            await target.timeout(None, reason=audit_reason)
        elif action == "kick":
            await guild.kick(target, reason=audit_reason)
        elif action == "ban":
            await guild.ban(target, reason=audit_reason, delete_message_seconds=delete_seconds)
        elif action == "unban":
            await guild.unban(target, reason=audit_reason)
        if action not in ("kick", "ban") and notify:
            await self._notify(target, guild, action, reason, duration)
        return await self.record(guild, action, target, moderator, reason, duration, extra)

    async def warn(self, guild: discord.Guild, target: discord.Member, moderator: discord.abc.User,
                   reason: str) -> tuple[int, int, str | None]:
        """Registra um aviso e aplica escalonamento. Retorna (caso, total_avisos, punição_extra)."""
        await self.bot.db.add_warning(guild.id, target.id, moderator.id, reason)
        count = len(await self.bot.db.active_warnings(guild.id, target.id))
        case_id = await self.apply(guild, target, "warn", moderator, reason, extra=f"Avisos ativos: {count}")

        s = self.bot.settings
        escalation = escalation_for(count, timeout_at=s.warn_timeout_threshold,
                                    kick_at=s.warn_kick_threshold, ban_at=s.warn_ban_threshold)
        if escalation is None:
            return case_id, count, None
        me = guild.me
        if target.top_role >= me.top_role or target.id == guild.owner_id:
            return case_id, count, None
        auto_reason = f"Punição automática: {count} avisos ativos"
        try:
            if escalation == "timeout":
                await self.apply(guild, target, "timeout", me, auto_reason, s.warn_timeout_minutes * 60)
            else:
                await self.apply(guild, target, escalation, me, auto_reason)
        except discord.HTTPException as exc:
            log.warning("Falha na punição automática (%s) de %s: %s", escalation, target.id, exc)
            return case_id, count, None
        return case_id, count, escalation

    # ------------------------------------------------------------------ helpers de comando
    async def _check_target(self, interaction: discord.Interaction, target: discord.Member) -> bool:
        assert interaction.guild is not None and isinstance(interaction.user, discord.Member)
        if err := hierarchy_error(interaction.user, target, interaction.guild.me):
            await respond(interaction, ui.error(err))
            return False
        return True

    # ------------------------------------------------------------------ avisos
    @app_commands.command(name="warn", description="Aplica um aviso a um membro")
    @app_commands.describe(member="Membro", reason="Motivo do aviso")
    @app_commands.guild_only()
    @app_commands.default_permissions(moderate_members=True)
    @require_roles(*bp.MOD_ROLES)
    async def warn_cmd(self, interaction: discord.Interaction, member: discord.Member,
                       reason: app_commands.Range[str, 3, 500]) -> None:
        if not await self._check_target(interaction, member):
            return
        await interaction.response.defer(ephemeral=True)
        case_id, count, extra = await self.warn(interaction.guild, member, interaction.user, reason)  # type: ignore[arg-type]
        msg = f"{member.mention} recebeu um aviso (caso #{case_id}). Avisos ativos: **{count}**."
        if extra:
            msg += f"\nPunição automática aplicada: **{extra}**."
        await respond(interaction, ui.success(msg))

    @app_commands.command(name="warnings", description="Lista os avisos ativos de um membro")
    @app_commands.guild_only()
    @require_roles(*bp.STAFF_ROLES)
    async def warnings_cmd(self, interaction: discord.Interaction, member: discord.Member) -> None:
        rows = await self.bot.db.active_warnings(interaction.guild_id, member.id)  # type: ignore[arg-type]
        if not rows:
            await respond(interaction, ui.success(f"{member.mention} não possui avisos ativos."))
            return
        lines = [f"`#{r['id']}` <t:{int(r['created_at'])}:d> por <@{r['moderator_id']}> — {truncate(r['reason'], 120)}"
                 for r in rows[-20:]]
        await respond(interaction, ui.brand(f"⚠️ Avisos de {member} ({len(rows)})", "\n".join(lines),
                                            color=bp.COLOR_WARNING))

    @app_commands.command(name="unwarn", description="Remove um aviso pelo ID")
    @app_commands.guild_only()
    @app_commands.default_permissions(moderate_members=True)
    @require_roles(*bp.MOD_ROLES)
    async def unwarn(self, interaction: discord.Interaction, warning_id: int) -> None:
        ok = await self.bot.db.remove_warning(interaction.guild_id, warning_id)  # type: ignore[arg-type]
        if not ok:
            await respond(interaction, ui.error("Aviso não encontrado ou já removido."))
            return
        await respond(interaction, ui.success(f"Aviso `#{warning_id}` removido."))
        await self.bot.send_log(interaction.guild, ui.log_embed(  # type: ignore[arg-type]
            f"♻️ Aviso #{warning_id} removido", user=interaction.user))

    @app_commands.command(name="clearwarnings", description="Remove todos os avisos de um membro")
    @app_commands.guild_only()
    @app_commands.default_permissions(ban_members=True)
    @require_roles(*bp.SENIOR_MOD_ROLES)
    async def clearwarnings(self, interaction: discord.Interaction, member: discord.Member) -> None:
        n = await self.bot.db.clear_warnings(interaction.guild_id, member.id)  # type: ignore[arg-type]
        await respond(interaction, ui.success(f"{n} aviso(s) de {member.mention} removido(s)."))
        await self.bot.send_log(interaction.guild, ui.log_embed(  # type: ignore[arg-type]
            "♻️ Avisos limpos", f"{member.mention}: {n} aviso(s)", user=interaction.user))

    # ------------------------------------------------------------------ mute / kick / ban
    @app_commands.command(name="mute", description="Silencia (timeout) um membro. Ex.: 10m, 2h, 1d")
    @app_commands.describe(member="Membro", duration="Duração (ex.: 30m, 2h, 1d; máx. 28d)", reason="Motivo")
    @app_commands.guild_only()
    @app_commands.default_permissions(moderate_members=True)
    @require_roles(*bp.MOD_ROLES)
    async def mute(self, interaction: discord.Interaction, member: discord.Member, duration: str,
                   reason: app_commands.Range[str, 3, 500]) -> None:
        seconds = parse_duration(duration)
        if seconds is None or seconds > MAX_TIMEOUT_SECONDS:
            await respond(interaction, ui.error("Duração inválida. Use formatos como `30m`, `2h`, `1d` (máx. 28d)."))
            return
        if not await self._check_target(interaction, member):
            return
        await interaction.response.defer(ephemeral=True)
        case_id = await self.apply(interaction.guild, member, "timeout", interaction.user, reason, seconds)  # type: ignore[arg-type]
        await respond(interaction, ui.success(f"{member.mention} silenciado por {format_duration(seconds)} (caso #{case_id})."))

    @app_commands.command(name="unmute", description="Remove o timeout de um membro")
    @app_commands.guild_only()
    @app_commands.default_permissions(moderate_members=True)
    @require_roles(*bp.MOD_ROLES)
    async def unmute(self, interaction: discord.Interaction, member: discord.Member,
                     reason: Optional[app_commands.Range[str, 3, 500]] = None) -> None:
        if not member.is_timed_out():
            await respond(interaction, ui.error("Este membro não está silenciado."))
            return
        if not await self._check_target(interaction, member):
            return
        case_id = await self.apply(interaction.guild, member, "untimeout", interaction.user,  # type: ignore[arg-type]
                                   reason or "Timeout removido")
        await respond(interaction, ui.success(f"{member.mention} pode falar novamente (caso #{case_id})."))

    @app_commands.command(name="kick", description="Expulsa um membro do servidor")
    @app_commands.guild_only()
    @app_commands.default_permissions(kick_members=True)
    @require_roles(*bp.MOD_ROLES)
    async def kick(self, interaction: discord.Interaction, member: discord.Member,
                   reason: app_commands.Range[str, 3, 500]) -> None:
        if not await self._check_target(interaction, member):
            return
        await interaction.response.defer(ephemeral=True)
        case_id = await self.apply(interaction.guild, member, "kick", interaction.user, reason)  # type: ignore[arg-type]
        await respond(interaction, ui.success(f"{member} foi expulso (caso #{case_id})."))

    @app_commands.command(name="ban", description="Bane um usuário (membro ou ID)")
    @app_commands.describe(user="Usuário (pode ser ID de quem não está no servidor)", reason="Motivo",
                           delete_messages="Apagar mensagens recentes")
    @app_commands.choices(delete_messages=[
        app_commands.Choice(name="Não apagar", value=0),
        app_commands.Choice(name="Última hora", value=3600),
        app_commands.Choice(name="Últimas 24h", value=86400),
        app_commands.Choice(name="Últimos 7 dias", value=604800),
    ])
    @app_commands.guild_only()
    @app_commands.default_permissions(ban_members=True)
    @require_roles(*bp.SENIOR_MOD_ROLES)
    async def ban(self, interaction: discord.Interaction, user: discord.User,
                  reason: app_commands.Range[str, 3, 500],
                  delete_messages: Optional[app_commands.Choice[int]] = None) -> None:
        guild = interaction.guild
        assert guild is not None
        member = guild.get_member(user.id)
        if member is not None and not await self._check_target(interaction, member):
            return
        if member is None and user.id == interaction.user.id:
            await respond(interaction, ui.error("Você não pode banir a si mesmo."))
            return
        await interaction.response.defer(ephemeral=True)
        target = member or user
        case_id = await self.apply(guild, target, "ban", interaction.user, reason,
                                   delete_messages.value if delete_messages else 0,
                                   notify=member is not None)
        await respond(interaction, ui.success(f"{user} foi banido (caso #{case_id})."))

    @app_commands.command(name="unban", description="Remove o banimento de um usuário pelo ID")
    @app_commands.guild_only()
    @app_commands.default_permissions(ban_members=True)
    @require_roles(*bp.SENIOR_MOD_ROLES)
    async def unban(self, interaction: discord.Interaction, user_id: str,
                    reason: app_commands.Range[str, 3, 500]) -> None:
        guild = interaction.guild
        assert guild is not None
        if not user_id.isdigit():
            await respond(interaction, ui.error("Informe um ID numérico válido."))
            return
        try:
            ban_entry = await guild.fetch_ban(discord.Object(id=int(user_id)))
        except discord.NotFound:
            await respond(interaction, ui.error("Este usuário não está banido."))
            return
        case_id = await self.apply(guild, ban_entry.user, "unban", interaction.user, reason, notify=False)
        await respond(interaction, ui.success(f"{ban_entry.user} foi desbanido (caso #{case_id})."))

    # ------------------------------------------------------------------ utilidades de canal
    @app_commands.command(name="purge", description="Apaga mensagens recentes do canal")
    @app_commands.describe(amount="Quantidade (1–100)", member="Apagar somente mensagens deste membro")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_messages=True)
    @require_roles(*bp.MOD_ROLES)
    async def purge(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100],
                    member: Optional[discord.Member] = None) -> None:
        channel = interaction.channel
        if not isinstance(channel, (discord.TextChannel, discord.Thread)):
            await respond(interaction, ui.error("Canal não suportado."))
            return
        await interaction.response.defer(ephemeral=True)
        remaining = amount

        def check(message: discord.Message) -> bool:
            nonlocal remaining
            if remaining <= 0 or (member is not None and message.author.id != member.id):
                return False
            remaining -= 1
            return True

        deleted = await channel.purge(limit=amount if member is None else 500, check=check,
                                      reason=f"/purge por {interaction.user}", bulk=True)
        await respond(interaction, ui.success(f"{len(deleted)} mensagem(ns) apagada(s)."))
        await self.bot.send_log(interaction.guild, ui.log_embed(  # type: ignore[arg-type]
            "🧹 Purge", f"{len(deleted)} mensagens em {channel.mention}"
            + (f" (de {member.mention})" if member else ""), user=interaction.user))

    @app_commands.command(name="slowmode", description="Define o modo lento do canal (0 desativa)")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_messages=True)
    @require_roles(*bp.MOD_ROLES)
    async def slowmode(self, interaction: discord.Interaction, seconds: app_commands.Range[int, 0, 21600]) -> None:
        channel = interaction.channel
        if not isinstance(channel, discord.TextChannel):
            await respond(interaction, ui.error("Use em um canal de texto."))
            return
        await channel.edit(slowmode_delay=seconds, reason=f"/slowmode por {interaction.user}")
        await respond(interaction, ui.success(f"Modo lento: **{seconds}s**."))

    async def _set_lock(self, interaction: discord.Interaction, locked: bool) -> None:
        channel = interaction.channel
        guild = interaction.guild
        if not isinstance(channel, discord.TextChannel) or guild is None:
            await respond(interaction, ui.error("Use em um canal de texto."))
            return
        verified = self.bot.role(guild, "verified")
        if verified is None:
            await respond(interaction, ui.error("Cargo Verified não encontrado."))
            return
        overwrite = channel.overwrites_for(verified)
        overwrite.send_messages = False if locked else None
        await channel.set_permissions(verified, overwrite=overwrite,
                                      reason=f"{'/lock' if locked else '/unlock'} por {interaction.user}")
        state = "🔒 Canal bloqueado | Channel locked" if locked else "🔓 Canal desbloqueado | Channel unlocked"
        await respond(interaction, ui.brand(state, None, timestamp=False), ephemeral=False)
        await self.bot.send_log(guild, ui.log_embed(state, channel.mention, user=interaction.user))

    @app_commands.command(name="lock", description="Impede membros de enviar mensagens neste canal")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_messages=True)
    @require_roles(*bp.MOD_ROLES)
    async def lock(self, interaction: discord.Interaction) -> None:
        await self._set_lock(interaction, True)

    @app_commands.command(name="unlock", description="Libera novamente o envio de mensagens neste canal")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_messages=True)
    @require_roles(*bp.MOD_ROLES)
    async def unlock(self, interaction: discord.Interaction) -> None:
        await self._set_lock(interaction, False)

    @app_commands.command(name="history", description="Histórico de punições de um usuário")
    @app_commands.guild_only()
    @require_roles(*bp.STAFF_ROLES)
    async def history(self, interaction: discord.Interaction, user: discord.User) -> None:
        rows = await self.bot.db.actions_for(interaction.guild_id, user.id, limit=15)  # type: ignore[arg-type]
        if not rows:
            await respond(interaction, ui.success(f"{user} não possui registros."))
            return
        lines = []
        for r in rows:
            emoji = ACTION_LABEL.get(r["action"], ("•",))[0]
            dur = f" ({format_duration(r['duration_s'])})" if r["duration_s"] else ""
            lines.append(f"{emoji} `#{r['id']}` **{r['action']}**{dur} <t:{int(r['created_at'])}:d> "
                         f"por <@{r['moderator_id']}> — {truncate(r['reason'], 80)}")
        await respond(interaction, ui.brand(f"📁 Histórico de {user}", "\n".join(lines)))


async def setup(bot: PolyBattleBot) -> None:
    await bot.add_cog(Moderation(bot))
