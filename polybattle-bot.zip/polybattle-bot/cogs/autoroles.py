"""
Cargos automáticos.

* Verified + Member: concedidos ao concluir a verificação (cogs/verification.py).
* Veteran: concedido automaticamente a membros verificados que estão no servidor
  há VETERAN_DAYS dias ou mais (verificação a cada 6 horas e via /autoroles sync).
* Quem recebe um cargo de equipe/desenvolvimento ganha também Verified, para
  enxergar os canais da comunidade.
"""

from __future__ import annotations

import datetime as dt
import logging

import discord
from discord import app_commands
from discord.ext import commands, tasks

from core import blueprint as bp
from core import ui
from core.bot import PolyBattleBot, require_roles, respond

log = logging.getLogger("polybattle.autoroles")

MAX_PER_RUN = 200
TEAM_ROLES = bp.STAFF_ROLES + bp.DEV_ROLES + ("vip",)


class AutoRoles(commands.Cog):
    autoroles_group = app_commands.Group(name="autoroles", description="Cargos automáticos", guild_only=True,
                                         default_permissions=discord.Permissions(manage_roles=True))

    def __init__(self, bot: PolyBattleBot) -> None:
        self.bot = bot

    async def cog_load(self) -> None:
        self.veteran_loop.start()

    async def cog_unload(self) -> None:
        self.veteran_loop.cancel()

    async def promote_veterans(self, guild: discord.Guild) -> int:
        veteran = self.bot.role(guild, "veteran")
        verified = self.bot.role(guild, "verified")
        if veteran is None or verified is None or veteran >= guild.me.top_role:
            return 0
        cutoff = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=self.bot.settings.veteran_days)
        promoted = 0
        for member in guild.members:
            if promoted >= MAX_PER_RUN:
                break
            if (member.bot or veteran in member.roles or verified not in member.roles
                    or member.joined_at is None or member.joined_at > cutoff):
                continue
            try:
                await member.add_roles(veteran, reason=f"Auto: {self.bot.settings.veteran_days}+ dias no servidor")
                promoted += 1
            except discord.HTTPException as exc:
                log.warning("Falha ao promover %s a Veteran: %s", member.id, exc)
                break
        if promoted:
            await self.bot.send_log(guild, ui.log_embed("🎖️ Veteranos promovidos",
                                                        f"{promoted} membro(s) receberam {veteran.mention}."))
        return promoted

    @tasks.loop(hours=6)
    async def veteran_loop(self) -> None:
        for guild in self.bot.guilds:
            if self.bot.is_setup(guild.id):
                await self.promote_veterans(guild)

    @veteran_loop.before_loop
    async def _before(self) -> None:
        await self.bot.wait_until_ready()

    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member) -> None:
        guild = after.guild
        if not self.bot.is_setup(guild.id) or before.roles == after.roles:
            return
        verified = self.bot.role(guild, "verified")
        if verified is None or verified in after.roles or verified >= guild.me.top_role:
            return
        added = set(after.roles) - set(before.roles)
        team = {self.bot.role(guild, k) for k in TEAM_ROLES} - {None}
        if added & team:
            try:
                await after.add_roles(verified, reason="Auto: membro da equipe recebe Verified")
            except discord.HTTPException as exc:
                log.warning("Falha ao conceder Verified para %s: %s", after.id, exc)

    @autoroles_group.command(name="sync", description="Executa agora a promoção automática de veteranos")
    @require_roles(*bp.ADMIN_ROLES)
    async def sync(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True)
        n = await self.promote_veterans(interaction.guild)  # type: ignore[arg-type]
        await respond(interaction, ui.success(f"{n} membro(s) promovido(s) a Veteran."))


async def setup(bot: PolyBattleBot) -> None:
    await bot.add_cog(AutoRoles(bot))
