# POLYBATTLE | OFFICIAL — Bot do servidor Discord

Bot oficial do servidor do **PolyBattle** (FPS tático no Roblox). Ele monta o servidor inteiro
(cargos, categorias, canais e permissões) com um único comando e mantém a comunidade com
verificação, tickets, denúncias, sugestões, moderação, automod, anti-raid e logs.

- Python 3.10+ e **discord.py 2.4+** (slash commands, botões, menus e formulários)
- Código modular em *cogs*, banco **SQLite** criado automaticamente, configuração por **.env**
- Setup **idempotente**: rodar de novo atualiza sem duplicar canais ou cargos

---

## 1. Estrutura do projeto

```
polybattle-bot/
├── bot.py                  # ponto de entrada (python bot.py / python bot.py --check)
├── requirements.txt        # dependências de produção
├── requirements-dev.txt    # + pytest
├── .env.example            # modelo de configuração
├── core/
│   ├── bot.py              # classe do bot, checks de permissão, tratamento global de erros
│   ├── config.py           # leitura/validação do .env
│   ├── database.py         # SQLite (schema e migração automáticos)
│   ├── blueprint.py        # planta do servidor: cargos, cores, canais, permissões, tipos de ticket
│   ├── content.py          # textos oficiais (regras, apresentação, painéis) PT/EN
│   ├── automod_rules.py    # detecção de flood, spam, convites e links maliciosos
│   ├── punishments.py      # escalonamento de punições por avisos
│   ├── transcript.py       # transcript HTML dos tickets
│   ├── text.py             # utilitários (durações, referências de canais…)
│   └── ui.py               # embeds com a identidade visual
├── cogs/
│   ├── setup.py            # /setup install | panels | status
│   ├── verification.py     # painel de verificação com código de segurança
│   ├── welcome.py          # boas-vindas + registro de entradas e saídas
│   ├── tickets.py          # sistema de tickets com transcript
│   ├── reports.py          # denúncias (painel, /report, menu de contexto)
│   ├── suggestions.py      # /suggest com votação
│   ├── moderation.py       # avisos, mute, kick, ban, purge, lock…
│   ├── automod.py          # moderação automática + anti-raid
│   ├── security.py         # bloqueio de escalonamento de permissões
│   ├── logging_events.py   # logs administrativos
│   ├── announcements.py    # /announce, /changelog, /devupdate, monitor de updates do Roblox
│   └── autoroles.py        # Verified/Member, Veteran automático
├── docs/MANUAL.md          # manual de uso e administração
└── tests/                  # testes (unitários + fluxos com Discord simulado)
```

---

## 2. Criar o bot no Discord

1. Acesse <https://discord.com/developers/applications> → **New Application** → nome `PolyBattle`.
2. Aba **Bot**:
   - **Reset Token** → copie o token (ele aparece uma vez; guarde no `.env`, nunca em código ou chat).
   - Em **Privileged Gateway Intents**, ative **SERVER MEMBERS INTENT** e **MESSAGE CONTENT INTENT**.
   - Desative **Public Bot** se só você deve poder convidá-lo.
3. Aba **General Information** → copie o **Application ID**.

### Convidar o bot

Troque `SEU_APPLICATION_ID` e abra o link:

```
https://discord.com/oauth2/authorize?client_id=SEU_APPLICATION_ID&permissions=8&scope=bot%20applications.commands
```

`permissions=8` = **Administrador**. É necessário porque o setup cria cargos com permissões
(o Discord só deixa um bot conceder permissões que ele mesmo tem) e aplica overwrites em todos os
canais. O bot verifica isso antes de instalar (`/setup status`).

> **Depois de convidar:** em *Configurações do servidor → Cargos*, arraste o cargo do bot
> (`PolyBattle`) para o **topo da lista**. O bot só gerencia cargos abaixo dele.

---

## 3. Instalação

```bash
git clone <seu-repositório> polybattle-bot   # ou extraia o .zip
cd polybattle-bot
python -m venv .venv
# Windows: .venv\Scripts\activate    Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env                          # Windows: copy .env.example .env
```

Edite o `.env`: preencha `DISCORD_TOKEN` e `GUILD_ID` (ID do servidor). Os demais campos têm
padrões sensatos — veja os comentários no próprio arquivo.

Valide sem conectar ao Discord:

```bash
python bot.py --check
```

Inicie:

```bash
python bot.py
```

O banco `data/polybattle.db` é criado automaticamente. Logs ficam em `logs/polybattle.log`
(rotação de 5 MB × 5 arquivos; o token é removido de qualquer linha de log).

---

## 4. Configuração inicial do servidor

1. No Discord, como **dono do servidor**, execute **`/setup install`** e confirme.
2. O bot vai:
   - criar os 13 cargos com cores e hierarquia (Founder → Member) e dar **Founder** ao dono;
   - reduzir as permissões de **@everyone** ao mínimo seguro (ler + usar comandos);
   - criar as categorias INFORMATION, COMMUNITY, GAME SUPPORT, DEVELOPMENT, VOICE CHANNELS,
     STAFF e TICKETS com todos os canais e permissões;
   - publicar os painéis: regras, apresentação/informações do jogo, links, verificação,
     tickets, denúncias e sugestões.
3. Rode **`/setup status`** para conferir intents, hierarquia e recursos.
4. Distribua os cargos de equipe (veja as regras de concessão no manual).

Canais ou cargos que já existirem **com o mesmo nome** são reaproveitados. Nada é apagado.
Depois de editar `core/content.py`, use **`/setup panels`** para republicar os textos.

> **Canais extras criados:** além da lista do projeto, o setup cria `✅┃verify` (painel de
> verificação, visível só para quem não é verificado) e a categoria `◤ TICKETS ◢` (oculta,
> onde ficam os tickets privados).

---

## 5. Testes

```bash
pip install -r requirements-dev.txt
python -m pytest
```

- `tests/test_core.py` — lógica pura e banco de dados (sempre executa).
- `tests/test_flows.py` — fluxos completos (setup idempotente, visibilidade de canais, verificação,
  tickets com transcript, sugestões, denúncias, moderação/escalonamento, automod, anti-raid,
  segurança de cargos, Veteran) usando um **Discord simulado em memória** (`tests/stubs`), que
  substitui o discord.py apenas dentro do pytest.

**Importante:** os testes validam a lógica do bot, mas o Discord simulado não reproduz 100% da API
real. Antes de abrir o servidor ao público, faça o roteiro de homologação do `docs/MANUAL.md`
(seção 9) em um servidor de teste.

---

## 6. Hospedagem

O bot precisa ficar ligado 24/7. Opções: VPS (Linux + `systemd`), Railway, Fly.io, um PC sempre
ligado etc. Exemplo de serviço `systemd`:

```ini
[Unit]
Description=PolyBattle Discord Bot
After=network-online.target

[Service]
WorkingDirectory=/opt/polybattle-bot
ExecStart=/opt/polybattle-bot/.venv/bin/python bot.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Faça backup periódico de `data/polybattle.db` (tickets, avisos, sugestões, denúncias e IDs dos
canais/cargos).

---

## 7. Solução de problemas

| Sintoma | Causa / solução |
|---|---|
| `PrivilegedIntentsRequired` | Ative SERVER MEMBERS e MESSAGE CONTENT no Developer Portal. |
| `Token inválido` | Gere outro token (Reset Token) e atualize o `.env`. |
| Comandos não aparecem | Preencha `GUILD_ID`. Sem ele a sincronização é global e pode levar até 1h. Reinicie o Discord (Ctrl+R). |
| "O cargo X está acima do cargo do bot" | Arraste o cargo do bot para o topo e rode `/setup install` de novo. |
| Verificação não dá cargos | Hierarquia: o cargo do bot precisa estar acima de Verified/Member. |
| Painéis sem botões após reiniciar | Não deve ocorrer (views persistentes). Se apagou a mensagem, use `/setup panels`. |
